package com.student.core.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class SupabaseApi {
    private val client = OkHttpClient()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    fun login(email: String, password: String): Result<StudentSession> = runCatching {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .post(body.toRequestBody(jsonType))
            .build()
        executeAuth(request)
    }

    fun register(fullName: String, email: String, password: String): Result<StudentSession?> = runCatching {
        val body = JSONObject()
            .put("email", email)
            .put("password", password)
            .put("data", JSONObject().put("full_name", fullName))
            .toString()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/auth/v1/signup")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .post(body.toRequestBody(jsonType))
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(errorMessage(raw, response.code))
            val root = JSONObject(raw)
            if (!root.has("access_token")) null else sessionFrom(root)
        }
    }

    fun refresh(refreshToken: String): Result<StudentSession> = runCatching {
        val body = JSONObject().put("refresh_token", refreshToken).toString()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .post(body.toRequestBody(jsonType))
            .build()
        executeAuth(request)
    }

    fun profile(session: StudentSession): Result<StudentProfile> = runCatching {
        val arr = getArray(session, "profiles?id=eq.${session.userId}&select=*&limit=1")
        if (arr.length() == 0) throw IllegalStateException("تعذر العثور على ملف الحساب.")
        parseProfile(arr.getJSONObject(0), session.email)
    }

    fun updateProfile(
        session: StudentSession,
        fullName: String,
        username: String,
        bio: String,
        accountStatus: String
    ): Result<Unit> = runCatching {
        val body = JSONObject()
            .put("full_name", fullName)
            .put("username", username)
            .put("bio", bio)
            .put("account_status", accountStatus)
        requestJson(session, "profiles?id=eq.${session.userId}", "PATCH", body, "return=minimal")
        Unit
    }

    fun updateAvatar(session: StudentSession, avatarUrl: String): Result<Unit> = runCatching {
        val body = JSONObject().put("avatar_url", avatarUrl)
        requestJson(session, "profiles?id=eq.${session.userId}", "PATCH", body, "return=minimal")
        Unit
    }

    fun feed(session: StudentSession, limit: Int = 40): Result<List<PostItem>> = runCatching {
        val arr = getArray(session, "posts?select=*&post_type=in.(text,image)&order=created_at.desc&limit=$limit")
        val ids = mutableSetOf<String>()
        for (i in 0 until arr.length()) ids += arr.getJSONObject(i).optString("user_id")
        val profiles = profileMap(session, ids.filter { it.isNotBlank() })
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val uid = o.optString("user_id")
                val p = profiles[uid]
                add(
                    PostItem(
                        id = o.optString("id"),
                        userId = uid,
                        postType = o.optString("post_type", "text"),
                        content = o.optString("content", ""),
                        mediaUrl = nullable(o, "media_url"),
                        createdAt = o.optString("created_at", ""),
                        authorName = p?.fullName ?: "مستخدم",
                        authorUsername = p?.username ?: "student",
                        authorAvatarUrl = p?.avatarUrl,
                        authorFrameUrl = p?.profileFrameUrl,
                        authorVerified = p?.isVerified ?: false,
                        authorVerificationColor = p?.verificationColor
                    )
                )
            }
        }
    }

    fun createPost(session: StudentSession, content: String, mediaUrl: String? = null): Result<Unit> = runCatching {
        val body = JSONObject()
            .put("user_id", session.userId)
            .put("post_type", if (mediaUrl.isNullOrBlank()) "text" else "image")
            .put("content", content)
            .put("media_url", mediaUrl ?: JSONObject.NULL)
        requestJson(session, "posts", "POST", body, "return=minimal")
        Unit
    }

    fun deletePost(session: StudentSession, postId: String): Result<Unit> = runCatching {
        requestJson(session, "posts?id=eq.$postId&user_id=eq.${session.userId}", "DELETE", null, "return=minimal")
        Unit
    }

    fun isPostLiked(session: StudentSession, postId: String): Result<Boolean> = runCatching {
        getArray(session, "post_likes?select=user_id&post_id=eq.$postId&user_id=eq.${session.userId}&limit=1").length() > 0
    }

    fun setPostLiked(session: StudentSession, postId: String, liked: Boolean): Result<Unit> = runCatching {
        if (liked) {
            requestJson(session, "post_likes", "POST", JSONObject().put("post_id", postId).put("user_id", session.userId), "return=minimal")
        } else {
            requestJson(session, "post_likes?post_id=eq.$postId&user_id=eq.${session.userId}", "DELETE", null, "return=minimal")
        }
        Unit
    }

    fun comments(session: StudentSession, postId: String): Result<List<CommentItem>> = runCatching {
        val arr = getArray(session, "comments?select=*&post_id=eq.$postId&order=created_at.asc&limit=200")
        val ids = mutableSetOf<String>()
        for (i in 0 until arr.length()) ids += arr.getJSONObject(i).optString("user_id")
        val profiles = profileMap(session, ids.filter { it.isNotBlank() })
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val uid = o.optString("user_id")
                add(CommentItem(o.optString("id"), postId, uid, first(o,"content","body","text"), o.optString("created_at"), profiles[uid]?.fullName ?: "مستخدم"))
            }
        }
    }

    fun addComment(session: StudentSession, postId: String, content: String): Result<Unit> = runCatching {
        requestJson(session, "comments", "POST", JSONObject().put("post_id", postId).put("user_id", session.userId).put("content", content), "return=minimal")
        Unit
    }

    fun stories(session: StudentSession, limit: Int = 40): Result<List<StoryItem>> = runCatching {
        val arr = getArray(session, "stories?select=*&order=created_at.desc&limit=$limit")
        val ids = mutableSetOf<String>()
        for (i in 0 until arr.length()) ids += arr.getJSONObject(i).optString("user_id")
        val profiles = profileMap(session, ids.filter { it.isNotBlank() })
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val uid = o.optString("user_id")
                add(
                    StoryItem(
                        id = o.optString("id"),
                        userId = uid,
                        type = o.optString("type", "text"),
                        content = o.optString("content", ""),
                        mediaUrl = nullable(o, "media_url"),
                        createdAt = o.optString("created_at", ""),
                        expiresAt = nullable(o, "expires_at"),
                        authorName = profiles[uid]?.fullName ?: "مستخدم",
                        authorAvatarUrl = profiles[uid]?.avatarUrl,
                        authorFrameUrl = profiles[uid]?.profileFrameUrl,
                        authorVerified = profiles[uid]?.isVerified ?: false,
                        authorVerificationColor = profiles[uid]?.verificationColor
                    )
                )
            }
        }
    }

    fun createTextStory(session: StudentSession, content: String): Result<Unit> =
        createStory(session, content, null, "text")

    fun createStory(session: StudentSession, content: String, mediaUrl: String?, type: String): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        val format = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val created = format.format(java.util.Date(now))
        val expires = format.format(java.util.Date(now + 24L * 60L * 60L * 1000L))
        val body = JSONObject()
            .put("user_id", session.userId)
            .put("type", type)
            .put("content", content)
            .put("media_url", mediaUrl ?: JSONObject.NULL)
            .put("media_path", JSONObject.NULL)
            .put("background_color", "#1877f2")
            .put("text_color", "#ffffff")
            .put("visibility", "public")
            .put("reply_enabled", true)
            .put("created_at", created)
            .put("expires_at", expires)
        requestJson(session, "stories", "POST", body, "return=minimal")
        Unit
    }

    fun notifications(session: StudentSession, limit: Int = 60): Result<List<StudentNotification>> = runCatching {
        val arr = getArray(session, "notifications?select=*&order=created_at.desc&limit=$limit")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    StudentNotification(
                        id = o.optString("id"),
                        title = o.optString("title", "Student"),
                        body = o.optString("body", ""),
                        kind = o.optString("kind", "general"),
                        createdAt = o.optString("created_at", ""),
                        isRead = o.optBoolean("is_read", false)
                    )
                )
            }
        }
    }

    fun markNotificationRead(session: StudentSession, notificationId: String): Result<Unit> = runCatching {
        val body = JSONObject().put("is_read", true)
        requestJson(session, "notifications?id=eq.$notificationId", "PATCH", body, "return=minimal")
        Unit
    }

    fun searchProfiles(session: StudentSession, query: String): Result<List<ProfileSearchItem>> = runCatching {
        val clean = query.trim().replace("%", "").replace(",", "").replace("(", "").replace(")", "")
        if (clean.isBlank()) return@runCatching emptyList()
        val path = "profiles?select=*&or=(full_name.ilike.*$clean*,username.ilike.*$clean*)&limit=30"
        val arr = getArray(session, path)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    ProfileSearchItem(
                        id = o.optString("id"),
                        fullName = o.optString("full_name", "مستخدم"),
                        username = o.optString("username", "student"),
                        role = o.optString("role", "student"),
                        avatarUrl = nullable(o, "avatar_url"),
                        isVerified = o.optBoolean("is_verified", false),
                        verificationColor = nullable(o, "verification_color"),
                        profileFrameUrl = nullable(o, "profile_frame_url")
                    )
                )
            }
        }
    }

    fun profileStats(session: StudentSession, userId: String): Result<ProfileStats> = runCatching {
        val raw = rpcRaw(session, "get_profile_stats", JSONObject().put("p_user_id", userId))
        val o = parseObjectFromRpc(raw)
        val postsArr = getArray(session, "posts?select=id&user_id=eq.$userId&limit=1000")
        ProfileStats(
            followers = intFirst(o, "followers_count", "followers"),
            following = intFirst(o, "following_count", "following"),
            posts = postsArr.length()
        )
    }

    fun isFollowing(session: StudentSession, otherUserId: String): Result<Boolean> = runCatching {
        val arr = getArray(session, "follows?select=follower_id&follower_id=eq.${session.userId}&following_id=eq.$otherUserId&limit=1")
        arr.length() > 0
    }

    fun setFollowing(session: StudentSession, otherUserId: String, follow: Boolean): Result<Unit> = runCatching {
        if (follow) {
            val body = JSONObject().put("follower_id", session.userId).put("following_id", otherUserId)
            requestJson(session, "follows", "POST", body, "return=minimal")
        } else {
            requestJson(session, "follows?follower_id=eq.${session.userId}&following_id=eq.$otherUserId", "DELETE", null, "return=minimal")
        }
        Unit
    }

    fun conversations(session: StudentSession): Result<List<ConversationItem>> = runCatching {
        val arr = rpcArray(session, "student_get_conversations", JSONObject())
        val peerIds = buildList {
            for (i in 0 until arr.length()) {
                nullableFirst(arr.getJSONObject(i), "other_user_id", "other_id", "peer_id")?.let { add(it) }
            }
        }
        val profiles = profileMap(session, peerIds.distinct())
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val peerId = nullableFirst(o, "other_user_id", "other_id", "peer_id")
                val peer = peerId?.let { profiles[it] }
                add(
                    ConversationItem(
                        id = first(o, "id", "conversation_id"),
                        title = peer?.fullName ?: first(o, "title", "other_name", "name").ifBlank { "المحادثة" },
                        kind = first(o, "kind", "conversation_type").ifBlank { "direct" },
                        otherUserId = peerId,
                        lastMessage = first(o, "last_message", "last_message_body", "body"),
                        lastMessageAt = first(o, "last_message_at", "updated_at", "created_at"),
                        unreadCount = intFirst(o, "unread_count", "unread"),
                        avatarUrl = peer?.avatarUrl ?: nullableFirst(o, "avatar_url", "other_avatar_url"),
                        profileFrameUrl = peer?.profileFrameUrl,
                        isVerified = peer?.isVerified ?: false,
                        verificationColor = peer?.verificationColor
                    )
                )
            }
        }
    }

    fun startDirectChat(session: StudentSession, otherUserId: String): Result<String> = runCatching {
        val raw = rpcRaw(session, "student_start_direct_chat", JSONObject().put("p_other_user", otherUserId))
        parseIdFromRpc(raw)
    }

    fun messages(session: StudentSession, conversationId: String, limit: Int = 60): Result<List<MessageItem>> = runCatching {
        val args = JSONObject().put("p_conversation", conversationId).put("p_before", JSONObject.NULL).put("p_limit", limit)
        val arr = rpcArray(session, "student_get_messages", args)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    MessageItem(
                        id = o.optString("id"),
                        conversationId = first(o, "conversation_id", "conversation").ifBlank { conversationId },
                        senderId = first(o, "sender_id", "user_id"),
                        body = o.optString("body", ""),
                        messageType = o.optString("message_type", "text"),
                        mediaUrl = nullable(o, "media_url"),
                        fileName = nullable(o, "file_name"),
                        createdAt = o.optString("created_at", ""),
                        editedAt = nullable(o, "edited_at"),
                        deletedAt = nullable(o, "deleted_at")
                    )
                )
            }
        }
    }

    fun sendMessage(session: StudentSession, conversationId: String, bodyText: String): Result<Unit> = runCatching {
        val args = JSONObject()
            .put("p_conversation", conversationId)
            .put("p_body", bodyText)
            .put("p_reply_to", JSONObject.NULL)
            .put("p_message_type", "text")
            .put("p_media_url", JSONObject.NULL)
            .put("p_file_name", JSONObject.NULL)
            .put("p_file_size", JSONObject.NULL)
        rpcRaw(session, "student_send_message", args)
        Unit
    }

    fun sendMediaMessage(
        session: StudentSession,
        conversationId: String,
        mediaUrl: String,
        messageType: String,
        fileName: String?,
        fileSize: Long
    ): Result<Unit> = runCatching {
        val args = JSONObject()
            .put("p_conversation", conversationId)
            .put("p_body", "")
            .put("p_reply_to", JSONObject.NULL)
            .put("p_message_type", messageType)
            .put("p_media_url", mediaUrl)
            .put("p_file_name", fileName ?: JSONObject.NULL)
            .put("p_file_size", fileSize)
        rpcRaw(session, "student_send_message", args)
        Unit
    }

    fun markConversationRead(session: StudentSession, conversationId: String): Result<Unit> = runCatching {
        rpcRaw(session, "student_mark_conversation_read", JSONObject().put("p_conversation", conversationId))
        Unit
    }

    fun educationStages(session: StudentSession): Result<List<EducationStage>> = runCatching {
        val arr = getArray(session, "education_stages?select=*&order=sort_order.asc")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(EducationStage(o.optString("id"), o.optString("name", "مرحلة"), o.optString("slug", ""), o.optString("description", ""), o.optInt("sort_order", i)))
            }
        }
    }

    fun educationLevels(session: StudentSession, stageId: String): Result<List<EducationLevel>> = runCatching {
        val arr = getArray(session, "education_levels?select=*&stage_id=eq.$stageId&order=sort_order.asc")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(EducationLevel(o.optString("id"), o.optString("stage_id", stageId), o.optString("name", "صف"), o.optString("slug", ""), o.optInt("sort_order", i)))
            }
        }
    }

    fun educationSubjects(session: StudentSession, levelId: String): Result<List<EducationSubject>> = runCatching {
        val links = getArray(session, "education_level_subjects?select=*&level_id=eq.$levelId&order=sort_order.asc")
        val ids = buildList {
            for (i in 0 until links.length()) {
                val id = links.getJSONObject(i).optString("subject_id")
                if (id.isNotBlank()) add(id)
            }
        }
        if (ids.isEmpty()) return@runCatching emptyList()
        val joined = ids.joinToString(",")
        val arr = getArray(session, "education_subjects?select=*&id=in.($joined)&order=sort_order.asc")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(EducationSubject(o.optString("id"), o.optString("name", "مادة"), o.optString("slug", ""), o.optString("description", "")))
            }
        }.sortedBy { ids.indexOf(it.id) }
    }

    fun educationMaterials(session: StudentSession, subjectId: String): Result<List<EducationMaterial>> = runCatching {
        val arr = getArray(session, "education_materials?select=*&subject_id=eq.$subjectId&status=eq.published&order=created_at.desc&limit=100")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    EducationMaterial(
                        id = o.optString("id"),
                        title = o.optString("title", "محتوى تعليمي"),
                        description = o.optString("description", ""),
                        materialType = o.optString("material_type", "text"),
                        fileUrl = nullable(o, "file_url"),
                        externalUrl = nullable(o, "external_url"),
                        createdAt = o.optString("created_at", "")
                    )
                )
            }
        }
    }

    fun universities(session: StudentSession): Result<List<UniversityNode>> =
        universityNodes(session, "universities", null, null)

    fun universityColleges(session: StudentSession, universityId: String): Result<List<UniversityNode>> =
        universityNodes(session, "university_colleges", "university_id", universityId)

    fun universityDepartments(session: StudentSession, collegeId: String): Result<List<UniversityNode>> =
        universityNodes(session, "university_departments", "college_id", collegeId)

    fun universityLevels(session: StudentSession, departmentId: String): Result<List<UniversityNode>> =
        universityNodes(session, "university_levels", "department_id", departmentId)

    fun universitySubjects(session: StudentSession, universityLevelId: String): Result<List<EducationSubject>> = runCatching {
        val links = getArray(session, "university_level_subjects?select=*&university_level_id=eq.$universityLevelId&order=sort_order.asc")
        val ids = buildList {
            for (i in 0 until links.length()) {
                val id = links.getJSONObject(i).optString("subject_id")
                if (id.isNotBlank()) add(id)
            }
        }
        if (ids.isEmpty()) return@runCatching emptyList()
        val arr = getArray(session, "university_subjects?select=*&id=in.(${ids.joinToString(",")})&order=sort_order.asc")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(EducationSubject(o.optString("id"), o.optString("name", "مادة"), o.optString("slug", ""), o.optString("description", "")))
            }
        }.sortedBy { ids.indexOf(it.id) }
    }

    fun universityMaterials(session: StudentSession, universityLevelId: String, subjectId: String): Result<List<EducationMaterial>> = runCatching {
        val arr = getArray(session, "education_materials?select=*&education_type=eq.university&subject_id=eq.$subjectId&university_level_id=eq.$universityLevelId&status=eq.published&order=created_at.desc&limit=100")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(EducationMaterial(o.optString("id"), o.optString("title", "محتوى تعليمي"), o.optString("description", ""), o.optString("material_type", "text"), nullable(o,"file_url"), nullable(o,"external_url"), o.optString("created_at", "")))
            }
        }
    }

    private fun universityNodes(session: StudentSession, table: String, parentKey: String?, parentId: String?): Result<List<UniversityNode>> = runCatching {
        val filter = if (!parentKey.isNullOrBlank() && !parentId.isNullOrBlank()) "&$parentKey=eq.$parentId" else ""
        val arr = getArray(session, "$table?select=*&order=sort_order.asc$filter")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(UniversityNode(o.optString("id"), o.optString("name", "عنصر"), o.optString("slug", ""), o.optString("description", ""), parentId))
            }
        }
    }

    fun storeProducts(session: StudentSession): Result<List<StoreProduct>> = runCatching {
        val arr = getArray(session, "store_products?select=*&is_active=eq.true&order=sort_order.asc")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    StoreProduct(
                        id = o.optString("id"),
                        name = o.optString("name", "منتج"),
                        description = o.optString("description", ""),
                        productType = o.optString("product_type", "product"),
                        priceMoney = o.optDouble("price_money", 0.0),
                        currency = o.optString("currency", "IQD"),
                        priceDiamonds = o.optInt("price_diamonds", 0),
                        allowMoney = o.optBoolean("allow_money", true),
                        allowDiamonds = o.optBoolean("allow_diamonds", false),
                        imageUrl = nullable(o, "image_url"),
                        frameKey = nullable(o, "frame_key"),
                        frameDurationDays = if (o.has("frame_duration_days") && !o.isNull("frame_duration_days")) o.optInt("frame_duration_days") else null
                    )
                )
            }
        }
    }

    fun walletSummary(session: StudentSession): Result<WalletSummary> = runCatching {
        val raw = rpcRaw(session, "store_get_wallet_summary", JSONObject())
        val o = parseObjectFromRpc(raw)
        WalletSummary(
            availableBalance = doubleFirst(o, "available_balance", "balance"),
            heldBalance = doubleFirst(o, "held_balance"),
            totalSpent = doubleFirst(o, "total_spent"),
            diamonds = intFirst(o, "diamonds", "diamond_balance", "balance_diamonds")
        )
    }

    fun storeOrders(session: StudentSession): Result<List<StoreOrder>> = runCatching {
        val arr = getArray(session, "store_orders?select=*&user_id=eq.${session.userId}&order=created_at.desc&limit=100")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    StoreOrder(
                        id = o.optString("id"),
                        productName = o.optString("product_name", "طلب"),
                        paymentMethod = o.optString("payment_method", ""),
                        moneyAmount = o.optDouble("money_amount", 0.0),
                        diamondAmount = o.optInt("diamond_amount", 0),
                        status = o.optString("status", "pending"),
                        createdAt = o.optString("created_at", "")
                    )
                )
            }
        }
    }

    fun createStoreOrder(session: StudentSession, productId: String, paymentMethod: String): Result<String> = runCatching {
        val raw = rpcRaw(session, "create_store_order", JSONObject().put("p_product_id", productId).put("p_payment_method", paymentMethod))
        parseIdFromRpc(raw)
    }

    fun isAdmin(session: StudentSession): Result<Boolean> = runCatching {
        val raw = rpcRaw(session, "current_user_is_admin", JSONObject()).trim()
        raw == "true" || raw == "1" || runCatching { parseObjectFromRpc(raw).optBoolean("current_user_is_admin", false) }.getOrDefault(false)
    }

    fun adminRecentUsers(session: StudentSession): Result<List<AdminRecentUser>> = runCatching {
        val arr = rpcArray(session, "student_admin_recent_users", JSONObject().put("p_limit", 50))
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    AdminRecentUser(
                        id = o.optString("id"),
                        fullName = o.optString("full_name", "مستخدم"),
                        username = o.optString("username", "student"),
                        email = o.optString("email", ""),
                        role = o.optString("role", "student"),
                        createdAt = o.optString("created_at", ""),
                        isVerified = o.optBoolean("is_verified", false)
                    )
                )
            }
        }
    }

    fun grantVerification(session: StudentSession, userId: String, color: String): Result<Unit> = runCatching {
        rpcRaw(
            session,
            "student_admin_gift_profile_cosmetic",
            JSONObject()
                .put("p_user", userId)
                .put("p_kind", "verification")
                .put("p_value", color)
                .put("p_label", "هدية من إدارة Student")
                .put("p_color", color)
        )
        Unit
    }

    fun myProfileFrames(session: StudentSession): Result<List<OwnedProfileFrame>> = runCatching {
        val arr = rpcArray(session, "student_get_my_profile_frames", JSONObject())
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(
                    OwnedProfileFrame(
                        id = o.optString("id"),
                        frameKey = o.optString("frame_key"),
                        productId = nullable(o, "product_id"),
                        source = o.optString("source", "store"),
                        expiresAt = nullable(o, "expires_at"),
                        isActive = o.optBoolean("is_active", false),
                        createdAt = o.optString("created_at", "")
                    )
                )
            }
        }
    }

    fun equipProfileFrame(session: StudentSession, ownedFrameId: String): Result<Unit> = runCatching {
        rpcRaw(session, "student_equip_profile_frame", JSONObject().put("p_owned_frame_id", ownedFrameId))
        Unit
    }

    fun clearProfileFrame(session: StudentSession): Result<Unit> = runCatching {
        rpcRaw(session, "student_clear_profile_frame", JSONObject())
        Unit
    }

    fun deleteProfileFrame(session: StudentSession, ownedFrameId: String): Result<Unit> = runCatching {
        rpcRaw(session, "student_delete_profile_frame", JSONObject().put("p_owned_frame_id", ownedFrameId))
        Unit
    }

    fun grantProfileFrame(session: StudentSession, userId: String, frameKey: String, days: Int?): Result<Unit> = runCatching {
        rpcRaw(
            session,
            "student_admin_grant_profile_frame",
            JSONObject().put("p_user", userId).put("p_frame_key", frameKey).put("p_days", days ?: JSONObject.NULL)
        )
        Unit
    }

    fun grantCustomBadge(session: StudentSession, userId: String, label: String, color: String): Result<Unit> = runCatching {
        rpcRaw(
            session,
            "student_admin_gift_profile_cosmetic",
            JSONObject()
                .put("p_user", userId)
                .put("p_kind", "custom_badge")
                .put("p_value", "★")
                .put("p_label", label.ifBlank { "علامة مميزة" })
                .put("p_color", color.ifBlank { "#7c3aed" })
        )
        Unit
    }

    fun featureFlags(session: StudentSession): Result<List<FeatureFlag>> = runCatching {
        val arr = getArray(session, "feature_flags?select=*")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val key = first(o, "feature_key", "key", "name")
                if (key.isNotBlank()) add(FeatureFlag(o.optString("id"), o.optString("name", key), key, boolFirst(o, "enabled", "is_enabled", default = true)))
            }
        }
    }


    fun uploadObject(
        session: StudentSession,
        bucket: String,
        path: String,
        bytes: ByteArray,
        mimeType: String
    ): Result<String> = runCatching {
        val bodyType = mimeType.toMediaType()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/storage/v1/object/$bucket/$path")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .header("Authorization", "Bearer ${session.accessToken}")
            .header("x-upsert", "false")
            .post(bytes.toRequestBody(bodyType))
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(errorMessage(raw, response.code))
        }
        "${StudentConfig.SUPABASE_URL}/storage/v1/object/public/$bucket/$path"
    }

    fun savedItems(session: StudentSession): Result<List<SavedItem>> = runCatching {
        val arr = getArray(session, "saved_items?select=*&user_id=eq.${session.userId}&order=created_at.desc&limit=200")
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(SavedItem(o.optString("id"), o.optString("content_type"), o.optString("content_id"), o.optString("created_at")))
            }
        }
    }

    fun saveItem(session: StudentSession, contentType: String, contentId: String): Result<Unit> = runCatching {
        val body = JSONObject().put("user_id", session.userId).put("content_type", contentType).put("content_id", contentId)
        requestJson(session, "saved_items", "POST", body, "return=minimal")
        Unit
    }

    fun deleteSavedItem(session: StudentSession, savedId: String): Result<Unit> = runCatching {
        requestJson(session, "saved_items?id=eq.$savedId&user_id=eq.${session.userId}", "DELETE", null, "return=minimal")
        Unit
    }

    fun updateFeatureFlag(session: StudentSession, id: String, enabled: Boolean): Result<Unit> = runCatching {
        val body = JSONObject().put("enabled", enabled)
        requestJson(session, "feature_flags?id=eq.$id", "PATCH", body, "return=minimal")
        Unit
    }

    fun adminBroadcast(session: StudentSession, title: String, bodyText: String, link: String? = null): Result<Unit> = runCatching {
        rpcRaw(
            session,
            "student_admin_broadcast_v2",
            JSONObject().put("p_title", title).put("p_body", bodyText).put("p_link", link ?: JSONObject.NULL)
        )
        Unit
    }

    fun registerPushToken(session: StudentSession, token: String): Result<Unit> = runCatching {
        val body = JSONObject()
            .put("user_id", session.userId)
            .put("fcm_token", token)
            .put("platform", "android-fcm")
            .put("is_active", true)
        requestJson(session, "device_push_tokens?on_conflict=fcm_token", "POST", body, "resolution=merge-duplicates,return=minimal")
        Unit
    }

    private fun profileMap(session: StudentSession, ids: List<String>): Map<String, StudentProfile> {
        if (ids.isEmpty()) return emptyMap()
        return runCatching {
            val arr = getArray(session, "profiles?select=*&id=in.(${ids.joinToString(",")})")
            buildMap {
                for (i in 0 until arr.length()) {
                    val p = parseProfile(arr.getJSONObject(i), "")
                    put(p.id, p)
                }
            }
        }.getOrDefault(emptyMap())
    }

    private fun parseProfile(o: JSONObject, fallbackEmail: String): StudentProfile = StudentProfile(
        id = o.optString("id"),
        fullName = first(o, "full_name", "display_name").ifBlank { "مستخدم" },
        username = o.optString("username", "student"),
        email = o.optString("email", fallbackEmail),
        bio = o.optString("bio", ""),
        avatarUrl = nullable(o, "avatar_url"),
        role = o.optString("role", "student"),
        accountStatus = o.optString("account_status", "public"),
        profileFrameUrl = nullable(o, "profile_frame_url"),
        isVerified = o.optBoolean("is_verified", false),
        verificationColor = nullable(o, "verification_color"),
        customBadgeLabel = nullable(o, "custom_badge_label"),
        customBadgeColor = nullable(o, "custom_badge_color"),
        createdAt = nullable(o, "created_at")
    )

    private fun getArray(session: StudentSession, path: String): JSONArray {
        val raw = requestJson(session, path, "GET", null, null)
        return if (raw.isBlank()) JSONArray() else JSONArray(raw)
    }

    private fun rpcArray(session: StudentSession, name: String, args: JSONObject): JSONArray {
        val raw = rpcRaw(session, name, args).trim()
        if (raw.isBlank() || raw == "null") return JSONArray()
        return when (raw.firstOrNull()) {
            '[' -> JSONArray(raw)
            '{' -> JSONArray().put(JSONObject(raw))
            else -> JSONArray()
        }
    }

    private fun rpcRaw(session: StudentSession, name: String, args: JSONObject): String =
        requestJson(session, "rpc/$name", "POST", args, null)

    private fun requestJson(
        session: StudentSession,
        path: String,
        method: String,
        body: JSONObject?,
        prefer: String?
    ): String {
        val builder = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/rest/v1/$path")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .header("Authorization", "Bearer ${session.accessToken}")
        if (!prefer.isNullOrBlank()) builder.header("Prefer", prefer)
        when (method) {
            "GET" -> builder.get()
            "POST" -> builder.post((body ?: JSONObject()).toString().toRequestBody(jsonType))
            "PATCH" -> builder.patch((body ?: JSONObject()).toString().toRequestBody(jsonType))
            "DELETE" -> builder.delete()
            else -> error("Unsupported HTTP method")
        }
        client.newCall(builder.build()).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(errorMessage(raw, response.code))
            return raw
        }
    }

    private fun executeAuth(request: Request): StudentSession {
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(errorMessage(raw, response.code))
            return sessionFrom(JSONObject(raw))
        }
    }

    private fun sessionFrom(root: JSONObject): StudentSession {
        val user = root.optJSONObject("user") ?: throw IllegalStateException("بيانات المستخدم غير مكتملة.")
        return StudentSession(
            accessToken = root.getString("access_token"),
            refreshToken = root.getString("refresh_token"),
            userId = user.getString("id"),
            email = user.optString("email", "")
        )
    }

    private fun parseIdFromRpc(rawValue: String): String {
        val raw = rawValue.trim()
        if (raw.isBlank() || raw == "null") return ""
        if (raw.startsWith("\"")) return raw.trim('"')
        return runCatching {
            val o = parseObjectFromRpc(raw)
            first(o, "id", "conversation_id", "order_id", "result")
        }.getOrDefault(raw)
    }

    private fun parseObjectFromRpc(rawValue: String): JSONObject {
        val raw = rawValue.trim()
        if (raw.startsWith("[")) {
            val a = JSONArray(raw)
            return if (a.length() > 0 && a.opt(0) is JSONObject) a.getJSONObject(0) else JSONObject()
        }
        if (raw.startsWith("{")) return JSONObject(raw)
        return JSONObject()
    }

    private fun nullable(o: JSONObject, key: String): String? =
        if (!o.has(key) || o.isNull(key)) null else o.optString(key).takeIf { it.isNotBlank() && it != "null" }

    private fun first(o: JSONObject, vararg keys: String): String {
        keys.forEach { key ->
            if (o.has(key) && !o.isNull(key)) {
                val value = o.optString(key, "")
                if (value.isNotBlank() && value != "null") return value
            }
        }
        return ""
    }

    private fun nullableFirst(o: JSONObject, vararg keys: String): String? = first(o, *keys).takeIf { it.isNotBlank() }

    private fun intFirst(o: JSONObject, vararg keys: String): Int {
        keys.forEach { if (o.has(it) && !o.isNull(it)) return o.optInt(it, 0) }
        return 0
    }

    private fun doubleFirst(o: JSONObject, vararg keys: String): Double {
        keys.forEach { if (o.has(it) && !o.isNull(it)) return o.optDouble(it, 0.0) }
        return 0.0
    }

    private fun boolFirst(o: JSONObject, vararg keys: String, default: Boolean): Boolean {
        keys.forEach { if (o.has(it) && !o.isNull(it)) return o.optBoolean(it, default) }
        return default
    }

    private fun errorMessage(raw: String, code: Int): String = try {
        val o = JSONObject(raw)
        o.optString("msg").ifBlank { o.optString("message") }.ifBlank { o.optString("error_description") }
            .ifBlank { o.optString("hint") }.ifBlank { "تعذر إكمال العملية ($code)." }
    } catch (_: Exception) {
        "تعذر إكمال العملية ($code)."
    }
}
