package com.student.core.data

data class StudentSession(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String
)

data class StudentProfile(
    val id: String,
    val fullName: String,
    val username: String,
    val email: String,
    val bio: String,
    val avatarUrl: String?,
    val role: String,
    val accountStatus: String,
    val profileFrameUrl: String?,
    val isVerified: Boolean = false,
    val verificationColor: String? = null,
    val customBadgeLabel: String? = null,
    val customBadgeColor: String? = null,
    val createdAt: String? = null
)

data class PostItem(
    val id: String,
    val userId: String,
    val postType: String,
    val content: String,
    val mediaUrl: String?,
    val createdAt: String,
    val authorName: String = "مستخدم",
    val authorUsername: String = "student",
    val authorAvatarUrl: String? = null,
    val authorFrameUrl: String? = null,
    val authorVerified: Boolean = false,
    val authorVerificationColor: String? = null
)

data class StoryItem(
    val id: String,
    val userId: String,
    val type: String,
    val content: String,
    val mediaUrl: String?,
    val createdAt: String,
    val expiresAt: String?,
    val authorName: String = "مستخدم",
    val authorAvatarUrl: String? = null,
    val authorFrameUrl: String? = null,
    val authorVerified: Boolean = false,
    val authorVerificationColor: String? = null
)

data class StudentNotification(
    val id: String,
    val title: String,
    val body: String,
    val kind: String,
    val createdAt: String,
    val isRead: Boolean
)

data class ProfileSearchItem(
    val id: String,
    val fullName: String,
    val username: String,
    val role: String,
    val avatarUrl: String?,
    val isVerified: Boolean,
    val verificationColor: String?,
    val profileFrameUrl: String? = null
)

data class ConversationItem(
    val id: String,
    val title: String,
    val kind: String,
    val otherUserId: String?,
    val lastMessage: String,
    val lastMessageAt: String,
    val unreadCount: Int,
    val avatarUrl: String? = null,
    val profileFrameUrl: String? = null,
    val isVerified: Boolean = false,
    val verificationColor: String? = null
)

data class MessageItem(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val body: String,
    val messageType: String,
    val mediaUrl: String?,
    val fileName: String?,
    val createdAt: String,
    val editedAt: String?,
    val deletedAt: String?
)

data class EducationStage(
    val id: String,
    val name: String,
    val slug: String,
    val description: String,
    val sortOrder: Int
)

data class EducationLevel(
    val id: String,
    val stageId: String,
    val name: String,
    val slug: String,
    val sortOrder: Int
)

data class EducationSubject(
    val id: String,
    val name: String,
    val slug: String,
    val description: String
)

data class EducationMaterial(
    val id: String,
    val title: String,
    val description: String,
    val materialType: String,
    val fileUrl: String?,
    val externalUrl: String?,
    val createdAt: String
)

data class StoreProduct(
    val id: String,
    val name: String,
    val description: String,
    val productType: String,
    val priceMoney: Double,
    val currency: String,
    val priceDiamonds: Int,
    val allowMoney: Boolean,
    val allowDiamonds: Boolean,
    val imageUrl: String?,
    val frameKey: String? = null,
    val frameDurationDays: Int? = null
)

data class WalletSummary(
    val availableBalance: Double = 0.0,
    val heldBalance: Double = 0.0,
    val totalSpent: Double = 0.0,
    val diamonds: Int = 0
)

data class StoreOrder(
    val id: String,
    val productName: String,
    val paymentMethod: String,
    val moneyAmount: Double,
    val diamondAmount: Int,
    val status: String,
    val createdAt: String
)

data class AdminRecentUser(
    val id: String,
    val fullName: String,
    val username: String,
    val email: String,
    val role: String,
    val createdAt: String,
    val isVerified: Boolean
)

data class FeatureFlag(
    val id: String,
    val name: String,
    val key: String,
    val enabled: Boolean
)


data class SavedItem(
    val id: String,
    val contentType: String,
    val contentId: String,
    val createdAt: String
)

data class UniversityNode(
    val id: String,
    val name: String,
    val slug: String,
    val description: String,
    val parentId: String? = null
)

data class ProfileStats(
    val followers: Int = 0,
    val following: Int = 0,
    val posts: Int = 0
)

data class CommentItem(
    val id: String,
    val postId: String,
    val userId: String,
    val content: String,
    val createdAt: String,
    val authorName: String = "مستخدم"
)

data class OwnedProfileFrame(
    val id: String,
    val frameKey: String,
    val productId: String?,
    val source: String,
    val expiresAt: String?,
    val isActive: Boolean,
    val createdAt: String
)
