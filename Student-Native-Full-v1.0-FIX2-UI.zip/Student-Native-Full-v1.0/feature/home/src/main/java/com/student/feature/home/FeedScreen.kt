package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FeedScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    onOpenStories: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenEducation: () -> Unit
) {
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf(offline.loadPosts()) }
    var stories by remember { mutableStateOf(offline.loadStories()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            message = null
            val result = withContext(Dispatchers.IO) { api.feed(session) to api.stories(session) }
            result.first.onSuccess { fresh -> posts = fresh; offline.savePosts(fresh) }
                .onFailure { if (posts.isEmpty()) message = it.message ?: "تعذر تحميل المنشورات." }
            result.second.onSuccess { fresh -> stories = fresh; offline.saveStories(fresh) }
            loading = false
        }
    }

    LaunchedEffect(session.userId) { refresh() }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color.White),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            HomeStoriesStrip(stories = stories, profile = profile, onOpenStories = onOpenStories)
            HorizontalDivider(color = Color(0xFFECEFF2))
        }

        item {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 15.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.clickable(onClick = onOpenProfile)) {
                        Text("مرحبًا ${profile?.fullName ?: "بك"}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = StudentText)
                        Text("منصة Student التعليمية", fontSize = 12.sp, color = StudentMuted)
                    }
                    if (loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                }
                Spacer(Modifier.height(15.dp))
                EducationGrid(onOpenEducation)
            }
        }

        item {
            HorizontalDivider(color = Color(0xFFF0F2F5))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("آخر المنشورات", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = StudentText)
                TextButton(onClick = { refresh() }, enabled = !loading) { Text("تحديث", color = StudentBlue) }
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontSize = 12.sp) }
        }

        if (posts.isEmpty() && !loading) {
            item {
                Box(Modifier.fillMaxWidth().padding(vertical = 42.dp), contentAlignment = Alignment.Center) {
                    Text("لا توجد منشورات بعد.", color = StudentMuted)
                }
            }
        }
        items(posts, key = { it.id }) { post -> PostCard(api, session, post) }
    }
}

@Composable
private fun HomeStoriesStrip(stories: List<StoryItem>, profile: StudentProfile?, onOpenStories: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White).padding(top = 8.dp, bottom = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("القصص", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = StudentText)
            TextButton(onClick = onOpenStories, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("عرض الكل", color = StudentBlue) }
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(68.dp).clickable(onClick = onOpenStories)) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        StudentAvatar(profile?.fullName ?: "S", profile?.avatarUrl, profile?.profileFrameUrl, 58.dp)
                        Surface(modifier = Modifier.size(20.dp), shape = CircleShape, color = StudentBlue, border = BorderStroke(2.dp, Color.White)) {
                            Box(contentAlignment = Alignment.Center) { Text("+", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                    Text("قصتك", maxLines = 1, fontSize = 10.sp, color = StudentText)
                }
            }
            items(stories.take(15), key = { it.id }) { story ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(68.dp).clickable(onClick = onOpenStories)) {
                    Box(
                        modifier = Modifier
                            .size(66.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .padding(2.dp)
                            .border(2.dp, Color(0xFFED1C24), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!story.authorAvatarUrl.isNullOrBlank()) {
                            StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, 56.dp)
                        } else if (!story.mediaUrl.isNullOrBlank() && story.type.lowercase() == "image") {
                            AsyncImage(
                                model = story.mediaUrl,
                                contentDescription = "قصة",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(56.dp).clip(CircleShape)
                            )
                        } else {
                            StudentAvatar(story.authorName, null, null, 56.dp)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(story.authorName, maxLines = 1, fontSize = 10.sp, color = StudentText)
                        if (story.authorVerified) Spacer(Modifier.width(2.dp))
                        VerificationBadge(story.authorVerified, story.authorVerificationColor, size = 11.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun EducationGrid(onOpenEducation: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            EducationCard("🎓", "الابتدائي", Color(0xFFE9F6FF), Color(0xFF087CFF), Modifier.weight(1f), onOpenEducation)
            EducationCard("🏫", "الإعدادي", Color(0xFFF1EDFF), Color(0xFF7257D6), Modifier.weight(1f), onOpenEducation)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            EducationCard("📘", "الثانوي", Color(0xFFEAF9F1), Color(0xFF1B8B55), Modifier.weight(1f), onOpenEducation)
            EducationCard("🏛", "الجامعة", Color(0xFFFFF5DF), Color(0xFFB87512), Modifier.weight(1f), onOpenEducation)
        }
    }
}

@Composable
private fun EducationCard(icon: String, title: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(132.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, StudentBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Surface(modifier = Modifier.size(54.dp), shape = CircleShape, color = bg, border = BorderStroke(1.dp, fg.copy(alpha = 0.12f))) {
                Box(contentAlignment = Alignment.Center) { Text(icon, fontSize = 25.sp) }
            }
            Spacer(Modifier.height(10.dp))
            Text(title, color = StudentText, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PostCard(api: SupabaseApi, session: StudentSession, post: PostItem) {
    val uriHandler = LocalUriHandler.current
    val scope = rememberCoroutineScope()
    var savedMessage by remember { mutableStateOf<String?>(null) }
    var liked by remember { mutableStateOf(false) }
    var showComments by remember { mutableStateOf(false) }
    var comments by remember { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentText by remember { mutableStateOf("") }

    LaunchedEffect(post.id) {
        liked = withContext(Dispatchers.IO) { api.isPostLiked(session, post.id).getOrDefault(false) }
    }

    if (showComments) {
        AlertDialog(
            onDismissRequest = { showComments = false },
            title = { Text("التعليقات") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (comments.isEmpty()) Text("لا توجد تعليقات بعد.", color = StudentMuted)
                    comments.takeLast(8).forEach { c -> Text("${c.authorName}: ${c.content}", style = MaterialTheme.typography.bodyMedium) }
                    OutlinedTextField(commentText, { commentText = it }, placeholder = { Text("أضف تعليقًا") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    val body = commentText.trim()
                    if (body.isBlank()) return@Button
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { api.addComment(session, post.id, body) }
                        r.onSuccess {
                            commentText = ""
                            comments = withContext(Dispatchers.IO) { api.comments(session, post.id).getOrDefault(comments) }
                        }
                    }
                }) { Text("إرسال") }
            },
            dismissButton = { TextButton(onClick = { showComments = false }) { Text("إغلاق") } }
        )
    }

    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE9EDF3)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StudentAvatar(post.authorName, post.authorAvatarUrl, post.authorFrameUrl, 42.dp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    StudentName(post.authorName, post.authorVerified, post.authorVerificationColor)
                    Text("@${post.authorUsername}", style = MaterialTheme.typography.labelMedium, color = StudentMuted)
                }
            }
            if (post.content.isNotBlank()) {
                Spacer(Modifier.height(11.dp))
                Text(post.content, style = MaterialTheme.typography.bodyLarge, color = StudentText)
            }
            post.mediaUrl?.let { url ->
                Spacer(Modifier.height(10.dp))
                if (post.postType.lowercase() == "image") {
                    AsyncImage(
                        model = url,
                        contentDescription = "صورة المنشور",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 420.dp).clip(RoundedCornerShape(13.dp)).clickable { runCatching { uriHandler.openUri(url) } }
                    )
                } else {
                    OutlinedButton(onClick = { runCatching { uriHandler.openUri(url) } }) { Text("فتح الوسائط") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = {
                    scope.launch {
                        val next = !liked
                        val r = withContext(Dispatchers.IO) { api.setPostLiked(session, post.id, next) }
                        if (r.isSuccess) liked = next
                    }
                }) { Text(if (liked) "♥ إعجاب" else "♡ إعجاب", color = if (liked) Color(0xFFED1C24) else StudentText) }
                TextButton(onClick = {
                    scope.launch {
                        comments = withContext(Dispatchers.IO) { api.comments(session, post.id).getOrDefault(emptyList()) }
                        showComments = true
                    }
                }) { Text("تعليقات", color = StudentText) }
                TextButton(onClick = {
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { api.saveItem(session, "post", post.id) }
                        savedMessage = if (r.isSuccess) "تم الحفظ" else if ((r.exceptionOrNull()?.message ?: "").contains("duplicate", true)) "محفوظ" else "تعذر الحفظ"
                    }
                }) { Text("☆ حفظ", color = StudentText) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(prettyTime(post.createdAt), style = MaterialTheme.typography.labelSmall, color = StudentMuted)
                savedMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = StudentBlue) }
            }
        }
    }
}

internal fun prettyTime(raw: String): String {
    if (raw.isBlank()) return ""
    return raw.replace("T", " ").take(16)
}
