package com.student.feature.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

val StudentBlue = Color(0xFF0095F6)
val StudentBlueDark = Color(0xFF087CFF)
val StudentText = Color(0xFF262626)
val StudentMuted = Color(0xFF77818C)
val StudentBorder = Color(0xFFDBDBDB)
val StudentSoft = Color(0xFFF7F9FB)
val StudentMessageBg = Color(0xFFF4F7FB)

@Composable
fun VerificationBadge(
    verified: Boolean,
    colorName: String?,
    modifier: Modifier = Modifier,
    size: Dp = 18.dp
) {
    if (!verified) return
    val color = when (colorName?.lowercase()) {
        "orange" -> Color(0xFFFF8A00)
        "red" -> Color(0xFFE53935)
        "blue" -> StudentBlue
        "green" -> Color(0xFF1B8B55)
        "purple" -> Color(0xFF7C3AED)
        else -> StudentBlue
    }
    Surface(
        modifier = modifier.size(size),
        shape = CircleShape,
        color = color
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text("✓", color = Color.White, fontSize = (size.value * 0.62f).sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun StudentAvatar(
    name: String,
    avatarUrl: String?,
    frameUrl: String? = null,
    size: Dp = 52.dp,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.size(size + 10.dp), contentAlignment = Alignment.Center) {
        if (!avatarUrl.isNullOrBlank()) {
            AsyncImage(
                model = avatarUrl,
                contentDescription = "صورة الحساب",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(Color(0xFFEAF2FF))
            )
        } else {
            Surface(
                modifier = Modifier.size(size),
                shape = CircleShape,
                color = Color(0xFFEAF2FF)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        name.trim().firstOrNull()?.toString()?.uppercase() ?: "S",
                        color = Color(0xFF47709F),
                        fontSize = (size.value * 0.36f).sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
        if (!frameUrl.isNullOrBlank()) {
            if (frameUrl.startsWith("student-frame:")) {
                NativeProfileFrame(frameUrl.substringAfter("student-frame:"), Modifier.fillMaxSize())
            } else {
                AsyncImage(
                    model = frameUrl,
                    contentDescription = "إطار الحساب",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun StudentName(
    name: String,
    verified: Boolean,
    verificationColor: String?,
    modifier: Modifier = Modifier,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.titleMedium
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(name, style = style, fontWeight = FontWeight.Bold, color = StudentText)
        VerificationBadge(verified, verificationColor)
    }
}


@Composable
fun CustomProfileBadge(label: String?, colorValue: String?, modifier: Modifier = Modifier) {
    if (label.isNullOrBlank()) return
    val bg = runCatching { Color(android.graphics.Color.parseColor(colorValue ?: "#7c3aed")) }.getOrDefault(Color(0xFF7C3AED))
    Surface(modifier = modifier, shape = RoundedCornerShape(999.dp), color = bg.copy(alpha = 0.12f), border = androidx.compose.foundation.BorderStroke(1.dp, bg.copy(alpha = 0.28f))) {
        Text(label, color = bg, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}

@Composable
fun StudentOutlinedCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE9EDF3)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        content = content
    )
}

@Composable
fun StudentLogo() {
    Text(
        "Student",
        color = StudentBlue,
        fontSize = 25.sp,
        fontWeight = FontWeight.Black,
        fontStyle = FontStyle.Italic
    )
}


@Composable
private fun NativeProfileFrame(frameKey: String, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "studentFrame")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(2600, easing = LinearEasing)),
        label = "frameRotation"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(900), repeatMode = RepeatMode.Reverse),
        label = "framePulse"
    )
    val colors = when (frameKey.lowercase()) {
        "fire" -> listOf(Color(0xFFFFD54F), Color(0xFFFF6D00), Color(0xFFE53935), Color(0xFFFFD54F))
        "blue-fire" -> listOf(Color(0xFF80D8FF), Color(0xFF2979FF), Color(0xFF00E5FF), Color(0xFF80D8FF))
        "neon" -> listOf(Color(0xFFFF00E5), Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFFFF00E5))
        "lightning" -> listOf(Color(0xFFFFEA00), Color(0xFFFFFFFF), Color(0xFF2979FF), Color(0xFFFFEA00))
        "royal" -> listOf(Color(0xFFFFF3B0), Color(0xFFFFC107), Color(0xFFB8860B), Color(0xFFFFF3B0))
        "ember" -> listOf(Color(0xFFFF8A65), Color(0xFFBF360C), Color(0xFFFFCA28), Color(0xFFFF8A65))
        else -> listOf(StudentBlue, Color(0xFF7C3AED), StudentBlue)
    }
    Canvas(modifier = modifier.rotate(rotation)) {
        drawCircle(
            brush = Brush.sweepGradient(colors),
            radius = size.minDimension / 2f - 3.dp.toPx(),
            style = Stroke(width = 4.dp.toPx()),
            alpha = pulse
        )
        drawCircle(
            color = colors[1].copy(alpha = 0.25f),
            radius = size.minDimension / 2f - 7.dp.toPx(),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}
