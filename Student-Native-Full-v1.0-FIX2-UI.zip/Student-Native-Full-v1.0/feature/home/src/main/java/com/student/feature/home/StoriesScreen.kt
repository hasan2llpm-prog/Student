package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StoriesScreen(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            message = null
            val r = withContext(Dispatchers.IO) { api.stories(session, 80) }
            r.onSuccess { stories = it }.onFailure { message = it.message }
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("قصص Student", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            TextButton(onClick = { refresh() }) { Text("تحديث", color = StudentBlue) }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp), fontSize = 12.sp) }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(stories, key = { it.id }) { story ->
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE9EDF3)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, 44.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                StudentName(story.authorName, story.authorVerified, story.authorVerificationColor)
                                Text(prettyTime(story.createdAt), color = StudentMuted, fontSize = 10.sp)
                            }
                        }
                        if (story.content.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Text(story.content, color = StudentText, lineHeight = 22.sp)
                        }
                        story.mediaUrl?.let { url ->
                            Spacer(Modifier.height(10.dp))
                            if (story.type.lowercase() == "image") {
                                AsyncImage(
                                    model = url,
                                    contentDescription = "صورة القصة",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 220.dp, max = 520.dp)
                                        .clip(RoundedCornerShape(15.dp))
                                        .clickable { runCatching { uri.openUri(url) } }
                                )
                            } else {
                                OutlinedButton(onClick = { runCatching { uri.openUri(url) } }) {
                                    Text(when (story.type.lowercase()) { "video" -> "فتح الفيديو"; "audio" -> "تشغيل الصوت"; else -> "فتح الوسائط" })
                                }
                            }
                        }
                    }
                }
            }
            if (stories.isEmpty() && !loading) {
                item {
                    Box(Modifier.fillMaxWidth().padding(vertical = 60.dp), contentAlignment = Alignment.Center) {
                        Text("لا توجد قصص حاليًا.", color = StudentMuted)
                    }
                }
            }
        }
    }
}
