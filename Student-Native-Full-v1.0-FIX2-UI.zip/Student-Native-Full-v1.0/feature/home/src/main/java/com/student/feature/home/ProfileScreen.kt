package com.student.feature.home

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ProfileScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    loadingProfile: Boolean,
    onProfileChanged: (StudentProfile) -> Unit,
    onRefreshProfile: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var editing by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("public") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var stats by remember { mutableStateOf(ProfileStats()) }

    BackHandler(enabled = editing) { editing = false; message = null }

    LaunchedEffect(profile?.id, profile?.fullName, profile?.username, profile?.bio, profile?.accountStatus) {
        profile?.let {
            fullName = it.fullName
            username = it.username
            bio = it.bio
            status = it.accountStatus
            val r = withContext(Dispatchers.IO) { api.profileStats(session, it.id) }
            r.onSuccess { value -> stats = value }
        }
    }

    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        if (picked != null && profile != null) {
            scope.launch {
                busy = true
                message = null
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val bytes = context.contentResolver.openInputStream(picked)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الصورة.")
                        if (bytes.size > 5 * 1024 * 1024) throw IllegalStateException("الصورة يجب أن تكون أقل من 5MB.")
                        val mime = context.contentResolver.getType(picked) ?: "image/jpeg"
                        val ext = when {
                            mime.contains("png") -> "png"
                            mime.contains("webp") -> "webp"
                            else -> "jpg"
                        }
                        val path = "${session.userId}/${System.currentTimeMillis()}.$ext"
                        val url = api.uploadObject(session, "avatars", path, bytes, mime).getOrThrow()
                        api.updateAvatar(session, url).getOrThrow()
                        api.profile(session).getOrThrow()
                    }
                }
                result.onSuccess {
                    onProfileChanged(it)
                    message = "تم تحديث صورة الحساب."
                }.onFailure { message = it.message ?: "تعذر تحديث الصورة." }
                busy = false
            }
        }
    }

    if (loadingProfile || profile == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator()
                Text("جارٍ تحميل الملف الشخصي...", color = StudentMuted)
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE9EDF3)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    StudentAvatar(profile.fullName, profile.avatarUrl, profile.profileFrameUrl, 92.dp)
                    Spacer(Modifier.height(8.dp))
                    StudentName(
                        profile.fullName,
                        profile.isVerified,
                        profile.verificationColor,
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text("@${profile.username}", color = StudentMuted, fontSize = 13.sp)
                    if (!profile.customBadgeLabel.isNullOrBlank()) {
                        Spacer(Modifier.height(5.dp))
                        CustomProfileBadge(profile.customBadgeLabel, profile.customBadgeColor)
                    }
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = if (profile.accountStatus == "private") Color(0xFFFFF5DF) else Color(0xFFEAF9F1)
                    ) {
                        Text(
                            if (profile.accountStatus == "private") "حساب خاص" else "حساب عام",
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                            fontSize = 11.sp,
                            color = if (profile.accountStatus == "private") Color(0xFF8A5A0A) else Color(0xFF1B6F47)
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = Color(0xFFF0F2F5))
                    Row(Modifier.fillMaxWidth().padding(top = 13.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ProfileStat(stats.posts, "المنشورات")
                        ProfileStat(stats.followers, "المتابعون")
                        ProfileStat(stats.following, "يتابع")
                    }
                    Spacer(Modifier.height(14.dp))

                    if (!editing) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            Button(onClick = { editing = true }, modifier = Modifier.weight(1f)) { Text("تعديل الملف") }
                            OutlinedButton(onClick = { avatarPicker.launch("image/*") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("تغيير الصورة") }
                        }
                    }
                }
            }
        }

        if (profile.bio.isNotBlank() && !editing) {
            item {
                StudentOutlinedCard(Modifier.fillMaxWidth()) {
                    Text("نبذة", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 15.dp))
                    Text(profile.bio, color = Color(0xFF44515F), lineHeight = 23.sp, modifier = Modifier.padding(16.dp))
                }
            }
        }

        if (!editing) {
            item {
                StudentOutlinedCard(Modifier.fillMaxWidth()) {
                    Text("معلومات الحساب", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 15.dp))
                    Text(profile.email, color = StudentMuted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
                }
            }
            item {
                OutlinedButton(onClick = onRefreshProfile, modifier = Modifier.fillMaxWidth()) { Text("تحديث بيانات الملف") }
            }
        } else {
            item {
                StudentOutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                        Text("تعديل الملف الشخصي", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        OutlinedTextField(fullName, { fullName = it }, label = { Text("الاسم الكامل") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(username, { username = it }, label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(bio, { bio = it }, label = { Text("النبذة") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                        Text("خصوصية الحساب", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = status == "public", onClick = { status = "public" }, label = { Text("عام") })
                            FilterChip(selected = status == "private", onClick = { status = "private" }, label = { Text("خاص") })
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    scope.launch {
                                        busy = true
                                        message = null
                                        val r = withContext(Dispatchers.IO) { api.updateProfile(session, fullName.trim(), username.trim(), bio.trim(), status) }
                                        if (r.isSuccess) {
                                            val fresh = withContext(Dispatchers.IO) { api.profile(session) }
                                            fresh.onSuccess {
                                                onProfileChanged(it)
                                                editing = false
                                                message = "تم حفظ التعديلات."
                                            }.onFailure { message = it.message }
                                        } else message = r.exceptionOrNull()?.message
                                        busy = false
                                    }
                                },
                                enabled = !busy && fullName.isNotBlank() && username.isNotBlank(),
                                modifier = Modifier.weight(1f)
                            ) { Text(if (busy) "جارٍ الحفظ..." else "حفظ") }
                            OutlinedButton(onClick = { editing = false }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                        }
                    }
                }
            }
        }

        message?.let {
            item {
                Text(
                    it,
                    color = if (it.startsWith("تم")) Color(0xFF16803C) else MaterialTheme.colorScheme.error,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun ProfileStat(value: Int, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.toString(), fontWeight = FontWeight.Black, fontSize = 18.sp, color = StudentText)
        Text(label, fontSize = 11.sp, color = StudentMuted)
    }
}
