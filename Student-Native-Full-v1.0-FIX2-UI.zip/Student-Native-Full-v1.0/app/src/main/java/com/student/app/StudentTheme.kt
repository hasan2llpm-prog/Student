package com.student.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

private val StudentLightColors = lightColorScheme(
    primary = Color(0xFF0095F6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE9F6FF),
    onPrimaryContainer = Color(0xFF123A5A),
    secondary = Color(0xFF087CFF),
    secondaryContainer = Color(0xFFEAF2FF),
    background = Color.White,
    onBackground = Color(0xFF262626),
    surface = Color.White,
    onSurface = Color(0xFF262626),
    surfaceVariant = Color(0xFFF4F7FB),
    onSurfaceVariant = Color(0xFF6B7280),
    outline = Color(0xFFDBDBDB),
    error = Color(0xFFC62828),
    errorContainer = Color(0xFFFFEBEE)
)

@Composable
fun StudentTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = StudentLightColors, content = content)
    }
}
