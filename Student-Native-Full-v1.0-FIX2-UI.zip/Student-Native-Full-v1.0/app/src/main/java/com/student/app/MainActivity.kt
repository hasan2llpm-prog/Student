package com.student.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.google.firebase.messaging.FirebaseMessaging
import com.student.core.data.*
import com.student.feature.auth.AuthScreen
import com.student.feature.home.HomeScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val api = SupabaseApi()
    private lateinit var store: SessionStore
    private lateinit var offline: OfflineStore

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SessionStore(this)
        offline = OfflineStore(this)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            StudentTheme {
                Surface(Modifier.fillMaxSize()) { StudentRoot() }
            }
        }
    }

    @Composable
    private fun StudentRoot() {
        val scope = rememberCoroutineScope()
        var session by remember { mutableStateOf<StudentSession?>(store.load()) }
        var profile by remember { mutableStateOf(offline.loadProfile()) }
        var busy by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }
        var offlineMode by remember { mutableStateOf(false) }

        fun loadProfile(current: StudentSession) {
            scope.launch {
                busy = true
                val pair = withContext(Dispatchers.IO) {
                    var active = current
                    var result = api.profile(active)
                    if (result.isFailure && active.refreshToken.isNotBlank()) {
                        api.refresh(active.refreshToken).getOrNull()?.let { fresh ->
                            active = fresh
                            store.save(fresh)
                            result = api.profile(fresh)
                        }
                    }
                    active to result
                }
                session = pair.first
                val freshProfile = pair.second.getOrNull()
                if (freshProfile != null) {
                    profile = freshProfile
                    offline.saveProfile(freshProfile)
                    offlineMode = false
                    val flushed = withContext(Dispatchers.IO) { offline.flushPending(api, pair.first) }
                    message = if (flushed > 0) "تمت مزامنة $flushed عملية محفوظة من وضع Offline." else null
                } else {
                    val cached = offline.loadProfile()
                    if (cached != null) {
                        profile = cached
                        offlineMode = true
                        message = "وضع Offline: نعرض آخر بيانات محفوظة."
                    } else {
                        message = pair.second.exceptionOrNull()?.message ?: "تعذر تحميل الحساب."
                    }
                }
                busy = false
                registerPush(session ?: current)
            }
        }

        LaunchedEffect(session?.accessToken) {
            session?.let { loadProfile(it) }
        }

        if (session == null) {
            AuthScreen(
                busy = busy,
                message = message,
                onLogin = { email, password ->
                    scope.launch {
                        busy = true
                        message = null
                        val result = withContext(Dispatchers.IO) { api.login(email, password) }
                        result.onSuccess {
                            store.save(it)
                            session = it
                        }.onFailure { message = it.message ?: "تعذر تسجيل الدخول." }
                        busy = false
                    }
                },
                onRegister = { name, email, password ->
                    scope.launch {
                        busy = true
                        message = null
                        val result = withContext(Dispatchers.IO) { api.register(name, email, password) }
                        result.onSuccess { created ->
                            if (created == null) message = "تم إنشاء الحساب. أكّد البريد ثم سجّل الدخول."
                            else {
                                store.save(created)
                                session = created
                            }
                        }.onFailure { message = it.message ?: "تعذر إنشاء الحساب." }
                        busy = false
                    }
                }
            )
        } else {
            HomeScreen(
                api = api,
                session = session!!,
                profile = profile,
                loadingProfile = busy,
                offlineMode = offlineMode,
                rootMessage = message,
                onProfileChanged = { fresh ->
                    profile = fresh
                    offline.saveProfile(fresh)
                },
                onRefreshProfile = { session?.let { loadProfile(it) } },
                onLogout = {
                    store.clear()
                    offline.clear()
                    profile = null
                    session = null
                    message = null
                    offlineMode = false
                },
                onExitApp = { finishAndRemoveTask() }
            )
        }
    }

    private fun registerPush(session: StudentSession) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            getSharedPreferences("student_push", MODE_PRIVATE).edit().putString("fcm_token", token).apply()
            Thread { api.registerPushToken(session, token) }.start()
        }
    }
}
