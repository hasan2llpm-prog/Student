package com.student.app

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.student.core.data.StudentConfig

class StudentApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (FirebaseApp.getApps(this).isEmpty()) {
            runCatching {
                val options = FirebaseOptions.Builder()
                    .setProjectId(StudentConfig.FIREBASE_PROJECT_ID)
                    .setGcmSenderId(StudentConfig.FIREBASE_SENDER_ID)
                    .setApiKey(StudentConfig.FIREBASE_API_KEY)
                    .setApplicationId(StudentConfig.FIREBASE_APP_ID)
                    .build()
                FirebaseApp.initializeApp(this, options)
            }
        }
    }
}
