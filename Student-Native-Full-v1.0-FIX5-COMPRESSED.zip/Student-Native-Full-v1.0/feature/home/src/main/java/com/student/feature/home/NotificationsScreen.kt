package com.student.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun NotificationsScreen(api: SupabaseApi, session: StudentSession, onOpenTarget: (String) -> Unit = {}) {
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(offline.loadNotifications()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            val r = withContext(Dispatchers.IO) { api.notifications(session) }
            r.onSuccess { fresh -> items = fresh; offline.saveNotifications(fresh); message = null }
                .onFailure { message = if (items.isEmpty()) it.message else "Offline: آخر إشعارات محفوظة" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("الإشعارات", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { refresh() }, enabled = !loading) { Text("تحديث") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, Modifier.padding(horizontal = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.id }) { n ->
                ElevatedCard(
                    Modifier.fillMaxWidth().clickable {
                        if (!n.isRead) {
                            scope.launch {
                                withContext(Dispatchers.IO) { api.markNotificationRead(session, n.id) }
                                items = items.map { if (it.id == n.id) it.copy(isRead = true) else it }
                                offline.saveNotifications(items)
                            }
                        }
                        onOpenTarget(n.link?.takeIf { it.isNotBlank() } ?: n.kind)
                    }
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(n.title, style = MaterialTheme.typography.titleMedium)
                            if (!n.isRead) Badge { Text("جديد") }
                        }
                        if (n.body.isNotBlank()) Text(n.body, style = MaterialTheme.typography.bodyMedium)
                        Text(prettyTime(n.createdAt), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (items.isEmpty() && !loading) item { Text("لا توجد إشعارات.") }
        }
    }
}
