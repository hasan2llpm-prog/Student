package com.student.feature.home

import kotlinx.coroutines.delay
import android.net.Uri
import android.widget.VideoView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StoriesScreen(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val uri = LocalUriHandler.current
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var createOpen by remember { mutableStateOf(false) }
    var storyText by remember { mutableStateOf("") }
    var interaction by remember { mutableStateOf<StoryItem?>(null) }
    var deleteStory by remember { mutableStateOf<StoryItem?>(null) }
    var viewerIndex by remember { mutableIntStateOf(-1) }

    fun refresh() {
        scope.launch {
            loading = true
            message = null
            val r = withContext(Dispatchers.IO) { api.stories(session, 80) }
            r.onSuccess { stories = it }.onFailure { message = it.message }
            loading = false
        }
    }

    fun publishMedia(uriValue: android.net.Uri) {
        scope.launch {
            loading = true
            message = null
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val mime = context.contentResolver.getType(uriValue) ?: "application/octet-stream"
                    val type = when {
                        mime.startsWith("image/") -> "image"
                        mime.startsWith("video/") -> "video"
                        else -> throw IllegalStateException("القصص تدعم الصور والفيديو فقط.")
                    }
                    val bytes = context.contentResolver.openInputStream(uriValue)?.use { it.readBytes() }
                        ?: throw IllegalStateException("تعذر قراءة الملف.")
                    if (bytes.size > 30 * 1024 * 1024) throw IllegalStateException("الحد الأقصى لوسائط القصة 30MB.")
                    val ext = if (type == "image") "jpg" else "mp4"
                    val path = "${session.userId}/${System.currentTimeMillis()}_story.$ext"
                    val url = api.uploadObject(session, "stories", path, bytes, mime).getOrThrow()
                    api.createStory(session, storyText.trim(), url, type).getOrThrow()
                }
            }
            loading = false
            result.onSuccess { storyText = ""; createOpen = false; message = "تم نشر القصة."; refresh() }
                .onFailure { message = it.message }
        }
    }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        if (picked != null) publishMedia(picked)
    }

    LaunchedEffect(Unit) { refresh() }

    if (createOpen) {
        AlertDialog(
            onDismissRequest = { if (!loading) createOpen = false },
            title = { Text("قصة جديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        storyText,
                        { storyText = it.take(1200) },
                        label = { Text("نص القصة — اختياري مع الوسائط") },
                        modifier = Modifier.fillMaxWidth(), minLines = 4
                    )
                    OutlinedButton(onClick = { mediaPicker.launch("*/*") }, modifier = Modifier.fillMaxWidth(), enabled = !loading) {
                        Icon(Icons.Rounded.PermMedia, null); Spacer(Modifier.width(6.dp)); Text("اختيار صورة أو فيديو")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (storyText.isBlank()) return@Button
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.createTextStory(session, storyText.trim()) }
                            loading = false
                            r.onSuccess { storyText = ""; createOpen = false; message = "تم نشر القصة."; refresh() }.onFailure { message = it.message }
                        }
                    }, enabled = storyText.isNotBlank() && !loading
                ) { Text("نشر نص") }
            },
            dismissButton = { TextButton(onClick = { createOpen = false }, enabled = !loading) { Text("إلغاء") } }
        )
    }

    interaction?.let { story ->
        StoryInteractionDialog(api, session, story, onDismiss = { interaction = null }) { msg -> message = msg }
    }

    deleteStory?.let { story ->
        AlertDialog(
            onDismissRequest = { if (!loading) deleteStory = null },
            title = { Text("حذف القصة") },
            text = { Text("هل تريد حذف هذه القصة نهائيًا؟") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.deleteStory(session, story.id) }
                            loading = false
                            r.onSuccess { deleteStory = null; message = "تم حذف القصة."; refresh() }.onFailure { message = it.message }
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleteStory = null }, enabled = !loading) { Text("إلغاء") } }
        )
    }

    if (viewerIndex >= 0 && stories.isNotEmpty()) {
        InstagramStoryViewer(
            stories = stories,
            startIndex = viewerIndex.coerceIn(0, stories.lastIndex),
            session = session,
            api = api,
            onClose = { viewerIndex = -1 },
            onInteract = { interaction = it },
            onDelete = { deleteStory = it }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("قصص Student", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("نص، صور وفيديو لمدة 24 ساعة", color = StudentMuted, fontSize = 11.sp)
            }
            Row {
                IconButton(onClick = { refresh() }) { Icon(Icons.Rounded.Refresh, "تحديث") }
                FilledIconButton(onClick = { createOpen = true }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = StudentBlue)) {
                    Icon(Icons.Rounded.Add, "إضافة قصة", tint = Color.White)
                }
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudentBlue)
        message?.let { Text(it, color = if (it.startsWith("تم")) Color(0xFF16803C) else MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp), fontSize = 12.sp) }
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(stories, key = { it.id }) { story ->
                val index = stories.indexOfFirst { it.id == story.id }
                Column(
                    modifier = Modifier.width(86.dp).clickable { viewerIndex = index },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(78.dp).clip(CircleShape).border(3.dp, Color(0xFFEF233C), CircleShape).padding(4.dp)) {
                        StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, 68.dp)
                    }
                    Text(story.authorName, maxLines = 1, fontSize = 12.sp)
                }
            }
        }
        if (stories.isEmpty() && !loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد قصص حاليًا.", color = StudentMuted) }
        } else {
            Text("اضغط على أي قصة ثم مرّر لليسار أو اليمين للتنقل مثل Instagram.", color = StudentMuted, fontSize = 12.sp, modifier = Modifier.padding(16.dp))
        }

    }
}

@Composable
private fun InstagramStoryViewer(
    stories: List<StoryItem>,
    startIndex: Int,
    session: StudentSession,
    api: SupabaseApi,
    onClose: () -> Unit,
    onInteract: (StoryItem) -> Unit,
    onDelete: (StoryItem) -> Unit
) {
    var index by remember(startIndex) { mutableIntStateOf(startIndex) }
    var drag by remember { mutableFloatStateOf(0f) }
    val story = stories[index]

    fun previous() { if (index > 0) index-- else onClose() }
    fun next() { if (index < stories.lastIndex) index++ else onClose() }

    BackHandler(onBack = onClose)
    LaunchedEffect(story.id) {
        if (story.userId != session.userId) withContext(Dispatchers.IO) { api.markStoryViewed(session, story.id) }
        delay(if (story.type.equals("video", true)) 10000 else 6000)
        next()
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(story.id) {
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onHorizontalDrag = { _, amount -> drag += amount },
                    onDragEnd = {
                        if (drag < -70f) next() else if (drag > 70f) previous()
                        drag = 0f
                    }
                )
            }
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            stories.forEachIndexed { i, _ ->
                LinearProgressIndicator(
                    progress = { if (i < index) 1f else if (i == index) .55f else 0f },
                    modifier = Modifier.weight(1f).height(3.dp),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = .28f)
                )
            }
        }

        when {
            story.type.equals("image", true) && !story.mediaUrl.isNullOrBlank() -> AsyncImage(
                model = story.mediaUrl,
                contentDescription = "قصة ${story.authorName}",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(top = 18.dp, bottom = 62.dp)
            )
            story.type.equals("video", true) && !story.mediaUrl.isNullOrBlank() -> AndroidView(
                factory = { context ->
                    VideoView(context).apply {
                        setVideoURI(Uri.parse(story.mediaUrl))
                        setOnPreparedListener { player -> player.isLooping = false; start() }
                    }
                },
                update = { view ->
                    if (view.tag != story.mediaUrl) {
                        view.tag = story.mediaUrl
                        view.setVideoURI(Uri.parse(story.mediaUrl))
                        view.start()
                    }
                },
                modifier = Modifier.fillMaxSize().padding(top = 18.dp, bottom = 62.dp)
            )
            else -> Box(
                Modifier.fillMaxSize().background(Color(0xFF402060)).padding(38.dp),
                contentAlignment = Alignment.Center
            ) { Text(story.content, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 38.sp) }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 18.dp, start = 12.dp, end = 8.dp).align(Alignment.TopCenter),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, 38.dp)
            Spacer(Modifier.width(7.dp))
            Column(Modifier.weight(1f)) {
                StudentName(story.authorName, story.authorVerified, story.authorVerificationColor, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                Text(prettyTime(story.createdAt), color = Color.White.copy(alpha = .75f), fontSize = 10.sp)
            }
            if (story.userId == session.userId) {
                IconButton(onClick = { onDelete(story) }) { Icon(Icons.Rounded.DeleteOutline, "حذف", tint = Color.White) }
            }
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "إغلاق", tint = Color.White) }
        }

        Row(
            Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            FilledTonalButton(onClick = { previous() }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color.White.copy(alpha=.16f), contentColor = Color.White)) { Icon(Icons.Rounded.ChevronRight, "السابق") }
            FilledTonalButton(onClick = { onInteract(story) }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color.White.copy(alpha=.16f), contentColor = Color.White)) {
                Icon(Icons.Rounded.FavoriteBorder, null); Spacer(Modifier.width(6.dp)); Text(if (story.userId == session.userId) "المشاهدات والردود" else "رد وتفاعل")
            }
            FilledTonalButton(onClick = { next() }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color.White.copy(alpha=.16f), contentColor = Color.White)) { Icon(Icons.Rounded.ChevronLeft, "التالي") }
        }
    }
}

@Composable
private fun StoryInteractionDialog(
    api: SupabaseApi,
    session: StudentSession,
    story: StoryItem,
    onDismiss: () -> Unit,
    onMessage: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val owner = story.userId == session.userId
    var reaction by remember(story.id) { mutableStateOf<String?>(null) }
    var replies by remember(story.id) { mutableStateOf<List<StoryReplyItem>>(emptyList()) }
    var viewers by remember(story.id) { mutableStateOf<List<ProfileSearchItem>>(emptyList()) }
    var reply by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(true) }

    fun refresh() {
        scope.launch {
            busy = true
            if (!owner) reaction = withContext(Dispatchers.IO) { api.myStoryReaction(session, story.id).getOrNull() }
            replies = withContext(Dispatchers.IO) { api.storyReplies(session, story.id).getOrDefault(emptyList()) }
            if (owner) viewers = withContext(Dispatchers.IO) { api.storyViewers(session, story.id).getOrDefault(emptyList()) }
            busy = false
        }
    }
    LaunchedEffect(story.id) { refresh() }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(if (owner) "تفاصيل القصة" else "تفاعل مع القصة") },
        text = {
            Column(Modifier.heightIn(max = 480.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudentBlue)
                if (!owner) {
                    Text("التفاعل", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf(
                            "like" to Icons.Rounded.ThumbUp,
                            "love" to Icons.Rounded.Favorite,
                            "wow" to Icons.Rounded.SentimentVerySatisfied
                        ).forEach { (value, icon) ->
                            FilterChip(
                                selected = reaction == value,
                                onClick = {
                                    val next = if (reaction == value) null else value
                                    scope.launch {
                                        val r = withContext(Dispatchers.IO) { api.setStoryReaction(session, story.id, next) }
                                        r.onSuccess { reaction = next }.onFailure { onMessage(it.message ?: "تعذر حفظ التفاعل.") }
                                    }
                                },
                                label = { Icon(icon, value, Modifier.size(18.dp)) }
                            )
                        }
                    }
                    OutlinedTextField(reply, { reply = it.take(1000) }, label = { Text("اكتب ردًا") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Button(
                        onClick = {
                            if (reply.isBlank()) return@Button
                            scope.launch {
                                busy = true
                                val r = withContext(Dispatchers.IO) { api.replyToStory(session, story.id, reply.trim()) }
                                busy = false
                                r.onSuccess { reply = ""; onMessage("تم إرسال الرد."); refresh() }.onFailure { onMessage(it.message ?: "تعذر إرسال الرد.") }
                            }
                        }, enabled = reply.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth()
                    ) { Text("إرسال الرد") }
                } else {
                    Text("المشاهدات: ${viewers.size}", fontWeight = FontWeight.Bold)
                    viewers.take(8).forEach { viewer ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StudentAvatar(viewer.fullName, viewer.avatarUrl, viewer.profileFrameUrl, 30.dp)
                            Spacer(Modifier.width(6.dp))
                            StudentName(viewer.fullName, viewer.isVerified, viewer.verificationColor, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    HorizontalDivider()
                    Text("الردود: ${replies.size}", fontWeight = FontWeight.Bold)
                    replies.takeLast(10).forEach { item -> Text("${item.authorName}: ${item.message}", color = StudentText) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("إغلاق") } }
    )
}
