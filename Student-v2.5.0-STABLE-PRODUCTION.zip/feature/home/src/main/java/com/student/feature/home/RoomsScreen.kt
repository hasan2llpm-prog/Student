package com.student.feature.home

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.student.core.data.*
import io.livekit.android.LiveKit
import io.livekit.android.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun RoomsScreen(
    api: SupabaseApi,
    session: StudentSession,
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit
) {
    var selected by remember { mutableStateOf<VoiceRoomItem?>(null) }
    if (selected != null) {
        VoiceRoomDetailScreen(api, session, selected!!, onBack = { selected = null }, onOpenProfile = onOpenProfile)
    } else {
        VoiceRoomsDiscovery(api, session, onBack = onBack, onOpenRoom = { selected = it })
    }
}

@Composable
private fun VoiceRoomsDiscovery(api: SupabaseApi, session: StudentSession, onBack: () -> Unit, onOpenRoom: (VoiceRoomItem) -> Unit) {
    val scope = rememberCoroutineScope()
    var rooms by remember { mutableStateOf<List<VoiceRoomItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var showCreate by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("discover") }
    var error by remember { mutableStateOf<String?>(null) }

    fun reload() {
        scope.launch {
            loading = true
            withContext(Dispatchers.IO) { api.voiceRooms(session, query) }
                .onSuccess { rooms = it; error = null }
                .onFailure { error = friendlyRoomError(it.message) }
            loading = false
        }
    }
    LaunchedEffect(query) { delay(250); reload() }

    Column(Modifier.fillMaxSize().background(Color(0xFFF8F9FC))) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "رجوع") }
            Text("الغرف", fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            FilledTonalIconButton(onClick = { showCreate = true }) { Icon(Icons.Rounded.Add, "إنشاء غرفة") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it.take(80) },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            placeholder = { Text("بحث") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)
        )
        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            FilterChip(selected=tab=="discover",onClick={tab="discover"},label={Text("اكتشاف")})
            FilterChip(selected=tab=="popular",onClick={tab="popular"},label={Text("شائعة")})
            FilterChip(selected=tab=="saved",onClick={tab="saved"},label={Text("غرفي")})
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(14.dp)) }
        val visibleRooms = when(tab){
            "saved" -> rooms.filter{it.isSaved}
            "popular" -> rooms.sortedByDescending{it.memberCount}
            else -> rooms
        }
        LazyColumn(contentPadding = PaddingValues(14.dp, 10.dp, 14.dp, 30.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(visibleRooms, key = { it.id }) { room ->
                Card(
                    Modifier.fillMaxWidth().heightIn(min = 100.dp).clickable { onOpenRoom(room) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(Modifier.fillMaxWidth()) {
                        room.backgroundUrl?.let { AsyncImage(it, null, Modifier.matchParentSize(), contentScale = ContentScale.Crop) }
                        if (room.backgroundUrl != null) Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = .42f)))
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(room.ownerAvatarUrl, null, Modifier.size(52.dp).clip(CircleShape).background(Color(0xFFE9ECF2)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(room.title, fontWeight = FontWeight.Black, fontSize = 18.sp, color = if(room.backgroundUrl==null) StudentText else Color.White)
                                if (room.description.isNotBlank()) Text(room.description, color = if(room.backgroundUrl==null) StudentMuted else Color.White.copy(.82f), maxLines = 1)
                                Text("${room.memberCount}/${room.capacity}", color = if(room.backgroundUrl==null) StudentBlue else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Icon(Icons.Rounded.GraphicEq, null, tint = if(room.backgroundUrl==null) StudentBlue else Color.White)
                        }
                    }
                }
            }
            if (!loading && visibleRooms.isEmpty()) item { Text(if(tab=="saved") "لم تحفظ أي غرفة بعد." else "لا توجد غرف.", color = StudentMuted, modifier = Modifier.padding(20.dp)) }
        }
    }
    if (showCreate) CreateRoomDialog(api, session, onDismiss = { showCreate = false }, onCreated = { showCreate = false; reload() })
}

@Composable
private fun CreateRoomDialog(api: SupabaseApi, session: StudentSession, onDismiss: () -> Unit, onCreated: () -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = { if(!busy) onDismiss() },
        title = { Text(if(confirm) "تأكيد الإنشاء" else "إنشاء غرفة", fontWeight = FontWeight.Black) },
        text = {
            if(confirm) Text("سيتم التحقق من السعر والرصيد من السيرفر قبل الخصم.")
            else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it.take(60) }, label = { Text("اسم الغرفة") }, singleLine = true)
                OutlinedTextField(description, { description = it.take(240) }, label = { Text("الوصف — اختياري") }, minLines = 2)
                message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled=!busy,onClick = {
                if(!confirm){ if(title.trim().length<3) message="اكتب اسم غرفة واضحاً." else confirm=true }
                else scope.launch { busy=true; withContext(Dispatchers.IO){api.createVoiceRoom(session,title,description)}.onSuccess{onCreated()}.onFailure{message=friendlyRoomError(it.message);confirm=false};busy=false }
            }) { Text(if(busy) "جارٍ الإنشاء..." else if(confirm) "تأكيد" else "إنشاء") }
        },
        dismissButton = { TextButton(enabled=!busy,onClick={ if(confirm) confirm=false else onDismiss() }) { Text("إلغاء") } }
    )
}

@Composable
private fun VoiceRoomDetailScreen(api: SupabaseApi, session: StudentSession, roomInfo: VoiceRoomItem, onBack: () -> Unit, onOpenProfile: (String)->Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var members by remember { mutableStateOf<List<VoiceRoomMember>>(emptyList()) }
    var gifts by remember { mutableStateOf<List<VoiceRoomGiftPack>>(emptyList()) }
    var feed by remember { mutableStateOf<List<VoiceRoomFeedItem>>(emptyList()) }
    var backgrounds by remember { mutableStateOf<List<VoiceRoomBackground>>(emptyList()) }
    var connected by remember { mutableStateOf(false) }
    var micOn by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var showGifts by remember { mutableStateOf(false) }
    var showBackgrounds by remember { mutableStateOf(false) }
    var unlockConfirm by remember { mutableStateOf(false) }
    var unlockedMics by remember(roomInfo.id) { mutableIntStateOf(roomInfo.unlockedMics.coerceIn(5,10)) }
    var saved by remember(roomInfo.id) { mutableStateOf(roomInfo.isSaved) }
    var backgroundUrl by remember(roomInfo.id) { mutableStateOf(roomInfo.backgroundUrl) }
    var chatText by remember { mutableStateOf("") }
    var voiceRoom by remember { mutableStateOf<Room?>(null) }
    val me = members.firstOrNull { it.userId == session.userId }
    val canManage = me?.roomRole in setOf("owner","moderator")
    val canSpeak = me?.micState == "speaker" || me?.roomRole in setOf("owner","moderator")
    val isOwner = roomInfo.ownerId == session.userId

    fun refreshMembers() { scope.launch { withContext(Dispatchers.IO){ api.voiceRoomMembers(session,roomInfo.id) }.onSuccess{members=it}.onFailure{message=friendlyRoomError(it.message)} } }
    fun refreshFeed() { scope.launch { withContext(Dispatchers.IO){ api.voiceRoomFeed(session,roomInfo.id) }.onSuccess{feed=it}.onFailure{} } }
    fun refreshBackgrounds(){ scope.launch { withContext(Dispatchers.IO){api.voiceRoomBackgrounds(session)}.onSuccess{backgrounds=it} } }

    LaunchedEffect(roomInfo.id) {
        withContext(Dispatchers.IO) { api.joinVoiceRoom(session, roomInfo.id) }.onFailure { message=friendlyRoomError(it.message) }
        refreshMembers(); refreshFeed(); refreshBackgrounds()
        withContext(Dispatchers.IO){ api.voiceRoomGiftPacks(session) }.onSuccess{gifts=it}
        while(true){ delay(2500); refreshMembers(); refreshFeed() }
    }
    DisposableEffect(roomInfo.id) { onDispose { voiceRoom?.disconnect(); scope.launch(Dispatchers.IO){ api.leaveVoiceRoom(session,roomInfo.id) } } }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scope.launch { if (canSpeak) runCatching { voiceRoom?.localParticipant?.setMicrophoneEnabled(true) }.onSuccess { micOn=true } }
    }

    suspend fun connectVoice() {
        if (connected) return
        busy=true
        withContext(Dispatchers.IO){ api.voiceRoomToken(session,roomInfo.id) }.onSuccess { token ->
            runCatching { val lk=LiveKit.create(context); lk.connect(token.url,token.token); voiceRoom=lk; connected=true }.onFailure { message=friendlyRoomError(it.message) }
        }.onFailure { message=friendlyRoomError(it.message) }
        busy=false
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF11131A))) {
        backgroundUrl?.let { AsyncImage(it,null,Modifier.matchParentSize(),contentScale=ContentScale.Crop) }
        Box(Modifier.matchParentSize().background(Color.Black.copy(alpha=if(backgroundUrl==null).05f else .48f)))
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onBack){Icon(Icons.Rounded.ArrowBack,"رجوع",tint=Color.White)}
                Column(Modifier.weight(1f)){ Text(roomInfo.title,color=Color.White,fontWeight=FontWeight.Black,fontSize=19.sp); Text("${members.size}/${roomInfo.capacity}",color=Color.White.copy(.72f),fontSize=11.sp) }
                OutlinedButton(
                    onClick={ scope.launch { val next=!saved; withContext(Dispatchers.IO){api.toggleSavedVoiceRoom(session,roomInfo.id,next)}.onSuccess{saved=next}.onFailure{message=friendlyRoomError(it.message)} } },
                    colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.White), contentPadding=PaddingValues(horizontal=11.dp,vertical=5.dp)
                ){Text(if(saved)"تم الانضمام" else "انضمام",fontSize=11.sp)}
                if(isOwner) IconButton(onClick={showBackgrounds=true}){Icon(Icons.Rounded.Wallpaper,"خلفية",tint=Color.White)}
            }
            message?.let { Text(it,color=Color(0xFFFFD0CC),modifier=Modifier.padding(horizontal=14.dp),fontSize=11.sp) }

            MicSeats(
                members=members, unlockedMics=unlockedMics, isOwner=isOwner,
                onSeatClick={slot,occupant,locked->
                    when {
                        locked && isOwner -> unlockConfirm=true
                        locked -> message="هذا المايك مقفل."
                        occupant==null -> scope.launch { withContext(Dispatchers.IO){api.requestVoiceMic(session,roomInfo.id,slot)}.onSuccess{message="تم إرسال طلب المايك.";refreshMembers()}.onFailure{message=friendlyRoomError(it.message)} }
                        occupant.userId==session.userId && occupant.micState=="speaker" -> Unit
                        else -> onOpenProfile(occupant.userId)
                    }
                },
                onAccept={member-> scope.launch { withContext(Dispatchers.IO){api.setVoiceMemberMic(session,roomInfo.id,member.userId,true)}.onSuccess{refreshMembers()}.onFailure{message=friendlyRoomError(it.message)} } },
                canManage=canManage
            )

            LazyRow(contentPadding=PaddingValues(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                items(members,key={it.userId}){member->
                    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(66.dp)){
                        AsyncImage(member.avatarUrl,null,Modifier.size(45.dp).clip(CircleShape).background(Color.DarkGray).clickable{onOpenProfile(member.userId)})
                        Text(member.fullName,color=Color.White,fontSize=10.sp,maxLines=1)
                        if(member.userId!=session.userId) TextButton(contentPadding=PaddingValues(0.dp),onClick={
                            scope.launch { val next=!member.isFollowing; withContext(Dispatchers.IO){api.setFollowing(session,member.userId,next)}.onSuccess{refreshMembers()}.onFailure{message=friendlyRoomError(it.message)} }
                        }){Text(if(member.isFollowing)"متابَع" else "متابعة",fontSize=9.sp,color=if(member.isFollowing)Color.LightGray else Color(0xFFB7A5FF))}
                    }
                }
            }

            LazyColumn(Modifier.weight(1f).fillMaxWidth(),contentPadding=PaddingValues(horizontal=14.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                items(feed.takeLast(60),key={it.id}){item->
                    when(item.kind){
                        "gift" -> Text("${item.userName} أرسل ${item.giftEmoji ?: "🎁"} ${if(item.targetUserId==null)"للجميع" else "إلى ${item.targetName}"}",color=Color(0xFFFFD76A),fontSize=12.sp,fontWeight=FontWeight.Bold)
                        else -> Text("${item.userName}: ${item.message}",color=Color.White,fontSize=12.sp)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedTextField(
                    value=chatText,onValueChange={chatText=it.take(500)},placeholder={Text("اكتب رسالة",color=Color.White.copy(.65f))},singleLine=true,
                    textStyle=LocalTextStyle.current.copy(color=Color.White),
                    colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Color.White.copy(.5f),unfocusedBorderColor=Color.White.copy(.25f)),
                    modifier=Modifier.weight(1f),trailingIcon={IconButton(enabled=chatText.isNotBlank(),onClick={ val text=chatText.trim();chatText="";scope.launch{withContext(Dispatchers.IO){api.sendVoiceRoomMessage(session,roomInfo.id,text)}.onSuccess{refreshFeed()}.onFailure{message=friendlyRoomError(it.message)}}}){Icon(Icons.Rounded.Send,"إرسال",tint=Color.White)}}
                )
                FilledTonalIconButton(onClick={showGifts=true}){Icon(Icons.Rounded.CardGiftcard,"هدايا")}
                FilledTonalIconButton(onClick={ scope.launch { if(!connected) connectVoice() else {voiceRoom?.disconnect();voiceRoom=null;connected=false;micOn=false} } }){Icon(if(connected)Icons.Rounded.WifiOff else Icons.Rounded.GraphicEq,"الصوت")}
                FilledIconButton(enabled=canSpeak,onClick={
                    if(ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    else scope.launch { val next=!micOn; if(next&&!connected)connectVoice();runCatching{voiceRoom?.localParticipant?.setMicrophoneEnabled(next)}.onSuccess{micOn=next}.onFailure{message=friendlyRoomError(it.message)} }
                }){Icon(if(micOn)Icons.Rounded.Mic else Icons.Rounded.MicOff,"مايك")}
            }
        }
    }

    if(showGifts) GiftSheet(api,session,roomInfo.id,gifts,members,onDismiss={showGifts=false},onSent={showGifts=false;refreshFeed()})
    if(showBackgrounds) RoomBackgroundSheet(api,session,roomInfo.id,backgrounds,onDismiss={showBackgrounds=false},onApplied={url->backgroundUrl=url;showBackgrounds=false;refreshBackgrounds()})
    if(unlockConfirm) AlertDialog(onDismissRequest={unlockConfirm=false},title={Text("فتح مايك إضافي؟")},text={Text("سيتم التحقق من سعر المايك والرصيد من السيرفر قبل الخصم.")},confirmButton={Button(onClick={unlockConfirm=false;scope.launch{withContext(Dispatchers.IO){api.unlockVoiceMic(session,roomInfo.id)}.onSuccess{unlockedMics=it;message="تم فتح المايك."}.onFailure{message=friendlyRoomError(it.message)}}}){Text("تأكيد الشراء")}},dismissButton={TextButton(onClick={unlockConfirm=false}){Text("إلغاء")}})
}

@Composable
private fun MicSeats(members:List<VoiceRoomMember>,unlockedMics:Int,isOwner:Boolean,onSeatClick:(Int,VoiceRoomMember?,Boolean)->Unit,onAccept:(VoiceRoomMember)->Unit,canManage:Boolean){
    Column(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        repeat(2){row->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){
                repeat(5){col->
                    val slot=row*5+col+1;val locked=slot>unlockedMics;val occupant=members.firstOrNull{it.micSlot==slot&&it.micState in setOf("requested","speaker")}
                    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(62.dp).clickable{onSeatClick(slot,occupant,locked)}){
                        Surface(Modifier.size(46.dp),shape=CircleShape,color=when{locked->Color.Black.copy(.38f);occupant?.micState=="speaker"->Color(0xFF315C42);occupant?.micState=="requested"->Color(0xFF604B26);else->Color.White.copy(.16f)}){
                            Box(contentAlignment=Alignment.Center){
                                when{locked->Icon(Icons.Rounded.Lock,"مقفل",tint=Color.White.copy(.72f));occupant!=null->AsyncImage(occupant.avatarUrl,null,Modifier.fillMaxSize().clip(CircleShape),contentScale=ContentScale.Crop);else->Icon(Icons.Rounded.MicNone,"مايك $slot",tint=Color.White)}
                            }
                        }
                        Text(if(locked)"مقفل" else occupant?.fullName ?: "مايك $slot",color=Color.White,fontSize=9.sp,maxLines=1,textAlign=TextAlign.Center)
                        if(canManage&&occupant?.micState=="requested") TextButton(onClick={onAccept(occupant)},contentPadding=PaddingValues(0.dp)){Text("قبول",fontSize=9.sp,color=Color(0xFF6FE38A))}
                    }
                }
            }
        }
        if(isOwner&&unlockedMics<10) Text("",fontSize=1.sp) // keep layout clean; locked seat itself is the purchase entry.
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GiftSheet(api:SupabaseApi,session:StudentSession,roomId:String,gifts:List<VoiceRoomGiftPack>,members:List<VoiceRoomMember>,onDismiss:()->Unit,onSent:()->Unit){
    val scope=rememberCoroutineScope();var selected by remember{mutableStateOf<VoiceRoomGiftPack?>(null)};var recipient by remember{mutableStateOf<String?>(null)};var confirm by remember{mutableStateOf(false)};var msg by remember{mutableStateOf<String?>(null)};var busy by remember{mutableStateOf(false)}
    ModalBottomSheet(onDismissRequest=onDismiss){
        Column(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding(),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("الهدايا",fontWeight=FontWeight.Black,fontSize=19.sp)
            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(gifts,key={it.id}){g->
                FilterChip(selected=selected?.id==g.id,onClick={selected=g;confirm=false},label={Column(horizontalAlignment=Alignment.CenterHorizontally){Text(g.iconKey.ifBlank{"🎁"},fontSize=28.sp);Text("${g.diamonds}♦",fontSize=10.sp)}})
            }}
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=recipient==null,onClick={recipient=null},label={Text("الجميع")})}
            LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(members.filter{it.userId!=session.userId},key={it.userId}){m->FilterChip(selected=recipient==m.userId,onClick={recipient=m.userId},label={Text(m.fullName)})}}
            msg?.let{Text(it,color=MaterialTheme.colorScheme.error)}
            Button(enabled=selected!=null&&!busy,onClick={
                if(!confirm){confirm=true;msg="تأكيد إرسال ${selected?.iconKey ?: "🎁"} مقابل ${selected?.diamonds ?: 0} ألماسة؟"}
                else scope.launch{busy=true;withContext(Dispatchers.IO){api.sendVoiceRoomGift(session,roomId,selected!!.id,recipient)}.onSuccess{onSent()}.onFailure{msg=friendlyRoomError(it.message);confirm=false};busy=false}
            },modifier=Modifier.fillMaxWidth()){Text(if(confirm)"تأكيد الخصم والإرسال" else "إرسال")}
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomBackgroundSheet(api:SupabaseApi,session:StudentSession,roomId:String,backgrounds:List<VoiceRoomBackground>,onDismiss:()->Unit,onApplied:(String?)->Unit){
    val scope=rememberCoroutineScope();var pendingBuy by remember{mutableStateOf<VoiceRoomBackground?>(null)};var msg by remember{mutableStateOf<String?>(null)}
    ModalBottomSheet(onDismissRequest=onDismiss){
        Column(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding(),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Text("خلفية الغرفة",fontWeight=FontWeight.Black,fontSize=19.sp)
            OutlinedButton(onClick={scope.launch{withContext(Dispatchers.IO){api.applyVoiceRoomBackground(session,roomId,null)}.onSuccess{onApplied(null)}.onFailure{msg=friendlyRoomError(it.message)}}}){Text("بدون خلفية")}
            LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp)){items(backgrounds,key={it.id}){bg->
                Card(Modifier.width(130.dp).clickable{
                    if(bg.isOwned) scope.launch{withContext(Dispatchers.IO){api.applyVoiceRoomBackground(session,roomId,bg.id)}.onSuccess{onApplied(bg.imageUrl)}.onFailure{msg=friendlyRoomError(it.message)}} else pendingBuy=bg
                },shape=RoundedCornerShape(14.dp)){
                    Column{AsyncImage(bg.imageUrl,bg.name,Modifier.fillMaxWidth().height(105.dp),contentScale=ContentScale.Crop);Text(bg.name,Modifier.padding(7.dp),fontWeight=FontWeight.Bold,fontSize=11.sp);Text(if(bg.isOwned)"استخدام" else "${bg.diamonds}♦",Modifier.padding(horizontal=7.dp,vertical=0.dp),fontSize=10.sp,color=StudentBlue);Spacer(Modifier.height(7.dp))}
                }
            }}
            msg?.let{Text(it,color=MaterialTheme.colorScheme.error)}
        }
    }
    pendingBuy?.let{bg->AlertDialog(onDismissRequest={pendingBuy=null},title={Text("شراء الخلفية؟")},text={Text("${bg.name} مقابل ${bg.diamonds} ألماسة. لن تُشترى الخلفية نفسها مرتين.")},confirmButton={Button(onClick={pendingBuy=null;scope.launch{withContext(Dispatchers.IO){api.purchaseVoiceRoomBackground(session,bg.id)}.onSuccess{withContext(Dispatchers.IO){api.applyVoiceRoomBackground(session,roomId,bg.id)};onApplied(bg.imageUrl)}.onFailure{msg=friendlyRoomError(it.message)}}}){Text("تأكيد الشراء")}},dismissButton={TextButton(onClick={pendingBuy=null}){Text("إلغاء")}})}
}

private fun friendlyRoomError(raw:String?):String{
    val s=raw.orEmpty().lowercase()
    return when{
        "duplicate key" in s || "follows_pkey" in s -> "حالة المتابعة محدثة بالفعل."
        "insufficient_diamonds" in s -> "رصيد الألماس غير كافٍ."
        "mic_locked" in s -> "هذا المايك مقفل."
        "mic_occupied" in s -> "هذا المايك مستخدم حاليًا."
        "speaker_limit" in s -> "اكتمل عدد المايكات المتاحة."
        "room_full" in s -> "الغرفة ممتلئة."
        "room_banned" in s -> "لا يمكنك دخول هذه الغرفة."
        "slow_down" in s -> "أرسل الرسائل بهدوء أكثر."
        else -> raw?.takeIf{it.isNotBlank()} ?: "تعذر تنفيذ العملية."
    }
}
