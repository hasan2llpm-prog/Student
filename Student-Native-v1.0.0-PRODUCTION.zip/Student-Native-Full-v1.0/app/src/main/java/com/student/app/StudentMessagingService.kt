package com.student.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.student.core.data.SessionStore
import com.student.core.data.SupabaseApi

class StudentMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        getSharedPreferences("student_push", MODE_PRIVATE).edit().putString("fcm_token", token).apply()

        // Firebase may rotate the token while Student is not open. Persist the new
        // native token in Supabase immediately when a signed-in session exists.
        val session = SessionStore(this).load() ?: return
        Thread {
            runCatching { SupabaseApi().registerPushToken(session, token) }
        }.start()
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        val session = SessionStore(this).load()
        val actorId = message.data["actor_id"].orEmpty()
        // Never notify a user about an action they performed themselves.
        if (session != null && actorId.isNotBlank() && actorId == session.userId) return

        val title = message.notification?.title ?: message.data["title"] ?: "Student"
        val body = message.notification?.body ?: message.data["body"] ?: "لديك إشعار جديد"
        val manager = getSystemService(NotificationManager::class.java)
        val channelId = "student_main"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "إشعارات Student",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "الرسائل والتنبيهات المهمة من Student"
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }

        val target = message.data["link"]
            ?.takeIf { it.isNotBlank() }
            ?: message.data["kind"]
            ?.takeIf { it.isNotBlank() }
            ?: "notifications"

        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("student_destination", target)
            .putExtra("student_notification_id", message.data["notification_id"])
            .putExtra("student_kind", message.data["kind"])
            .putExtra("student_link", message.data["link"])
            .putExtra("student_metadata", message.data["metadata"])

        val pending = PendingIntent.getActivity(
            this,
            (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_stat_student)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()

        val stableId = message.data["notification_id"]?.hashCode()
            ?: (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        manager.notify(stableId, notification)
    }
}
