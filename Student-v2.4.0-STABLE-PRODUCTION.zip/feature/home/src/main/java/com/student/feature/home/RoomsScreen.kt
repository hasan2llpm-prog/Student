package com.student.feature.home

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.student.core.data.*
import io.livekit.android.LiveKit
import io.livekit.android.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun RoomsScreen(
    api: SupabaseApi,
    session: StudentSession,
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit
) {
    var selected by remember { mutableStateOf<VoiceRoomItem?>(null) }
    if (selected != null) {
        VoiceRoomDetailScreen(api, session, selected!!, onBack = { selected = null }, onOpenProfile = onOpenProfile)
    } else {
        VoiceRoomsDiscovery(api, session, onBack = onBack, onOpenRoom = { selected = it })
    }
}

@Composable
private fun VoiceRoomsDiscovery(api: SupabaseApi, session: StudentSession, onBack: () -> Unit, onOpenRoom: (VoiceRoomItem) -> Unit) {
    val scope = rememberCoroutineScope()
    var rooms by remember { mutableStateOf<List<VoiceRoomItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var showCreate by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun reload() {
        scope.launch {
            loading = true
            withContext(Dispatchers.IO) { api.voiceRooms(session, query) }
                .onSuccess { rooms = it }
                .onFailure { error = it.message }
            loading = false
        }
    }
    LaunchedEffect(query) { delay(250); reload() }

    Column(Modifier.fillMaxSize().background(Color(0xFFF8F9FC))) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "رجوع") }
            Text("الغرف", fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            FilledTonalIconButton(onClick = { showCreate = true }) { Icon(Icons.Rounded.Add, "إنشاء غرفة") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it.take(80) },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            placeholder = { Text("ابحث عن غرفة") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp)
        )
        Spacer(Modifier.height(8.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(14.dp)) }
        LazyColumn(contentPadding = PaddingValues(14.dp, 8.dp, 14.dp, 30.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(rooms, key = { it.id }) { room ->
                StudentOutlinedCard(Modifier.fillMaxWidth().clickable { onOpenRoom(room) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(room.ownerAvatarUrl, null, Modifier.size(54.dp).clip(CircleShape))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(room.title, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            if (room.description.isNotBlank()) Text(room.description, color = StudentMuted, maxLines = 2)
                            Text("${room.memberCount}/${room.capacity} عضو", color = StudentBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Icon(if (room.isLocked) Icons.Rounded.Lock else Icons.Rounded.GraphicEq, null, tint = StudentBlue)
                    }
                }
            }
            if (!loading && rooms.isEmpty()) item { Text("لا توجد غرف مطابقة.", color = StudentMuted, modifier = Modifier.padding(20.dp)) }
        }
    }

    if (showCreate) CreateRoomDialog(api, session, onDismiss = { showCreate = false }, onCreated = { showCreate = false; reload() })
}

@Composable
private fun CreateRoomDialog(api: SupabaseApi, session: StudentSession, onDismiss: () -> Unit, onCreated: () -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    if (!confirm) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("إنشاء غرفة", fontWeight = FontWeight.Black) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it.take(60) }, label = { Text("اسم الغرفة") }, singleLine = true)
                OutlinedTextField(description, { description = it.take(240) }, label = { Text("وصف مختصر") }, minLines = 2)
                Text("السعة الأساسية 50 عضو. سعر الإنشاء يحدده الأدمن، والأدمن والمدرس مجاناً.", color = StudentMuted, fontSize = 12.sp)
                message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            } },
            confirmButton = { Button(onClick = { if (title.trim().length < 3) message="اكتب اسم غرفة واضحاً." else confirm=true }) { Text("متابعة") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
        )
    } else {
        AlertDialog(
            onDismissRequest = { if (!busy) confirm = false },
            title = { Text("تأكيد إنشاء الغرفة") },
            text = { Text("سيتم التحقق من السعر والرصيد من السيرفر قبل الإنشاء. هل تريد المتابعة؟") },
            confirmButton = { Button(enabled=!busy, onClick = { scope.launch { busy=true; withContext(Dispatchers.IO){ api.createVoiceRoom(session,title,description) }.onSuccess { onCreated() }.onFailure { message=it.message; confirm=false }; busy=false } }) { Text(if(busy) "جارٍ الإنشاء..." else "تأكيد") } },
            dismissButton = { TextButton(enabled=!busy,onClick={confirm=false}) { Text("رجوع") } }
        )
    }
}

@Composable
private fun VoiceRoomDetailScreen(api: SupabaseApi, session: StudentSession, roomInfo: VoiceRoomItem, onBack: () -> Unit, onOpenProfile: (String)->Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var members by remember { mutableStateOf<List<VoiceRoomMember>>(emptyList()) }
    var gifts by remember { mutableStateOf<List<VoiceRoomGiftPack>>(emptyList()) }
    var tiers by remember { mutableStateOf<List<VoiceRoomCapacityTier>>(emptyList()) }
    var connected by remember { mutableStateOf(false) }
    var micOn by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var showGifts by remember { mutableStateOf(false) }
    var showUpgrade by remember { mutableStateOf(false) }
    var room by remember { mutableStateOf<Room?>(null) }
    val me = members.firstOrNull { it.userId == session.userId }
    val canManage = me?.roomRole in setOf("owner","moderator")
    val canSpeak = me?.micState == "speaker" || me?.roomRole in setOf("owner","moderator")

    fun refreshMembers() { scope.launch { withContext(Dispatchers.IO){ api.voiceRoomMembers(session,roomInfo.id) }.onSuccess{members=it} } }
    LaunchedEffect(roomInfo.id) {
        withContext(Dispatchers.IO) { api.joinVoiceRoom(session, roomInfo.id) }.onFailure { message=it.message }
        refreshMembers()
        withContext(Dispatchers.IO){ api.voiceRoomGiftPacks(session) }.onSuccess{gifts=it}
        withContext(Dispatchers.IO){ api.voiceRoomCapacityTiers(session) }.onSuccess{tiers=it}
        while(true){ delay(7000); refreshMembers() }
    }
    DisposableEffect(roomInfo.id) { onDispose { room?.disconnect(); scope.launch(Dispatchers.IO){ api.leaveVoiceRoom(session,roomInfo.id) } } }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scope.launch { if (canSpeak) { runCatching { room?.localParticipant?.setMicrophoneEnabled(true) }.onSuccess { micOn=true } } }
    }

    suspend fun connectVoice() {
        if (connected) return
        busy=true
        withContext(Dispatchers.IO){ api.voiceRoomToken(session,roomInfo.id) }
            .onSuccess { token ->
                runCatching {
                    val lk=LiveKit.create(context)
                    lk.connect(token.url,token.token)
                    room=lk; connected=true
                }.onFailure { message=it.message }
            }.onFailure { message=it.message }
        busy=false
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF11131A))) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick=onBack){Icon(Icons.Rounded.ArrowBack,"رجوع",tint=Color.White)}
            Column(Modifier.weight(1f)){ Text(roomInfo.title,color=Color.White,fontWeight=FontWeight.Black,fontSize=20.sp); Text("${members.size}/${roomInfo.capacity} عضو",color=Color.LightGray,fontSize=12.sp) }
            IconButton(onClick={showGifts=true}){Icon(Icons.Rounded.CardGiftcard,"هدايا",tint=Color(0xFFFFC857))}
            if (roomInfo.ownerId==session.userId) IconButton(onClick={showUpgrade=true}){Icon(Icons.Rounded.Upgrade,"توسعة",tint=Color.White)}
        }
        message?.let { Text(it,color=Color(0xFFFF8A80),modifier=Modifier.padding(horizontal=14.dp)) }
        LazyRow(contentPadding=PaddingValues(14.dp), horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            items(members,key={it.userId}) { member ->
                Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(76.dp).clickable{onOpenProfile(member.userId)}) {
                    Box {
                        AsyncImage(member.avatarUrl,null,Modifier.size(58.dp).clip(CircleShape).background(Color.DarkGray))
                        if(member.micState=="speaker") Icon(Icons.Rounded.Mic,null,tint=Color(0xFF5BE37D),modifier=Modifier.size(18.dp).align(Alignment.BottomEnd).background(Color.Black,CircleShape).padding(2.dp))
                    }
                    Text(member.fullName,color=Color.White,fontSize=11.sp,maxLines=1)
                    if(member.roomRole!="listener") Text(member.roomRole,color=Color(0xFFB7A5FF),fontSize=9.sp)
                    if(member.userId!=session.userId) TextButton(contentPadding=PaddingValues(0.dp),onClick={ scope.launch { withContext(Dispatchers.IO){ api.setFollowing(session,member.userId,true) }.onSuccess{message="تمت المتابعة"}.onFailure{message=it.message} } }){Text("متابعة",fontSize=9.sp)}
                    if(canManage && member.micState=="requested") IconButton(onClick={ scope.launch { withContext(Dispatchers.IO){api.setVoiceMemberMic(session,roomInfo.id,member.userId,true)}.onSuccess{refreshMembers()}.onFailure{message=it.message} } },modifier=Modifier.size(28.dp)){Icon(Icons.Rounded.CheckCircle,"قبول المايك",tint=Color(0xFF5BE37D))}
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
            FilledTonalIconButton(onClick={ scope.launch { if(!connected) connectVoice() else {room?.disconnect();room=null;connected=false;micOn=false} } }) { Icon(if(connected) Icons.Rounded.WifiOff else Icons.Rounded.GraphicEq,null) }
            if (canSpeak) {
                FilledIconButton(onClick={
                    if(ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    else scope.launch {
                        val next=!micOn
                        if(next){
                            if(connected){ room?.disconnect(); room=null; connected=false }
                            connectVoice()
                        }
                        runCatching{room?.localParticipant?.setMicrophoneEnabled(next)}.onSuccess{micOn=next}.onFailure{message=it.message}
                    }
                }) { Icon(if(micOn) Icons.Rounded.Mic else Icons.Rounded.MicOff,null) }
            } else {
                Button(onClick={ scope.launch { withContext(Dispatchers.IO){api.requestVoiceMic(session,roomInfo.id)}.onSuccess{message="تم إرسال طلب المايك."}.onFailure{message=it.message} } }) { Text("طلب مايك") }
            }
            FilledTonalIconButton(onClick={showGifts=true}){Icon(Icons.Rounded.CardGiftcard,null)}
        }
    }

    if(showGifts) GiftDialog(api,session,roomInfo.id,gifts,members,onDismiss={showGifts=false})
    if(showUpgrade) UpgradeRoomDialog(api,session,roomInfo,tiers,onDismiss={showUpgrade=false})
}

@Composable
private fun GiftDialog(api:SupabaseApi,session:StudentSession,roomId:String,gifts:List<VoiceRoomGiftPack>,members:List<VoiceRoomMember>,onDismiss:()->Unit){
    val scope=rememberCoroutineScope(); var selectedPack by remember{mutableStateOf<VoiceRoomGiftPack?>(null)}; var recipient by remember{mutableStateOf<String?>(null)}; var confirm by remember{mutableStateOf(false)}; var busy by remember{mutableStateOf(false)}; var msg by remember{mutableStateOf<String?>(null)}
    AlertDialog(onDismissRequest={if(!busy)onDismiss()},title={Text("هدايا الغرفة")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(gifts,key={it.id}){g->FilterChip(selectedPack?.id==g.id,{selectedPack=g},{Text("${g.name} • ${g.diamonds}♦")})}}
        Text("الإرسال إلى",fontWeight=FontWeight.Bold); FilterChip(recipient==null,{recipient=null},{Text("الجميع")}); LazyRow(horizontalArrangement=Arrangement.spacedBy(6.dp)){items(members.filter{it.userId!=session.userId},key={it.userId}){m->FilterChip(recipient==m.userId,{recipient=m.userId},{Text(m.fullName)})}}
        msg?.let{Text(it,color=MaterialTheme.colorScheme.error)}
    }},confirmButton={Button(enabled=selectedPack!=null&&!busy,onClick={if(!confirm){confirm=true;msg="اضغط إرسال مرة ثانية لتأكيد خصم ${selectedPack?.diamonds?:0} ألماسة."}else scope.launch{busy=true;withContext(Dispatchers.IO){api.sendVoiceRoomGift(session,roomId,selectedPack!!.id,recipient)}.onSuccess{onDismiss()}.onFailure{msg=it.message;confirm=false};busy=false}}){Text(if(confirm)"تأكيد الإرسال" else "إرسال")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}

@Composable
private fun UpgradeRoomDialog(api:SupabaseApi,session:StudentSession,room:VoiceRoomItem,tiers:List<VoiceRoomCapacityTier>,onDismiss:()->Unit){
    val scope=rememberCoroutineScope(); var selected by remember{mutableStateOf<VoiceRoomCapacityTier?>(null)}; var confirm by remember{mutableStateOf(false)}; var busy by remember{mutableStateOf(false)}; var msg by remember{mutableStateOf<String?>(null)}
    AlertDialog(onDismissRequest={if(!busy)onDismiss()},title={Text("توسعة الغرفة")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){tiers.filter{it.capacity>room.capacity}.forEach{t->FilterChip(selected?.capacity==t.capacity,{selected=t},{Text("${t.capacity} عضو • ${t.diamonds}♦")})};msg?.let{Text(it,color=MaterialTheme.colorScheme.error)}}},confirmButton={Button(enabled=selected!=null&&!busy,onClick={if(!confirm){confirm=true;msg="تأكيد الترقية من ${room.capacity} إلى ${selected!!.capacity} مقابل ${selected!!.diamonds} ألماسة؟"}else scope.launch{busy=true;withContext(Dispatchers.IO){api.upgradeVoiceRoom(session,room.id,selected!!.capacity)}.onSuccess{onDismiss()}.onFailure{msg=it.message;confirm=false};busy=false}}){Text(if(confirm)"تأكيد الخصم" else "ترقية")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
