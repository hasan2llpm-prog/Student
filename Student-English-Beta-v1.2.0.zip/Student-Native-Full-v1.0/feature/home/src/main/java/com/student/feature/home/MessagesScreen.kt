package com.student.feature.home

import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun MessagesScreen(api: SupabaseApi, session: StudentSession, initialConversationId: String? = null, onOpenProfile: (String) -> Unit = {}, onConversationStateChanged: (Boolean) -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val offline = remember { OfflineStore(context) }
    var conversations by remember { mutableStateOf<List<ConversationItem>>(emptyList()) }
    var current by remember { mutableStateOf<ConversationItem?>(null) }
    var messages by remember { mutableStateOf<List<MessageItem>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val messageListState = rememberLazyListState()
    var imagePreview by remember { mutableStateOf<String?>(null) }
    var editingMessage by remember { mutableStateOf<MessageItem?>(null) }
    var deleteMessage by remember { mutableStateOf<MessageItem?>(null) }
    var menuMessageId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(error) { if (error != null) { delay(cfg.long("messages.status_duration_ms", 3200L, 500L, 10000L)); error = null } }

    fun loadConversations() {
        scope.launch {
            busy = true
            error = null
            val r = withContext(Dispatchers.IO) { api.conversations(session) }
            r.onSuccess { conversations = it }.onFailure { error = it.message }
            busy = false
        }
    }

    fun loadMessages(conv: ConversationItem, quiet: Boolean = false) {
        scope.launch {
            if (!quiet) {
                busy = true
                val cached = offline.loadMessages(conv.id)
                if (cached.isNotEmpty()) messages = cached.sortedBy { it.createdAt }
            }
            val r = withContext(Dispatchers.IO) { api.messages(session, conv.id) }
            r.onSuccess { rows ->
                messages = rows.sortedBy { it.createdAt }
                offline.saveMessages(conv.id, rows)
                withContext(Dispatchers.IO) { api.markConversationRead(session, conv.id) }
            }.onFailure { if (!quiet && messages.isEmpty()) error = it.message else if (!quiet) error = "Offline: يتم عرض آخر رسائل محفوظة." }
            if (!quiet) busy = false
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        val conv = current
        if (picked != null && conv != null) {
            scope.launch {
                busy = true
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val bytes = context.contentResolver.openInputStream(picked)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الملف.")
                        val maxMb = cfg.int("messages.max_upload_mb", 20, 1, 100)
                        if (bytes.size > maxMb * 1024 * 1024) throw IllegalStateException("الحد الأقصى ${maxMb}MB.")
                        val mime = context.contentResolver.getType(picked) ?: "application/octet-stream"
                        val displayName = runCatching {
                            context.contentResolver.query(picked, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                                if (cursor.moveToFirst()) cursor.getString(0) else null
                            }
                        }.getOrNull()?.takeIf { !it.isNullOrBlank() } ?: "attachment"
                        val type = when {
                            mime.startsWith("image/") -> "image"
                            mime.startsWith("video/") -> "video"
                            mime.startsWith("audio/") -> "audio"
                            else -> "file"
                        }
                        val extension = displayName.substringAfterLast('.', "").takeIf { it.isNotBlank() }
                            ?: MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
                            ?: when (type) { "image" -> "jpg"; "video" -> "mp4"; "audio" -> "m4a"; else -> "bin" }
                        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(100)
                        val path = "${session.userId}/${System.currentTimeMillis()}_${safeName.ifBlank { "attachment.$extension" }}"
                        val url = api.uploadObject(session, "chat-media", path, bytes, mime).getOrThrow()
                        api.sendMediaMessage(session, conv.id, url, type, displayName, bytes.size.toLong()).getOrThrow()
                    }
                }
                result.onSuccess { loadMessages(conv, quiet = true) }.onFailure { error = it.message }
                busy = false
            }
        }
    }

    BackHandler(enabled = current != null) {
        current = null
        messages = emptyList()
        loadConversations()
    }

    LaunchedEffect(Unit) { loadConversations() }
    LaunchedEffect(initialConversationId, conversations) {
        val id = initialConversationId?.takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        val conv = conversations.firstOrNull { it.id == id } ?: return@LaunchedEffect
        if (current?.id != conv.id) {
            current = conv
            loadMessages(conv)
        }
    }
    LaunchedEffect(current?.id) { onConversationStateChanged(current != null) }
    DisposableEffect(Unit) { onDispose { onConversationStateChanged(false) } }
    DisposableEffect(current?.id, session.accessToken) {
        val conv = current
        val observer = if (conv != null) api.observeConversationMessages(session, conv.id) {
            loadMessages(conv, quiet = true)
        } else null
        onDispose { observer?.close() }
    }
    LaunchedEffect(current?.id, messages.size) {
        if (cfg.bool("messages.auto_scroll", true) && current != null && messages.isNotEmpty()) {
            delay(cfg.long("messages.auto_scroll_delay_ms", 60L, 0L, 1000L))
            messageListState.animateScrollToItem(messages.lastIndex)
        }
    }
    LaunchedEffect(current?.id) {
        val conv = current ?: return@LaunchedEffect
        while (current?.id == conv.id) {
            delay(cfg.long("messages.poll_interval_ms", 15000L, 3000L, 120000L))
            loadMessages(conv, quiet = true)
        }
    }

    imagePreview?.let { url ->
        StudentImageViewer(url = url, fileName = "student-image-${System.currentTimeMillis()}.jpg", onDismiss = { imagePreview = null })
    }

    deleteMessage?.let { target ->
        AlertDialog(
            onDismissRequest = { if (!busy) deleteMessage = null },
            title = { Text("حذف الرسالة؟") },
            text = { Text("سيتم حذف هذه الرسالة من المحادثة.") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.deleteMessage(session, target.id) }
                            busy = false
                            r.onSuccess {
                                deleteMessage = null
                                current?.let { loadMessages(it, quiet = true) }
                            }.onFailure { error = it.message ?: "تعذر حذف الرسالة." }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleteMessage = null }, enabled = !busy) { Text("إلغاء") } }
        )
    }


    if (current == null) {
        Column(Modifier.fillMaxSize().background(StudentMessageBg)) {
            Row(
                Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("المحادثات", fontSize = 20.sp, fontWeight = FontWeight.Black, color = StudentText)
                    Text("رسائلك في Student", fontSize = 11.sp, color = StudentMuted)
                }
                TextButton(onClick = { loadConversations() }) { Text("تحديث", color = StudentBlue) }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp), fontSize = 12.sp) }
            LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(conversations, key = { it.id }) { c ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { current = c; loadMessages(c) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE9EDF3)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                            StudentAvatar(c.title, c.avatarUrl, c.profileFrameUrl, 50.dp)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                StudentName(c.title, c.isVerified, c.verificationColor)
                                Text(c.lastMessage.ifBlank { "لا توجد رسائل" }, maxLines = 1, color = StudentMuted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(prettyTime(c.lastMessageAt), color = Color(0xFF98A2B1), fontSize = 9.sp)
                                if (c.unreadCount > 0) {
                                    Spacer(Modifier.height(5.dp))
                                    Badge(containerColor = StudentBlue) { val max = cfg.int("messages.unread_badge_max", 99, 9, 999); Text(if (c.unreadCount > max) "${max}+" else c.unreadCount.toString(), color = Color.White) }
                                }
                            }
                        }
                    }
                }
                if (conversations.isEmpty() && !busy) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 70.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Rounded.Email, null, tint = StudentBlue, modifier = Modifier.size(34.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("لا توجد محادثات بعد", fontWeight = FontWeight.Bold)
                                Text("ابحث عن شخص وابدأ المراسلة.", color = StudentMuted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    } else {
        val conv = current!!
        Column(Modifier.fillMaxSize().background(StudentMessageBg).imePadding()) {
            Row(
                Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { current = null; messages = emptyList(); loadConversations() }) { Icon(Icons.Rounded.ArrowBack, "رجوع", tint = StudentText) }
                Row(Modifier.weight(1f).clickable(enabled = !conv.otherUserId.isNullOrBlank()) { conv.otherUserId?.let(onOpenProfile) }, verticalAlignment = Alignment.CenterVertically) {
                    StudentAvatar(conv.title, conv.avatarUrl, conv.profileFrameUrl, 42.dp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        StudentName(conv.title, conv.isVerified, conv.verificationColor)
                        Text("عرض الحساب", fontSize = 10.sp, color = StudentMuted)
                    }
                }
                IconButton(onClick = { loadMessages(conv) }) { Icon(Icons.Rounded.Refresh, "تحديث", tint = StudentText) }
            }
            HorizontalDivider(color = Color(0xFFE8EDF4))
            if (busy && messages.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 11.sp) }
            LazyColumn(
                state = messageListState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(messages, key = { it.id }) { m ->
                    val mine = m.senderId == session.userId
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End) {
                        Surface(
                            color = if (mine) Color(0xFFDFF0FF) else Color.White,
                            shape = RoundedCornerShape(cfg.int("messages.bubble_radius_dp", 17, 4, 32).dp),
                            shadowElevation = 1.dp,
                            modifier = Modifier.widthIn(max = cfg.int("messages.bubble_max_width_dp", 310, 180, 380).dp)
                        ) {
                            Column(Modifier.padding(horizontal = 11.dp, vertical = 8.dp)) {
                                if (m.deletedAt != null) {
                                    Text("تم حذف الرسالة", color = StudentMuted, fontSize = 13.sp)
                                } else {
                                    if (m.body.isNotBlank()) Text(m.body, color = StudentText, fontSize = cfg.int("messages.message_font_sp", 14, 10, 22).sp, lineHeight = cfg.int("messages.message_line_sp", 20, 14, 32).sp)
                                    m.mediaUrl?.let { url ->
                                        if (m.messageType.lowercase() == "image") {
                                            Spacer(Modifier.height(5.dp))
                                            AsyncImage(
                                                model = url,
                                                contentDescription = "صورة مرفقة",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.widthIn(max = cfg.int("messages.image_max_width_dp", 260, 160, 360).dp).heightIn(min = 120.dp, max = cfg.int("messages.image_max_height_dp", 320, 180, 600).dp).clip(RoundedCornerShape(12.dp)).clickable { if (cfg.bool("messages.open_images_inside", true)) imagePreview = url else runCatching { uriHandler.openUri(url) } }
                                            )
                                        } else {
                                            Spacer(Modifier.height(5.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(when (m.messageType.lowercase()) { "video" -> Icons.Rounded.PlayCircle; "audio" -> Icons.Rounded.AudioFile; else -> Icons.Rounded.AttachFile }, null, tint = StudentBlue)
                                                Spacer(Modifier.width(4.dp))
                                                Text(when (m.messageType.lowercase()) { "video" -> "فيديو"; "audio" -> "ملف صوتي"; else -> m.fileName ?: "ملف" }, modifier = Modifier.weight(1f), fontSize = 12.sp)
                                            }
                                            StudentFileActions(url, m.fileName)
                                        }
                                    }
                                }
                                if (cfg.bool("messages.show_time", true) || (mine && cfg.bool("messages.show_read_receipt", true))) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    if (cfg.bool("messages.show_time", true)) Text(prettyTime(m.createdAt), style = MaterialTheme.typography.labelSmall, color = Color(0xFF8792A0))
                                    if (mine && cfg.bool("messages.show_read_receipt", true)) Icon(if (m.readCount > 0) Icons.Rounded.DoneAll else Icons.Rounded.Done, "حالة القراءة", tint = if (m.readCount > 0) StudentBlue else StudentMuted, modifier = Modifier.size(cfg.int("messages.read_icon_size_dp", 14, 10, 22).dp))
                                }
                                if (mine && m.deletedAt == null && cfg.bool("messages.allow_edit_delete", true)) {
                                    Box(Modifier.align(Alignment.End)) {
                                        IconButton(onClick = { menuMessageId = m.id }, modifier = Modifier.size(28.dp)) {
                                            Icon(Icons.Rounded.MoreVert, "خيارات الرسالة", modifier = Modifier.size(17.dp), tint = StudentMuted)
                                        }
                                        DropdownMenu(expanded = menuMessageId == m.id, onDismissRequest = { menuMessageId = null }) {
                                            if (m.messageType.lowercase() == "text") {
                                                DropdownMenuItem(
                                                    text = { Text("تعديل") },
                                                    leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                                                    onClick = { menuMessageId = null; editingMessage = m; input = m.body }
                                                )
                                            }
                                            DropdownMenuItem(
                                                text = { Text("حذف", color = Color(0xFFC62828)) },
                                                leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = Color(0xFFC62828)) },
                                                onClick = { menuMessageId = null; deleteMessage = m }
                                            )
                                        }
                                    }
                                }
                                if (m.editedAt != null && m.deletedAt == null) Text("تم التعديل", fontSize = 9.sp, color = StudentMuted)
                            }
                        }
                    }
                }
            }
            editingMessage?.let { editing ->
                Surface(color = Color(0xFFF3F0FA), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("تعديل الرسالة", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = StudentBlue)
                            Text(editing.body, maxLines = 1, fontSize = 11.sp, color = StudentMuted)
                        }
                        TextButton(onClick = { editingMessage = null; input = "" }) { Text("إلغاء") }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                OutlinedIconButton(onClick = { filePicker.launch("*/*") }, enabled = !busy, modifier = Modifier.size(45.dp), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Rounded.AttachFile, "إرفاق") }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("اكتب رسالة...") },
                    modifier = Modifier.weight(1f),
                    maxLines = cfg.int("messages.composer_max_lines", 4, 1, 8),
                    shape = RoundedCornerShape(18.dp)
                )
                Button(
                    onClick = {
                        val body = input.trim()
                        if (body.isBlank()) return@Button
                        val editing = editingMessage
                        input = ""
                        editingMessage = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                if (editing != null) api.editMessage(session, editing.id, body)
                                else api.sendMessage(session, conv.id, body)
                            }
                            r.onSuccess { loadMessages(conv, quiet = true) }.onFailure {
                                if (editing == null) {
                                    offline.enqueue("message_text", JSONObject().put("conversation_id", conv.id).put("body", body))
                                    error = "لا يوجد اتصال. تم حفظ الرسالة وستُرسل عند رجوع الإنترنت."
                                } else {
                                    input = body
                                    editingMessage = editing
                                    error = it.message ?: "تعذر تعديل الرسالة."
                                }
                            }
                        }
                    },
                    enabled = input.isNotBlank(),
                    modifier = Modifier.height(cfg.int("messages.send_button_height_dp", 46, 40, 64).dp),
                    shape = RoundedCornerShape(cfg.int("messages.send_button_radius_dp", 15, 4, 28).dp)
                ) { Text(if (editingMessage != null) "حفظ" else "إرسال") }
            }
        }
    }
}
