@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.student.feature.home

import kotlinx.coroutines.delay
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import android.net.Uri
import android.widget.VideoView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StoriesScreen(api: SupabaseApi, session: StudentSession, initialStoryId: String? = null, onClose: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    val context = LocalContext.current
    val uri = LocalUriHandler.current
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var createOpen by remember { mutableStateOf(false) }
    var storyText by remember { mutableStateOf("") }
    var interaction by remember { mutableStateOf<StoryItem?>(null) }
    var deleteStory by remember { mutableStateOf<StoryItem?>(null) }
    var editStory by remember { mutableStateOf<StoryItem?>(null) }
    var viewerIndex by remember { mutableIntStateOf(-1) }

    fun refresh() {
        scope.launch {
            loading = true
            message = null
            val r = withContext(Dispatchers.IO) { api.stories(session, 80) }
            r.onSuccess { stories = it }.onFailure { message = it.message }
            loading = false
        }
    }

    fun publishMedia(uriValue: android.net.Uri) {
        scope.launch {
            loading = true
            message = null
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val mime = context.contentResolver.getType(uriValue) ?: "application/octet-stream"
                    val type = when {
                        mime.startsWith("image/") -> "image"
                        mime.startsWith("video/") -> "video"
                        else -> throw IllegalStateException("القصص تدعم الصور والفيديو فقط.")
                    }
                    val bytes = context.contentResolver.openInputStream(uriValue)?.use { it.readBytes() }
                        ?: throw IllegalStateException("تعذر قراءة الملف.")
                    val maxMb = cfg.int("stories.max_upload_mb", 30, 1, 100)
                    if (bytes.size > maxMb * 1024 * 1024) throw IllegalStateException("الحد الأقصى لوسائط القصة ${maxMb}MB.")
                    val ext = if (type == "image") "jpg" else "mp4"
                    val path = "${session.userId}/${System.currentTimeMillis()}_story.$ext"
                    val url = api.uploadObject(session, "stories", path, bytes, mime).getOrThrow()
                    api.createStory(session, storyText.trim(), url, type).getOrThrow()
                }
            }
            loading = false
            result.onSuccess { storyText = ""; createOpen = false; message = "تم نشر القصة."; refresh() }
                .onFailure { message = it.message }
        }
    }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        if (picked != null) publishMedia(picked)
    }

    LaunchedEffect(Unit) { refresh() }
    LaunchedEffect(initialStoryId, stories) {
        when {
            initialStoryId == "__create__" -> createOpen = true
            !initialStoryId.isNullOrBlank() && stories.isNotEmpty() && viewerIndex < 0 -> {
                viewerIndex = stories.indexOfFirst { it.id == initialStoryId }.takeIf { it >= 0 } ?: -1
            }
        }
    }
    LaunchedEffect(message) { if (message != null) { delay(cfg.long("stories.status_duration_ms", 2600L, 500L, 10000L)); message = null } }

    if (createOpen) {
        AlertDialog(
            onDismissRequest = { if (!loading) createOpen = false },
            title = { Text("قصة جديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        storyText,
                        { storyText = it.take(1200) },
                        label = { Text("نص القصة — اختياري مع الوسائط") },
                        modifier = Modifier.fillMaxWidth(), minLines = 4
                    )
                    OutlinedButton(onClick = { mediaPicker.launch("*/*") }, modifier = Modifier.fillMaxWidth(), enabled = !loading) {
                        Icon(Icons.Rounded.PermMedia, null); Spacer(Modifier.width(6.dp)); Text("اختيار صورة أو فيديو")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (storyText.isBlank()) return@Button
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.createTextStory(session, storyText.trim()) }
                            loading = false
                            r.onSuccess { storyText = ""; createOpen = false; message = "تم نشر القصة."; refresh() }.onFailure { message = it.message }
                        }
                    }, enabled = storyText.isNotBlank() && !loading
                ) { Text("نشر نص") }
            },
            dismissButton = { TextButton(onClick = { createOpen = false }, enabled = !loading) { Text("إلغاء") } }
        )
    }

    interaction?.let { story ->
        StoryInteractionDialog(api, session, story, onDismiss = { interaction = null }) { msg -> message = msg }
    }

    editStory?.let { story ->
        var editText by remember(story.id) { mutableStateOf(story.content) }
        AlertDialog(
            onDismissRequest = { if (!loading) editStory = null },
            title = { Text("تعديل القصة") },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it.take(1200) },
                    label = { Text(if (story.type.equals("text", true)) "نص القصة" else "وصف القصة") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )
            },
            confirmButton = {
                Button(
                    enabled = !loading && (!story.type.equals("text", true) || editText.isNotBlank()),
                    onClick = {
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.updateStory(session, story.id, editText.trim()) }
                            loading = false
                            r.onSuccess {
                                editStory = null
                                message = "تم تعديل القصة."
                                refresh()
                            }.onFailure { message = it.message }
                        }
                    }
                ) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { editStory = null }, enabled = !loading) { Text("إلغاء") } }
        )
    }

    deleteStory?.let { story ->
        AlertDialog(
            onDismissRequest = { if (!loading) deleteStory = null },
            title = { Text("حذف القصة") },
            text = { Text("هل تريد حذف هذه القصة نهائيًا؟") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.deleteStory(session, story.id) }
                            loading = false
                            r.onSuccess { deleteStory = null; message = "تم حذف القصة."; refresh() }.onFailure { message = it.message }
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleteStory = null }, enabled = !loading) { Text("إلغاء") } }
        )
    }

    if (!initialStoryId.isNullOrBlank() && initialStoryId != "__create__" && viewerIndex < 0 && loading) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }
        return
    }

    if (viewerIndex >= 0 && stories.isNotEmpty()) {
        InstagramStoryViewer(
            stories = stories,
            startIndex = viewerIndex.coerceIn(0, stories.lastIndex),
            session = session,
            api = api,
            onClose = { viewerIndex = -1; onClose() },
            onInteract = { interaction = it },
            onEdit = { editStory = it },
            onDelete = { deleteStory = it }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        if (cfg.bool("stories.show_library_header", true)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(cfg.string("stories.header_title", "قصص Student"), fontWeight = FontWeight.Bold, fontSize = cfg.int("stories.header_title_sp", 17, 12, 24).sp)
                    if (cfg.bool("stories.show_header_subtitle", true)) Text(cfg.string("stories.header_subtitle", "نص، صور وفيديو لمدة 24 ساعة"), color = StudentMuted, fontSize = 11.sp)
                }
                Row {
                    if (cfg.bool("stories.show_refresh_button", true)) IconButton(onClick = { refresh() }) { Icon(Icons.Rounded.Refresh, "تحديث") }
                    if (cfg.bool("stories.show_create_button", true)) FilledIconButton(onClick = { createOpen = true }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = StudentBlue)) {
                        Icon(Icons.Rounded.Add, "إضافة قصة", tint = Color.White)
                    }
                }
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudentBlue)
        message?.let { Text(it, color = if (it.startsWith("تم")) Color(0xFF16803C) else MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp), fontSize = 12.sp) }
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(stories, key = { it.id }) { story ->
                val index = stories.indexOfFirst { it.id == story.id }
                Column(
                    modifier = Modifier.width(cfg.int("stories.library_item_width_dp", 86, 60, 130).dp).clickable { viewerIndex = index },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(cfg.int("stories.library_ring_size_dp", 78, 50, 110).dp).clip(CircleShape).border(cfg.int("stories.library_ring_width_dp", 3, 1, 7).dp, Color(0xFFEF233C), CircleShape).padding(4.dp)) {
                        StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, cfg.int("stories.library_avatar_size_dp", 68, 40, 100).dp)
                    }
                    Text(story.authorName, maxLines = 1, fontSize = cfg.int("stories.library_text_sp", 12, 9, 18).sp)
                }
            }
        }
        if (stories.isEmpty() && !loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد قصص حاليًا.", color = StudentMuted) }
        }

    }
}

@Composable
private fun InstagramStoryViewer(
    stories: List<StoryItem>,
    startIndex: Int,
    session: StudentSession,
    api: SupabaseApi,
    onClose: () -> Unit,
    onInteract: (StoryItem) -> Unit,
    onEdit: (StoryItem) -> Unit,
    onDelete: (StoryItem) -> Unit
) {
    val cfg = LocalNativeRemoteConfig.current
    val pager = rememberPagerState(
        initialPage = startIndex.coerceIn(0, stories.lastIndex),
        pageCount = { stories.size }
    )
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var paused by remember { mutableStateOf(false) }

    fun previous() {
        scope.launch {
            progress.stop()
            paused = false
            if (pager.currentPage > 0) pager.animateScrollToPage(pager.currentPage - 1)
            else onClose()
        }
    }

    fun next() {
        scope.launch {
            progress.stop()
            paused = false
            if (pager.currentPage < stories.lastIndex) pager.animateScrollToPage(pager.currentPage + 1)
            else onClose()
        }
    }

    BackHandler(onBack = onClose)

    LaunchedEffect(pager.currentPage) {
        progress.snapTo(0f)
        paused = false
        val story = stories[pager.currentPage]
        if (story.userId != session.userId) {
            withContext(Dispatchers.IO) { api.markStoryViewed(session, story.id) }
        }
    }

    LaunchedEffect(pager.currentPage, paused) {
        if (paused) {
            progress.stop()
            return@LaunchedEffect
        }
        val story = stories[pager.currentPage]
        val total = if (story.type.equals("video", true)) {
            cfg.long("stories.video_duration_ms", 10000L, 2500L, 60000L)
        } else {
            cfg.long("stories.image_duration_ms", 6000L, 1800L, 30000L)
        }
        val remaining = ((1f - progress.value).coerceIn(0f, 1f) * total).toLong().coerceAtLeast(80L)
        progress.animateTo(1f, animationSpec = tween(remaining.toInt(), easing = LinearEasing))
        if (!paused && progress.value >= .999f) next()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            pageSpacing = 0.dp
        ) { page ->
            val story = stories[page]
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(page, pager.currentPage) {
                        detectTapGestures(
                            onPress = {
                                if (page == pager.currentPage) {
                                    paused = true
                                    tryAwaitRelease()
                                    paused = false
                                }
                            },
                            onTap = { point ->
                                if (page == pager.currentPage) {
                                    if (point.x < size.width / 2f) previous() else next()
                                }
                            }
                        )
                    }
            ) {
                when {
                    story.type.equals("image", true) && !story.mediaUrl.isNullOrBlank() -> AsyncImage(
                        model = story.mediaUrl,
                        contentDescription = "قصة ${story.authorName}",
                        contentScale = if (cfg.string("stories.media_content_scale", "fit").equals("crop", true)) ContentScale.Crop else ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().padding(top = 18.dp, bottom = 66.dp)
                    )
                    story.type.equals("video", true) && !story.mediaUrl.isNullOrBlank() -> AndroidView(
                        factory = { context ->
                            VideoView(context).apply {
                                tag = story.mediaUrl
                                setVideoURI(Uri.parse(story.mediaUrl))
                                setOnPreparedListener { player ->
                                    player.isLooping = false
                                    if (!paused && page == pager.currentPage) start()
                                }
                            }
                        },
                        update = { view ->
                            if (view.tag != story.mediaUrl) {
                                view.tag = story.mediaUrl
                                view.setVideoURI(Uri.parse(story.mediaUrl))
                                view.setOnPreparedListener { player ->
                                    player.isLooping = false
                                    if (!paused && page == pager.currentPage) view.start()
                                }
                            }
                            if (page == pager.currentPage) {
                                if (paused) {
                                    if (view.isPlaying) view.pause()
                                } else if (!view.isPlaying) {
                                    runCatching { view.start() }
                                }
                            } else if (view.isPlaying) {
                                view.pause()
                            }
                        },
                        modifier = Modifier.fillMaxSize().padding(top = 18.dp, bottom = 66.dp)
                    )
                    else -> Box(
                        Modifier.fillMaxSize().background(Color(0xFF402060)).padding(38.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            story.content,
                            color = Color.White,
                            fontSize = cfg.int("stories.text_story_font_sp", 28, 16, 48).sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = cfg.int("stories.text_story_line_sp", 38, 20, 60).sp
                        )
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 18.dp, start = 12.dp, end = 8.dp).align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, 38.dp)
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        StudentName(
                            story.authorName,
                            story.authorVerified,
                            story.authorVerificationColor,
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
                        )
                        Text(prettyTime(story.createdAt), color = Color.White.copy(alpha = .75f), fontSize = 10.sp)
                    }
                    if (paused) {
                        Icon(Icons.Rounded.PauseCircle, "متوقف", tint = Color.White.copy(alpha = .9f))
                    }
                    if (story.userId == session.userId) {
                        IconButton(onClick = { onEdit(story) }) { Icon(Icons.Rounded.Edit, "تعديل", tint = Color.White) }
                        IconButton(onClick = { onDelete(story) }) { Icon(Icons.Rounded.DeleteOutline, "حذف", tint = Color.White) }
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "إغلاق", tint = Color.White) }
                }

                FilledTonalButton(
                    onClick = { onInteract(story) },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color.Black.copy(alpha = .42f),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Icon(
                        if (story.userId == session.userId) Icons.Rounded.Visibility else Icons.Rounded.ChatBubbleOutline,
                        null
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(if (story.userId == session.userId) "المشاهدات والردود" else "رد أو تفاعل")
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            stories.forEachIndexed { i, _ ->
                LinearProgressIndicator(
                    progress = {
                        when {
                            i < pager.currentPage -> 1f
                            i == pager.currentPage -> progress.value
                            else -> 0f
                        }
                    },
                    modifier = Modifier.weight(1f).height(cfg.int("stories.progress_height_dp", 3, 1, 8).dp),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = .28f)
                )
            }
        }
    }
}

@Composable
private fun StoryInteractionDialog(
    api: SupabaseApi,
    session: StudentSession,
    story: StoryItem,
    onDismiss: () -> Unit,
    onMessage: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    val owner = story.userId == session.userId
    var reaction by remember(story.id) { mutableStateOf<String?>(null) }
    var replies by remember(story.id) { mutableStateOf<List<StoryReplyItem>>(emptyList()) }
    var viewers by remember(story.id) { mutableStateOf<List<ProfileSearchItem>>(emptyList()) }
    var reply by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(true) }

    fun refresh() {
        scope.launch {
            busy = true
            if (!owner) reaction = withContext(Dispatchers.IO) { api.myStoryReaction(session, story.id).getOrNull() }
            replies = withContext(Dispatchers.IO) { api.storyReplies(session, story.id).getOrDefault(emptyList()) }
            if (owner) viewers = withContext(Dispatchers.IO) { api.storyViewers(session, story.id).getOrDefault(emptyList()) }
            busy = false
        }
    }

    LaunchedEffect(story.id) { refresh() }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (owner) "نشاط القصة" else "الرد على القصة", fontWeight = FontWeight.Black)
                IconButton(onClick = onDismiss, enabled = !busy) { Icon(Icons.Rounded.Close, "إغلاق") }
            }
        },
        text = {
            LazyColumn(
                Modifier.heightIn(max = 520.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudentBlue) }

                if (!owner) {
                    if (cfg.bool("stories.reactions_enabled", true)) {
                        item {
                            Text("تفاعل سريع", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(
                                    "like" to Icons.Rounded.ThumbUp,
                                    "love" to Icons.Rounded.Favorite,
                                    "wow" to Icons.Rounded.SentimentVerySatisfied
                                ).forEach { (value, icon) ->
                                    FilterChip(
                                        selected = reaction == value,
                                        onClick = {
                                            val next = if (reaction == value) null else value
                                            scope.launch {
                                                val r = withContext(Dispatchers.IO) {
                                                    api.setStoryReaction(session, story.id, next)
                                                }
                                                r.onSuccess { reaction = next }
                                                    .onFailure { onMessage(it.message ?: "تعذر حفظ التفاعل.") }
                                            }
                                        },
                                        label = { Icon(icon, value, Modifier.size(20.dp)) }
                                    )
                                }
                            }
                        }
                    }

                    if (cfg.bool("stories.reply_enabled", true)) {
                        item {
                            OutlinedTextField(
                                value = reply,
                                onValueChange = { reply = it.take(cfg.int("stories.reply_max_chars", 1000, 50, 5000)) },
                                label = { Text("اكتب ردًا") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    if (reply.isBlank()) return@Button
                                    scope.launch {
                                        busy = true
                                        val r = withContext(Dispatchers.IO) {
                                            api.replyToStory(session, story.id, reply.trim())
                                        }
                                        busy = false
                                        r.onSuccess {
                                            reply = ""
                                            onMessage("تم إرسال الرد.")
                                            onDismiss()
                                        }.onFailure {
                                            onMessage(it.message ?: "تعذر إرسال الرد.")
                                        }
                                    }
                                },
                                enabled = reply.isNotBlank() && !busy,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("إرسال") }
                        }
                    }
                } else {
                    item { Text("المشاهدات ${viewers.size}", fontWeight = FontWeight.Black) }
                    items(viewers, key = { it.id }) { viewer ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            StudentAvatar(viewer.fullName, viewer.avatarUrl, viewer.profileFrameUrl, 34.dp)
                            Spacer(Modifier.width(8.dp))
                            StudentName(
                                viewer.fullName,
                                viewer.isVerified,
                                viewer.verificationColor,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    item {
                        HorizontalDivider()
                        Spacer(Modifier.height(6.dp))
                        Text("الردود ${replies.size}", fontWeight = FontWeight.Black)
                    }
                    items(replies, key = { it.id }) { item ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${item.authorName}: ${item.message}", modifier = Modifier.padding(10.dp), color = StudentText)
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}
