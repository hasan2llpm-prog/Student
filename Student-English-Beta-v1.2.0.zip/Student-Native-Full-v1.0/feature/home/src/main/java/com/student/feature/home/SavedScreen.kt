package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SavedScreen(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<SavedItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(2800); message = null } }
    var filter by remember { mutableStateOf("all") }

    fun refresh() {
        scope.launch {
            loading = true
            val r = withContext(Dispatchers.IO) { api.savedItems(session) }
            r.onSuccess { items = it }.onFailure { message = it.message }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    val shown = if (filter == "all") items else items.filter { it.contentType == filter }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("all" to "الكل", "post" to "منشور", "story" to "قصة", "lesson" to "درس").forEach { (key, label) ->
                FilterChip(selected = filter == key, onClick = { filter = key }, label = { Text(label) })
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { item ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(typeLabel(item.contentType), style = MaterialTheme.typography.titleMedium)
                            Text(item.contentId, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                            Text(prettyTime(item.createdAt), style = MaterialTheme.typography.labelSmall)
                        }
                        TextButton(onClick = {
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { api.deleteSavedItem(session, item.id) }
                                r.onSuccess { refresh() }.onFailure { message = it.message }
                            }
                        }) { Text("إزالة") }
                    }
                }
            }
            if (shown.isEmpty() && !loading) item { Text("لا توجد عناصر محفوظة.") }
        }
    }
}

private fun typeLabel(type: String): String = when (type) {
    "post" -> "منشور"
    "story" -> "قصة"
    "lesson" -> "درس"
    "file" -> "ملف"
    "video" -> "فيديو"
    else -> type.ifBlank { "محتوى" }
}
