package com.student.feature.home

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.student.core.data.StudentSession
import com.student.core.data.SupabaseApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import kotlin.math.absoluteValue

@Composable
fun EnglishAcademyScreen(api: SupabaseApi, session: StudentSession, initialSection: String = "hub") {
    var section by remember(initialSection) { mutableStateOf(initialSection) }
    if (section == "hub") EnglishLearningHub { section = it }
    else {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { section = "hub" }) { Icon(Icons.Rounded.ArrowBack, "رجوع") }
                Text(sectionTitle(section), fontWeight = FontWeight.Black, fontSize = 20.sp, color = StudentText)
            }
            HorizontalDivider(color = StudentBorder)
            Box(Modifier.fillMaxSize()) {
                when (section) {
                    "vocabulary" -> VocabularySection(api, session)
                    "parts" -> LessonSection("Parts of Speech • Relations • Functions", EnglishSeedContent.posLessons)
                    "verbs" -> VerbsSection()
                    "grammar" -> LessonSection("Grammar & Tenses", EnglishSeedContent.grammarLessons)
                    "reading" -> ReadingSection()
                    "listening" -> ListeningSection()
                    "pronunciation" -> PronunciationSection()
                    "phrasal" -> SimpleDailySection("Phrasal Verbs", listOf("look after — يعتني بـ","find out — يكتشف / يعرف","give up — يستسلم","turn on — يشغّل","pick up — يلتقط"))
                    "idioms" -> SimpleDailySection("Idioms & Expressions", listOf("piece of cake — سهل جداً","break the ice — يكسر حاجز الصمت","once in a blue moon — نادراً جداً","under the weather — متوعك","keep an eye on — يراقب"))
                    "spelling" -> SpellingSection()
                    "writing" -> WritingSection()
                    "speaking" -> SpeakingSection()
                    "progress" -> EnglishProgressSection()
                    "daily" -> DailyChallenge()
                    else -> EnglishLearningHub { section = it }
                }
            }
        }
    }
}

private fun sectionTitle(key: String) = when(key) {
    "vocabulary" -> "تعلم المفردات"
    "parts" -> "Parts of Speech"
    "verbs" -> "الأفعال"
    "grammar" -> "الأزمنة والقواعد"
    "reading" -> "Reading"
    "listening" -> "Listening"
    "pronunciation" -> "Pronunciation"
    "phrasal" -> "Phrasal Verbs"
    "idioms" -> "Idioms"
    "spelling" -> "Spelling"
    "writing" -> "Writing"
    "speaking" -> "Speaking"
    "progress" -> "تقدمي"
    "daily" -> "Daily Challenge"
    else -> "Learn English"
}

@Composable
private fun EnglishLearningHub(onOpen: (String) -> Unit) {
    val cards = listOf(
        Triple("vocabulary","تعلم المفردات","5 كلمات + مراجعة ذكية واختبارات"),
        Triple("parts","Parts of Speech","الأنواع والعلاقات والوظائف"),
        Triple("verbs","Regular & Irregular Verbs","5 شاذة + 5 قياسية ومراجعة"),
        Triple("grammar","Grammar & Tenses","قواعد وأزمنة واختبار يومي"),
        Triple("reading","Reading","قطعة + نطق + 5 أسئلة"),
        Triple("listening","Listening","استماع وفهم تدريجي"),
        Triple("pronunciation","Pronunciation","نطق أمريكي وبريطاني"),
        Triple("phrasal","Phrasal Verbs","أفعال مركبة شائعة"),
        Triple("idioms","Idioms & Expressions","تعبيرات مستخدمة فعلياً"),
        Triple("spelling","Spelling","اسمع واكتب وصحح فوراً"),
        Triple("writing","Writing","تمرين كتابة يومي بخطوات واضحة"),
        Triple("speaking","Speaking","مواقف يومية ونطق نموذجي"),
        Triple("progress","تقدمي","راجع إنجازك والكلمات المحفوظة"),
        Triple("daily","Daily Challenge","اختبار يومي مختلط")
    )
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFF111827), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("English Learning Path", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("تعلم يومي تلقائي • مراجعة متباعدة • اختبارات فورية", color = Color(0xFFD1D5DB))
                }
            }
        }
        items(cards) { (key,title,sub) ->
            StudentOutlinedCard(Modifier.fillMaxWidth().clickable { onOpen(key) }) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(15.dp), color = StudentSoft, modifier = Modifier.size(48.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(iconFor(key), null, tint = StudentBlue) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Black, color = StudentText); Text(sub, color = StudentMuted, fontSize = 12.sp) }
                    Icon(Icons.Rounded.ChevronRight, null, tint = StudentMuted)
                }
            }
        }
    }
}

private fun iconFor(key:String) = when(key) {
    "vocabulary" -> Icons.Rounded.MenuBook
    "parts" -> Icons.Rounded.AccountTree
    "verbs" -> Icons.Rounded.SyncAlt
    "grammar" -> Icons.Rounded.Spellcheck
    "reading" -> Icons.Rounded.Article
    "listening" -> Icons.Rounded.Headphones
    "pronunciation" -> Icons.Rounded.RecordVoiceOver
    "phrasal" -> Icons.Rounded.Hub
    "idioms" -> Icons.Rounded.Lightbulb
    "spelling" -> Icons.Rounded.EditNote
    "writing" -> Icons.Rounded.Draw
    "speaking" -> Icons.Rounded.Mic
    "progress" -> Icons.Rounded.Insights
    else -> Icons.Rounded.EmojiEvents
}

@Composable
private fun VocabularySection(api: SupabaseApi, session: StudentSession) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("student_english", Context.MODE_PRIVATE) }
    val speech = rememberStudentSpeechController()
    val scope = rememberCoroutineScope()
    var remoteWords by remember { mutableStateOf<List<EnglishWord>>(emptyList()) }
    LaunchedEffect(session.userId) {
        withContext(Dispatchers.IO) { api.englishVocabulary(session, limit = 500) }
            .onSuccess { rows ->
                if (rows.isNotEmpty()) remoteWords = rows.map { row ->
                    EnglishWord(row.id, row.word, row.meaningAr, row.level, row.exampleEn.ifBlank { row.word }, row.exampleAr)
                }
            }
    }
    val sourceWords = if (remoteWords.isNotEmpty()) remoteWords else EnglishSeedContent.words
    val day = LocalDate.now().dayOfMonth
    val newWordDays = listOf(1,2,3,5,6)
    val groupIndex = newWordDays.indexOf(day).takeIf { it >= 0 } ?: ((day - 1) / 7).coerceIn(0,4)
    val start = (groupIndex * 5).coerceAtMost((sourceWords.size - 5).coerceAtLeast(0))
    val today = sourceWords.drop(start).take(5)
    val reviewDay = day !in newWordDays
    var accent by remember { mutableStateOf("american") }
    var speed by remember { mutableStateOf("normal") }
    var quiz by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    if (quiz) { VocabularyQuiz(today, onClose = { quiz = false }); return }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (reviewDay) "مراجعة اليوم" else "كلمات اليوم", fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text("الخطة الشهرية: 25 كلمة أساسية، وبعدها مراجعات واختبارات متباعدة.", color = StudentMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(accent=="american", {accent="american"}, {Text("US")})
                        FilterChip(accent=="british", {accent="british"}, {Text("UK")})
                        FilterChip(speed=="slow", {speed="slow"}, {Text("بطيء")})
                        FilterChip(speed=="normal", {speed="normal"}, {Text("عادي")})
                    }
                    Button(onClick={quiz=true}, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Quiz,null); Spacer(Modifier.width(6.dp)); Text("اختبار سريع") }
                    message?.let { Text(it, color=Color(0xFF16834A), fontWeight=FontWeight.Bold) }
                }
            }
        }
        items(today, key={it.id}) { w ->
            var expanded by remember(w.id) { mutableStateOf(false) }
            val saved = prefs.getBoolean("review_${w.id}", false)
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(w.word, fontSize=22.sp, fontWeight=FontWeight.Black); Text("${w.meaningAr}  •  ${w.level}", color=StudentBlue, fontWeight=FontWeight.Bold) }
                        IconButton(onClick={speech.speak(w.word,accent,speed)}) { Icon(Icons.Rounded.VolumeUp,"نطق") }
                    }
                    OutlinedButton(onClick={expanded=!expanded}, modifier=Modifier.fillMaxWidth()) { Text(if(expanded) "إخفاء المثال" else "ضعها في جملة") }
                    if(expanded) {
                        Text(w.example, fontWeight=FontWeight.Bold); Text(w.exampleAr, color=StudentMuted)
                        Button(onClick={speech.speak(w.example,accent,speed)}, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Rounded.GraphicEq,null); Spacer(Modifier.width(6.dp)); Text("نطق الجملة") }
                    }
                    OutlinedButton(onClick={
                        prefs.edit().putBoolean("review_${w.id}", true).apply()
                        scope.launch { withContext(Dispatchers.IO) { api.rememberEnglishWord(session, w.word) } }
                        message="تمت إضافة ${w.word} إلى المراجعة اللاحقة."
                    }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.outlinedButtonColors(contentColor=if(saved) Color(0xFF16834A) else StudentBlue)) {
                        Icon(if(saved) Icons.Rounded.CheckCircle else Icons.Rounded.NotificationsActive,null); Spacer(Modifier.width(6.dp)); Text(if(saved) "محفوظة للمراجعة" else "ذكرني بها لاحقاً")
                    }
                }
            }
        }
    }
}

@Composable
private fun VocabularyQuiz(words: List<EnglishWord>, onClose:()->Unit) {
    var index by remember { mutableIntStateOf(0) }; var score by remember { mutableIntStateOf(0) }; var feedback by remember { mutableStateOf<String?>(null) }
    if(index >= words.size) {
        Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { StudentOutlinedCard(Modifier.padding(20.dp)) { Column(Modifier.padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(12.dp)) { Text("النتيجة $score / ${words.size}", fontSize=24.sp,fontWeight=FontWeight.Black); Button(onClick=onClose){Text("إنهاء")}}}}; return
    }
    val w=words[index]; val pool=(EnglishSeedContent.words.filter{it.id!=w.id}.map{it.meaningAr}.shuffled().take(3)+w.meaningAr).shuffled()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("اختر معنى: ${w.word}",fontSize=22.sp,fontWeight=FontWeight.Black)
        pool.forEach { answer -> OutlinedButton(onClick={ if(feedback==null){ val ok=answer==w.meaningAr; if(ok)score++; feedback=if(ok)"✓ صحيح" else "✗ الصحيح: ${w.meaningAr}" } }, modifier=Modifier.fillMaxWidth()){Text(answer)} }
        feedback?.let { Text(it,color=if(it.startsWith("✓"))Color(0xFF16834A) else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold); Button(onClick={index++;feedback=null},modifier=Modifier.fillMaxWidth()){Text("التالي")}}
    }
}

@Composable
private fun LessonSection(title:String, lessons:List<EnglishMiniLesson>) {
    val day=(LocalDate.now().dayOfYear.absoluteValue % lessons.size); val lesson=lessons[day]
    var chosen by remember(lesson.id){mutableStateOf<Int?>(null)}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("درس اليوم",color=StudentBlue,fontWeight=FontWeight.Bold); Text(lesson.title,fontSize=24.sp,fontWeight=FontWeight.Black); Text(lesson.summary,color=StudentMuted); Surface(color=StudentSoft,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Text(lesson.example,Modifier.padding(13.dp),fontWeight=FontWeight.Bold)} }
        item { Text("اختبار فوري",fontSize=18.sp,fontWeight=FontWeight.Black); Text(lesson.question) }
        items(lesson.options.size){ i -> OutlinedButton(onClick={chosen=i},modifier=Modifier.fillMaxWidth(),border=BorderStroke(1.dp, if(chosen==i)StudentBlue else StudentBorder)){Text(lesson.options[i])} }
        chosen?.let { c -> item { Text(if(c==lesson.correctIndex)"✓ إجابة صحيحة" else "✗ الإجابة الصحيحة: ${lesson.options[lesson.correctIndex]}",color=if(c==lesson.correctIndex)Color(0xFF16834A) else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold) } }
    }
}

@Composable
private fun VerbsSection() {
    val speech=rememberStudentSpeechController(); val irregular=EnglishSeedContent.words.filter{it.irregular}.take(5)
    val regular=listOf("work — worked — worked","play — played — played","study — studied — studied","open — opened — opened","watch — watched — watched")
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("5 أفعال شاذة اليوم",fontSize=20.sp,fontWeight=FontWeight.Black) }
        items(irregular){w-> StudentOutlinedCard(Modifier.fillMaxWidth()){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(w.word,fontWeight=FontWeight.Black);Text("${w.past} • ${w.participle} — ${w.meaningAr}",color=StudentMuted)};IconButton(onClick={speech.speak("${w.word}, ${w.past}, ${w.participle}","american","normal")}){Icon(Icons.Rounded.VolumeUp,"نطق")}}}}
        item { Text("5 أفعال قياسية اليوم",fontSize=20.sp,fontWeight=FontWeight.Black) }
        items(regular){v-> StudentOutlinedCard(Modifier.fillMaxWidth()){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Text(v,Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton(onClick={speech.speak(v.substringBefore(" —"),"american","normal")}){Icon(Icons.Rounded.VolumeUp,"نطق")}}}}
    }
}

@Composable
private fun ReadingSection() {
    val speech = rememberStudentSpeechController()
    val item = EnglishSeedContent.readingPassages[LocalDate.now().dayOfYear % EnglishSeedContent.readingPassages.size]
    val answers = listOf(
        listOf("To improve his English", "To learn math", "To travel", "To sleep"),
        listOf("Five", "Ten", "Two", "Twenty"),
        listOf("Reviewed words and wrote sentences", "Watched TV", "Played games", "Slept"),
        listOf("Reading", "Driving", "Cooking", "Running"),
        listOf("More confident", "More tired", "Angry", "Confused")
    )
    val correct = listOf(0,0,0,0,0)
    var selected by remember(item.first) { mutableStateOf<Map<Int,Int>>(emptyMap()) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(item.first, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text(item.second, lineHeight = 24.sp)
            Button(onClick = { speech.speak(item.second, "british", "slow") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Headphones, null)
                Spacer(Modifier.width(6.dp))
                Text("استمع للقطعة")
            }
            Text("5 أسئلة MCQ", fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
        items(item.third.size) { i ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${i + 1}. ${item.third[i]}", fontWeight = FontWeight.Bold)
                    answers.getOrElse(i) { listOf("A","B","C","D") }.forEachIndexed { optionIndex, option ->
                        OutlinedButton(
                            onClick = { selected = selected + (i to optionIndex) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(option) }
                    }
                    selected[i]?.let { choice ->
                        Text(
                            if (choice == correct[i]) "✓ صحيح" else "✗ حاول مراجعة القطعة مرة أخرى",
                            color = if (choice == correct[i]) Color(0xFF16834A) else MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ListeningSection() {
    val speech = rememberStudentSpeechController()
    val text = "Learning a language becomes easier when you practise a little every day."
    var show by remember { mutableStateOf(false) }
    var answer by remember { mutableStateOf<Int?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("استماع اليوم", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Button(onClick = { speech.speak(text, "british", "slow") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Headphones, null); Spacer(Modifier.width(6.dp)); Text("استمع")
        }
        OutlinedButton(onClick = { show = !show }, modifier = Modifier.fillMaxWidth()) {
            Text(if (show) "إخفاء النص" else "إظهار النص بعد الاستماع")
        }
        if (show) Text(text, fontWeight = FontWeight.Bold)
        Text("ما الفكرة الرئيسية؟", fontWeight = FontWeight.Black)
        listOf("الممارسة اليومية القصيرة تساعد على التعلم","السفر ضروري للتعلم","القواعد غير مهمة","اللغة لا تحتاج ممارسة").forEachIndexed { i, option ->
            OutlinedButton(onClick = { answer = i }, modifier = Modifier.fillMaxWidth()) { Text(option) }
        }
        answer?.let { Text(if (it == 0) "✓ صحيح" else "✗ حاول مرة أخرى", color = if (it == 0) Color(0xFF16834A) else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun PronunciationSection() {
    val speech = rememberStudentSpeechController()
    val pairs = listOf("ship / sheep", "live / leave", "full / fool", "bit / beat", "hat / hot")
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text("Minimal Pairs", fontSize = 23.sp, fontWeight = FontWeight.Black); Text("استمع للفرق بين الأصوات.", color = StudentMuted) }
        items(pairs) { pair ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(pair, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { speech.speak(pair.replace("/", ","), "american", "slow") }) { Icon(Icons.Rounded.VolumeUp, "US") }
                    IconButton(onClick = { speech.speak(pair.replace("/", ","), "british", "slow") }) { Icon(Icons.Rounded.RecordVoiceOver, "UK") }
                }
            }
        }
    }
}

@Composable
private fun SimpleDailySection(title: String, itemsList: List<String>) {
    val speech = rememberStudentSpeechController()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text(title, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("مجموعة اليوم", color = StudentMuted) }
        items(itemsList) { value ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(value, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { speech.speak(value.substringBefore(" —"), "american", "normal") }) { Icon(Icons.Rounded.VolumeUp, "نطق") }
                }
            }
        }
    }
}

@Composable
private fun SpellingSection() {
    val speech = rememberStudentSpeechController()
    val word = EnglishSeedContent.words[LocalDate.now().dayOfYear % EnglishSeedContent.words.size]
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("اسمع واكتب", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Button(onClick = { speech.speak(word.word, "american", "slow") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.VolumeUp, null); Spacer(Modifier.width(6.dp)); Text("اسمع الكلمة")
        }
        OutlinedTextField(input, { input = it.lowercase().filter(Char::isLetter) }, label = { Text("اكتب الكلمة") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { result = if (input.equals(word.word, true)) "✓ صحيح" else "✗ الصحيح: ${word.word}" }, modifier = Modifier.fillMaxWidth()) { Text("تحقق") }
        result?.let { Text(it, color = if (it.startsWith("✓")) Color(0xFF16834A) else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun DailyChallenge() {
    val questions = EnglishSeedContent.grammarLessons.take(3)
    var score by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf(setOf<String>()) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("تحدي اليوم", fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("النتيجة الحالية: $score / ${questions.size}", color = StudentBlue, fontWeight = FontWeight.Bold)
        }
        items(questions) { q ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(q.question, fontWeight = FontWeight.Black)
                    q.options.forEachIndexed { i, option ->
                        OutlinedButton(
                            onClick = {
                                if (q.id !in done) {
                                    done = done + q.id
                                    if (i == q.correctIndex) score++
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(option) }
                    }
                    if (q.id in done) Text("الإجابة: ${q.options[q.correctIndex]}", color = Color(0xFF16834A), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


@Composable
private fun WritingSection() {
    val prompts = listOf(
        "Write 5 sentences about your daily routine.",
        "Describe a person you admire in 5–7 sentences.",
        "Write a short paragraph about why learning English is important.",
        "Write a message inviting a friend to study with you.",
        "Describe your city using at least three adjectives."
    )
    val prompt = prompts[LocalDate.now().dayOfYear % prompts.size]
    var answer by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf(false) }
    val sentenceCount = remember(answer) { answer.split(Regex("[.!?]+")).count { it.trim().isNotBlank() } }
    val wordCount = remember(answer) { answer.trim().split(Regex("\\s+")).count { it.isNotBlank() } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Writing Task", fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text(prompt, color = StudentBlue, fontWeight = FontWeight.Bold)
        }
        item {
            OutlinedTextField(
                value = answer,
                onValueChange = { answer = it.take(1800); checked = false },
                label = { Text("اكتب إجابتك بالإنجليزية") },
                minLines = 8,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Text("$wordCount كلمة • $sentenceCount جملة", color = StudentMuted)
            Button(onClick = { checked = true }, enabled = answer.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text("فحص سريع")
            }
        }
        if (checked) item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("مراجعة ذاتية", fontWeight = FontWeight.Black)
                    Text(if (wordCount >= 25) "✓ الطول مناسب" else "• حاول كتابة 25 كلمة على الأقل")
                    Text(if (sentenceCount >= 4) "✓ عدد الجمل مناسب" else "• أضف جمل أكثر")
                    Text(if (answer.firstOrNull()?.isUpperCase() == true) "✓ بدأت بحرف كبير" else "• ابدأ الجملة بحرف كبير")
                    Text(if (answer.trim().lastOrNull() in listOf('.', '!', '?')) "✓ علامة نهاية موجودة" else "• أضف علامة نهاية للجملة")
                }
            }
        }
    }
}

@Composable
private fun SpeakingSection() {
    val speech = rememberStudentSpeechController()
    val tasks = listOf(
        "Introduce yourself in five sentences.",
        "Talk about your university or school.",
        "Describe what you did yesterday.",
        "Explain your plans for next weekend.",
        "Describe your favourite book, film, or game."
    )
    val task = tasks[LocalDate.now().dayOfYear % tasks.size]
    val model = when {
        task.startsWith("Introduce") -> "Hello. My name is ... I am from ... I study ... In my free time, I like ... My goal is to improve my English."
        task.startsWith("Talk") -> "I study at ... My favourite subject is ... I enjoy learning because ..."
        task.startsWith("Describe what") -> "Yesterday, I woke up at ... Then I ... In the evening, I ..."
        task.startsWith("Explain") -> "Next weekend, I am going to ... I hope to ... because ..."
        else -> "My favourite ... is ... I like it because ... I would recommend it to ..."
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Speaking Task", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text(task, color = StudentBlue, fontWeight = FontWeight.Bold)
        StudentOutlinedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("نموذج مساعد", fontWeight = FontWeight.Black)
                Text(model)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { speech.speak(model, "american", "slow") }) { Text("US بطيء") }
                    OutlinedButton(onClick = { speech.speak(model, "british", "normal") }) { Text("UK") }
                }
            }
        }
        Text("تكلم بصوت مرتفع ثم أعد النموذج وحاول تقليد الإيقاع والنطق.", color = StudentMuted)
    }
}

@Composable
private fun EnglishProgressSection() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("student_english", Context.MODE_PRIVATE) }
    val reviewCount = remember { EnglishSeedContent.words.count { prefs.getBoolean("review_${it.id}", false) } }
    val day = LocalDate.now().dayOfMonth
    val completedDays = (day - 1).coerceAtLeast(0)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("تقدمي", fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("ملخص سريع لمسارك الحالي", color = StudentMuted)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StudentOutlinedCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("$reviewCount", fontSize = 26.sp, fontWeight = FontWeight.Black, color = StudentBlue)
                        Text("كلمات للمراجعة", fontSize = 12.sp, color = StudentMuted)
                    }
                }
                StudentOutlinedCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("$completedDays", fontSize = 26.sp, fontWeight = FontWeight.Black, color = StudentBlue)
                        Text("أيام هذا الشهر", fontSize = 12.sp, color = StudentMuted)
                    }
                }
            }
        }
        item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("خطة اليوم", fontWeight = FontWeight.Black)
                    Text("1. مفردات اليوم")
                    Text("2. درس قواعد أو Parts of Speech")
                    Text("3. استماع أو قراءة")
                    Text("4. مراجعة الكلمات المحفوظة")
                    Text("5. Daily Challenge")
                }
            }
        }
    }
}
