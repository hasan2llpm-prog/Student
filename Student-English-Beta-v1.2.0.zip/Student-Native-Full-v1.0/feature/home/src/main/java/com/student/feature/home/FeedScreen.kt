@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.student.feature.home

import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FeedScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    onOpenStories: (String?) -> Unit,
    onOpenProfile: () -> Unit,
    onOpenEducation: (String) -> Unit,
    onOpenStudentAi: () -> Unit,
    onOpenLearnEnglish: () -> Unit,
    onOpenEnglishSection: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var ads by remember { mutableStateOf<List<HomeAd>>(emptyList()) }
    var featureFlags by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            loading = true
            val loaded = withContext(Dispatchers.IO) {
                Triple(api.stories(session, 30), api.homeAds(session), api.featureFlags(session))
            }
            loaded.first.onSuccess { stories = it }
            loaded.second.onSuccess { ads = it }
            loaded.third.onSuccess { flags -> featureFlags = flags.associate { it.key.lowercase() to it.enabled } }
            loading = false
        }
    }
    LaunchedEffect(session.userId) { refresh() }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        if (loading && cfg.bool("home.show_loading_bar", true)) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFF169CF0))
        if (cfg.bool("home.show_stories", true)) {
            HomeStoriesStrip(stories, profile, onOpenStories, onOpenProfile)
            if (cfg.bool("home.show_story_divider", true)) HorizontalDivider(color = Color(0xFFE8E8E8))
        }

        if (cfg.bool("home.show_features", true)) {
            Spacer(Modifier.height(cfg.int("home.features_top_space_dp", 14, 0, 60).dp))
            EnglishHomeFeatureGrid(
                featureFlags = featureFlags,
                onTranslation = onOpenStudentAi,
                onOpenSection = onOpenEnglishSection
            )
        }

        val showAds = cfg.bool("home.show_ads", true) && ads.isNotEmpty()
        val adsPosition = cfg.string("home.ads_position", "center").lowercase()
        when {
            showAds && adsPosition == "after_features" -> {
                Spacer(Modifier.height(cfg.int("home.ads_top_space_dp", 10, 0, 50).dp))
                HomeAdsCarousel(ads)
                Spacer(Modifier.weight(1f))
            }
            showAds && adsPosition == "center" -> {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    HomeAdsCarousel(ads)
                }
            }
            showAds -> {
                Spacer(Modifier.weight(1f))
                HomeAdsCarousel(ads)
                Spacer(Modifier.height(cfg.int("home.ads_bottom_space_dp", 10, 0, 50).dp))
            }
            else -> Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun HomeStoriesStrip(
    stories: List<StoryItem>,
    profile: StudentProfile?,
    onOpenStories: (String?) -> Unit,
    onOpenProfile: () -> Unit
) {
    val cfg = LocalNativeRemoteConfig.current
    LazyRow(
        modifier = Modifier.fillMaxWidth().height(cfg.int("home.stories_height_dp", 126, 92, 220).dp),
        contentPadding = PaddingValues(horizontal = cfg.int("home.stories_padding_horizontal_dp", 14, 0, 40).dp, vertical = cfg.int("home.stories_padding_vertical_dp", 10, 0, 30).dp),
        horizontalArrangement = Arrangement.spacedBy(cfg.int("home.stories_spacing_dp", 10, 4, 32).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        item {
            HomeStoryCircle(
                name = "ستوري",
                avatarUrl = profile?.avatarUrl,
                frameUrl = profile?.profileFrameUrl,
                addBadge = true,
                ringColor = Color(0xFF159BF0),
                onClick = { onOpenStories("__create__") }
            )
        }
        item {
            val own = stories.firstOrNull { it.userId == profile?.id }
            HomeStoryCircle(
                name = "قصتي",
                avatarUrl = own?.authorAvatarUrl ?: profile?.avatarUrl,
                frameUrl = own?.authorFrameUrl ?: profile?.profileFrameUrl,
                mediaUrl = own?.takeIf { it.type.equals("image", true) }?.mediaUrl,
                ringColor = Color(0xFFEF233C),
                onClick = { onOpenStories(own?.id ?: "__create__") }
            )
        }
        items(stories.filter { it.userId != profile?.id }.take(cfg.int("home.story_limit", 12, 1, 40)), key = { it.id }) { story ->
            HomeStoryCircle(
                name = story.authorName,
                avatarUrl = story.authorAvatarUrl,
                frameUrl = story.authorFrameUrl,
                mediaUrl = story.takeIf { it.type.equals("image", true) }?.mediaUrl,
                ringColor = Color(0xFFEF233C),
                onClick = { onOpenStories(story.id) }
            )
        }
    }
}

@Composable
private fun HomeStoryCircle(
    name: String,
    avatarUrl: String?,
    frameUrl: String?,
    mediaUrl: String? = null,
    addBadge: Boolean = false,
    ringColor: Color,
    onClick: () -> Unit
) {
    val cfg = LocalNativeRemoteConfig.current
    val ringSize = cfg.int("home.story_ring_size_dp", 70, 52, 120).dp
    val avatarSize = cfg.int("home.story_avatar_size_dp", 58, 40, 100).dp
    val ringWidth = cfg.int("home.story_ring_width_dp", 4, 1, 8).dp
    Column(
        modifier = Modifier.width(cfg.int("home.story_item_width_dp", 78, 60, 140).dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Box(
                modifier = Modifier.size(ringSize).clip(CircleShape).border(ringWidth, ringColor, CircleShape).padding(ringWidth),
                contentAlignment = Alignment.Center
            ) {
                if (!mediaUrl.isNullOrBlank()) {
                    AsyncImage(mediaUrl, "ستوري", Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
                } else {
                    StudentAvatar(name, avatarUrl, frameUrl, avatarSize)
                }
            }
            if (addBadge) {
                Surface(
                    modifier = Modifier.size(cfg.int("home.story_add_badge_size_dp", 25, 18, 42).dp), shape = CircleShape, color = Color(0xFFEF233C),
                    border = BorderStroke(3.dp, Color.White)
                ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Add, "إضافة ستوري", tint = Color.White, modifier = Modifier.size(cfg.int("home.story_add_icon_size_dp", 16, 12, 28).dp)) } }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(name, maxLines = 1, fontSize = cfg.int("home.story_text_sp", 12, 9, 18).sp, color = StudentText)
    }
}

@Composable
private fun EnglishHomeFeatureGrid(
    featureFlags: Map<String, Boolean>,
    onTranslation: () -> Unit,
    onOpenSection: (String) -> Unit
) {
    val cfg = LocalNativeRemoteConfig.current
    val items = listOf(
        Triple("translation", "الترجمة", Icons.Rounded.Translate),
        Triple("vocabulary", "المفردات", Icons.Rounded.MenuBook),
        Triple("parts", "Parts of Speech", Icons.Rounded.AccountTree),
        Triple("verbs", "الأفعال", Icons.Rounded.SyncAlt),
        Triple("grammar", "القواعد", Icons.Rounded.Spellcheck),
        Triple("reading", "Reading", Icons.Rounded.Article),
        Triple("listening", "Listening", Icons.Rounded.Headphones),
        Triple("pronunciation", "Pronunciation", Icons.Rounded.RecordVoiceOver),
        Triple("daily", "Daily Challenge", Icons.Rounded.EmojiEvents)
    ).filter { (key,_,_) ->
        val remoteEnabled = cfg.bool("english.feature_$key", true)
        val adminEnabled = featureFlags["english_$key"] ?: true
        remoteEnabled && adminEnabled
    }

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items.chunked(3).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { (key,label,icon) ->
                    Card(
                        modifier = Modifier.weight(1f).height(92.dp).clickable { if (key == "translation") onTranslation() else onOpenSection(key) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE6EAF0))
                    ) {
                        Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(icon, null, tint = StudentBlue, modifier = Modifier.size(29.dp))
                            Spacer(Modifier.height(6.dp))
                            Text(label, color = StudentText, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun HomeFeatureGrid(
    onPrimary: () -> Unit,
    onMiddle: () -> Unit,
    onSecondary: () -> Unit,
    onUniversity: () -> Unit,
    onAi: () -> Unit,
    onLearnEnglish: () -> Unit
) {
    val cfg = LocalNativeRemoteConfig.current
    val defaultOrder = listOf("primary", "middle", "secondary", "university", "student_ai", "learn_english")
    val order = cfg.strings("home.feature_order", defaultOrder).map { it.lowercase() }.distinct()
    val visible = order.filter { key ->
        when (key) {
            "primary" -> cfg.bool("home.feature_primary", true)
            "middle" -> cfg.bool("home.feature_middle", true)
            "secondary" -> cfg.bool("home.feature_secondary", true)
            "university" -> cfg.bool("home.feature_university", true)
            "student_ai" -> cfg.bool("home.feature_student_ai", true)
            "learn_english" -> cfg.bool("home.feature_learn_english", true)
            else -> false
        }
    }
    val topCount = cfg.int("home.feature_top_count", 5, 1, 6)
    val top = visible.take(topCount)
    val bottom = visible.drop(topCount)

    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = cfg.int("home.feature_padding_horizontal_dp", 10, 0, 28).dp),
        verticalArrangement = Arrangement.spacedBy(cfg.int("home.feature_row_spacing_dp", 9, 0, 24).dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Top) {
            top.forEach { key -> HomeCircleFeatureForKey(key, cfg, onPrimary, onMiddle, onSecondary, onUniversity, onAi, onLearnEnglish) }
        }
        if (bottom.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Top) {
                bottom.forEach { key ->
                    HomeCircleFeatureForKey(key, cfg, onPrimary, onMiddle, onSecondary, onUniversity, onAi, onLearnEnglish)
                    Spacer(Modifier.width(cfg.int("home.feature_bottom_spacing_dp", 8, 0, 24).dp))
                }
            }
        }
    }
}

@Composable
private fun HomeCircleFeatureForKey(
    key: String,
    cfg: NativeRemoteConfig,
    onPrimary: () -> Unit,
    onMiddle: () -> Unit,
    onSecondary: () -> Unit,
    onUniversity: () -> Unit,
    onAi: () -> Unit,
    onLearnEnglish: () -> Unit
) {
    when (key) {
        "primary" -> HomeCircleFeature(Icons.Rounded.School, cfg.string("home.label_primary", "الابتدائي"), Color(0xFFE7F6FF), Color(0xFF159BF0), onPrimary)
        "middle" -> HomeCircleFeature(Icons.Rounded.AccountBalance, cfg.string("home.label_middle", "الإعدادي"), Color(0xFFF0EAFE), Color(0xFF7357D9), onMiddle)
        "secondary" -> HomeCircleFeature(Icons.Rounded.AccountBalance, cfg.string("home.label_secondary", "الثانوي"), Color(0xFFE9F8F2), Color(0xFF138B62), onSecondary)
        "university" -> HomeCircleFeature(Icons.Rounded.AccountBalance, cfg.string("home.label_university", "الجامعة"), Color(0xFFFFF6D9), Color(0xFFB87500), onUniversity)
        "student_ai" -> HomeCircleFeature(Icons.Rounded.Translate, cfg.string("home.label_translation", "الترجمة"), Color(0xFFF2E6FF), Color(0xFF8B42D9), onAi)
        "learn_english" -> HomeCircleFeature(Icons.Rounded.Translate, cfg.string("home.label_learn_english", "Learn English"), Color(0xFFE5F7F8), Color(0xFF138A94), onLearnEnglish)
    }
}

@Composable
private fun HomeCircleFeature(icon: ImageVector, title: String, bg: Color, tint: Color, onClick: () -> Unit) {
    val cfg = LocalNativeRemoteConfig.current
    val itemWidth = cfg.int("home.feature_item_width_dp", 64, 48, 92).dp
    val circleSize = cfg.int("home.feature_circle_size_dp", 58, 42, 82).dp
    Column(
        modifier = Modifier.width(itemWidth).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(circleSize),
            shape = CircleShape,
            color = bg,
            border = BorderStroke(cfg.int("home.feature_border_width_dp", 1, 0, 3).dp, tint.copy(alpha = .16f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, title, tint = tint, modifier = Modifier.size(cfg.int("home.feature_icon_size_dp", 28, 18, 42).dp))
            }
        }
        Spacer(Modifier.height(cfg.int("home.feature_label_gap_dp", 6, 2, 14).dp))
        Text(
            title,
            color = StudentText,
            fontWeight = FontWeight.Bold,
            fontSize = cfg.int("home.feature_text_sp", 11, 9, 15).sp,
            maxLines = 1
        )
    }
}

@Composable
private fun HomeAdsCarousel(ads: List<HomeAd>) {
    val cfg = LocalNativeRemoteConfig.current
    val uri = LocalUriHandler.current
    val pager = rememberPagerState(pageCount = { ads.size })
    LaunchedEffect(ads.size) {
        if (ads.size > 1) {
            while (true) {
                delay(cfg.long("home.ad_interval_ms", 4500L, 1500L, 30000L))
                if (!pager.isScrollInProgress) {
                    val next = (pager.currentPage + 1) % ads.size
                    pager.animateScrollToPage(
                        next,
                        animationSpec = tween(durationMillis = cfg.int("home.ad_animation_ms", 650, 180, 1800))
                    )
                }
            }
        }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = cfg.int("home.ad_horizontal_padding_dp", 14, 6, 32).dp)) {
        HorizontalPager(state = pager, pageSpacing = cfg.int("home.ad_page_spacing_dp", 10, 0, 24).dp) { index ->
            val ad = ads[index]
            Card(
                modifier = Modifier.fillMaxWidth().height(cfg.int("home.ad_height_dp", 180, 100, 360).dp).clickable(enabled = !ad.actionUrl.isNullOrBlank()) {
                    ad.actionUrl?.let { runCatching { uri.openUri(it) } }
                },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F8FB)),
                border = BorderStroke(1.dp, Color(0xFFE8E8E8))
            ) {
                Box(Modifier.fillMaxSize()) {
                    if (!ad.imageUrl.isNullOrBlank()) {
                        AsyncImage(ad.imageUrl, ad.title.ifBlank { "إعلان Student" }, Modifier.fillMaxSize().background(Color.White), contentScale = if (cfg.string("home.ad_content_scale", "fit").equals("crop", true)) ContentScale.Crop else ContentScale.Fit)
                    }
                    if (cfg.bool("home.ad_show_title", false) && ad.title.isNotBlank()) {
                        Surface(
                            modifier = Modifier.align(Alignment.BottomStart).padding(9.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = Color.Black.copy(alpha = .55f)
                        ) { Text(ad.title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) }
                    }
                }
            }
        }
        if (ads.size > 1) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center) {
                repeat(ads.size) { i ->
                    Box(Modifier.padding(horizontal = 3.dp).size(if (i == pager.currentPage) 8.dp else 6.dp).clip(CircleShape).background(if (i == pager.currentPage) Color(0xFF169CF0) else Color(0xFFD6D6D6)))
                }
            }
        }
    }
}
