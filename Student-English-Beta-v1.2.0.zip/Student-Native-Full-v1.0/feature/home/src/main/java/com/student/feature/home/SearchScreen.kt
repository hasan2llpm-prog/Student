package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SearchScreen(api: SupabaseApi, session: StudentSession, onOpenMessages: () -> Unit, onOpenProfile: (String) -> Unit = {}) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ProfileSearchItem>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var blockedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var blockConfirm by remember { mutableStateOf<Pair<ProfileSearchItem, Boolean>?>(null) }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(2600); message = null } }

    LaunchedEffect(session.userId) {
        blockedIds = withContext(Dispatchers.IO) { api.blockedUserIds(session).getOrDefault(emptySet()) }
    }

    fun search() {
        if (query.isBlank()) return
        scope.launch {
            busy = true
            message = null
            val r = withContext(Dispatchers.IO) { api.searchProfiles(session, query) }
            r.onSuccess { results = it }.onFailure { message = it.message }
            busy = false
        }
    }

    blockConfirm?.let { (item, shouldBlock) ->
        AlertDialog(
            onDismissRequest = { if (!busy) blockConfirm = null },
            title = { Text(if (shouldBlock) "تأكيد حظر المستخدم" else "تأكيد إلغاء الحظر") },
            text = {
                Text(
                    if (shouldBlock) "هل تريد حظر ${item.fullName}؟ ستُلغى المتابعة بين الحسابين ولن يسمح Student Native ببدء محادثة جديدة بينكما."
                    else "هل تريد إلغاء حظر ${item.fullName}؟"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) {
                                if (shouldBlock) api.blockUser(session, item.id) else api.unblockUser(session, item.id)
                            }
                            busy = false
                            r.onSuccess {
                                blockedIds = if (shouldBlock) blockedIds + item.id else blockedIds - item.id
                                message = if (shouldBlock) "تم حظر المستخدم." else "تم إلغاء الحظر."
                                blockConfirm = null
                            }.onFailure { message = it.message ?: "تعذر تنفيذ عملية الحظر." }
                        }
                    },
                    enabled = !busy,
                    colors = if (shouldBlock) ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)) else ButtonDefaults.buttonColors(containerColor = StudentBlue)
                ) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = { blockConfirm = null }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("الاسم أو اسم المستخدم") },
                singleLine = true,
                shape = RoundedCornerShape(15.dp),
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { search() }, enabled = !busy && query.isNotBlank(), shape = RoundedCornerShape(14.dp)) { Text("بحث") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(vertical = 5.dp)) }
        LazyColumn(contentPadding = PaddingValues(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(17.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE9EDF3)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(Modifier.fillMaxWidth().clickable { onOpenProfile(item.id) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        StudentAvatar(item.fullName, item.avatarUrl, item.profileFrameUrl, 50.dp)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            StudentName(item.fullName, item.isVerified, item.verificationColor)
                            Text("@${item.username}", style = MaterialTheme.typography.bodySmall, color = StudentMuted)
                        }
                        if (item.id != session.userId) {
                            val blocked = item.id in blockedIds
                            Column(horizontalAlignment = Alignment.End) {
                                TextButton(
                                    onClick = {
                                        scope.launch {
                                            busy = true
                                            val r = withContext(Dispatchers.IO) { api.startDirectChat(session, item.id) }
                                            busy = false
                                            r.onSuccess { onOpenMessages() }.onFailure { message = it.message }
                                        }
                                    },
                                    enabled = !blocked && !busy
                                ) { Text("مراسلة", color = if (blocked) StudentMuted else StudentBlue, fontWeight = FontWeight.Bold) }
                                TextButton(
                                    onClick = {
                                        scope.launch {
                                            val r = withContext(Dispatchers.IO) {
                                                val following = api.isFollowing(session, item.id).getOrDefault(false)
                                                api.setFollowing(session, item.id, !following).map { !following }
                                            }
                                            r.onSuccess { now -> message = if (now) "تمت المتابعة." else "تم إلغاء المتابعة." }
                                                .onFailure { message = it.message }
                                        }
                                    },
                                    enabled = !blocked && !busy
                                ) { Text("متابعة", color = if (blocked) StudentMuted else StudentText, fontSize = 12.sp) }
                                TextButton(onClick = { blockConfirm = item to !blocked }, enabled = !busy) {
                                    Icon(if (blocked) Icons.Rounded.LockOpen else Icons.Rounded.Block, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (blocked) "إلغاء الحظر" else "حظر", color = if (blocked) StudentBlue else Color(0xFFC62828), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
            if (results.isEmpty() && query.isNotBlank() && !busy) {
                item { Box(Modifier.fillMaxWidth().padding(top = 50.dp), contentAlignment = Alignment.Center) { Text("لا توجد نتائج", color = StudentMuted) } }
            }
        }
    }
}
