package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AdminScreen(api: SupabaseApi, session: StudentSession, profile: StudentProfile?) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    var allowed by remember { mutableStateOf(profile?.role.equals("admin", true)) }
    var checked by remember { mutableStateOf(false) }
    var users by remember { mutableStateOf<List<AdminRecentUser>>(emptyList()) }
    var flags by remember { mutableStateOf<List<FeatureFlag>>(emptyList()) }
    var tabKey by remember { mutableStateOf("users") }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<AdminRecentUser?>(null) }
    var broadcastTitle by remember { mutableStateOf("") }
    var broadcastBody by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch {
            loading = true
            val adminResult = withContext(Dispatchers.IO) { api.isAdmin(session) }
            allowed = adminResult.getOrDefault(profile?.role.equals("admin", true))
            checked = true
            if (allowed) {
                val usersResult = withContext(Dispatchers.IO) { api.adminRecentUsers(session) }
                val flagsResult = withContext(Dispatchers.IO) { api.featureFlags(session) }
                usersResult.onSuccess { users = it }.onFailure { message = it.message }
                flagsResult.onSuccess { flags = it }.onFailure { if (message == null) message = it.message }
            }
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(cfg.long("admin.status_duration_ms", 3000L, 500L, 10000L)); message = null } }

    selected?.let { user ->
        AdminGiftDialog(
            user = user,
            loading = loading,
            onDismiss = { if (!loading) selected = null },
            onGiftVerification = { color ->
                scope.launch {
                    loading = true
                    val r = withContext(Dispatchers.IO) { api.grantVerification(session, user.id, color) }
                    loading = false
                    r.onSuccess {
                        message = "تم إرسال التوثيق كهدية للمستخدم."
                        selected = null
                        refresh()
                    }.onFailure { message = it.message }
                }
            },
            onGiftFrame = { frameKey, days ->
                scope.launch {
                    loading = true
                    val r = withContext(Dispatchers.IO) { api.grantProfileFrame(session, user.id, frameKey, days) }
                    loading = false
                    r.onSuccess {
                        message = "تم إرسال الإطار كهدية للمستخدم."
                        selected = null
                        refresh()
                    }.onFailure { message = it.message }
                }
            },
            onGiftCustomBadge = { label, color ->
                scope.launch {
                    loading = true
                    val r = withContext(Dispatchers.IO) { api.grantCustomBadge(session, user.id, label, color) }
                    loading = false
                    r.onSuccess {
                        message = "تم إرسال العلامة كهدية للمستخدم."
                        selected = null
                        refresh()
                    }.onFailure { message = it.message }
                }
            }
        )
    }

    val defaultTabs = listOf("users", "features", "broadcast", "operations")
    val allowedTabs = cfg.strings("admin.tab_order", defaultTabs).map { it.lowercase() }.distinct().filter { key ->
        when (key) {
            "users" -> cfg.bool("admin.show_users_tab", true)
            "features" -> cfg.bool("admin.show_features_tab", true)
            "broadcast" -> cfg.bool("admin.show_broadcast_tab", true)
            "operations" -> cfg.bool("admin.show_operations_tab", true)
            else -> false
        }
    }.ifEmpty { listOf("users") }
    LaunchedEffect(allowedTabs) { if (tabKey !in allowedTabs) tabKey = allowedTabs.first() }

    Column(Modifier.fillMaxSize().padding(horizontal = cfg.int("admin.horizontal_padding_dp", 10, 4, 24).dp)) {
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (checked && !allowed) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                StudentOutlinedCard(Modifier.fillMaxWidth()) {
                    Text(
                        "هذه الصفحة متاحة لحساب الأدمن فقط.",
                        Modifier.padding(20.dp),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
            return@Column
        }

        Surface(
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 2.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF111827),
            shadowElevation = 8.dp
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("STUDENT CONTROL CENTER", color = Color(0xFF93C5FD), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(cfg.string("admin.header_title", "لوحة الإدارة"), fontWeight = FontWeight.Black, fontSize = 24.sp, color = Color.White)
                        Text("تحكم مباشر بالمحتوى والميزات والمستخدمين والمتجر", color = Color(0xFFD1D5DB), fontSize = 11.sp)
                    }
                    if (cfg.bool("admin.show_refresh", true)) {
                        FilledTonalButton(onClick = { refresh() }, enabled = !loading) { Text("تحديث") }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AdminMetricChip("المستخدمون", users.size.toString(), Modifier.weight(1f))
                    AdminMetricChip("الميزات", flags.size.toString(), Modifier.weight(1f))
                    AdminMetricChip("الحالة", if (loading) "تحديث" else "Live", Modifier.weight(1f))
                }
            }
        }

        message?.let {
            Surface(
                color = Color(0xFFF3FAFF),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 7.dp)
            ) {
                Text(it, Modifier.padding(10.dp), color = StudentText, fontSize = 12.sp)
            }
        }

        if (cfg.bool("admin.show_tabs", true)) TabRow(selectedTabIndex = allowedTabs.indexOf(tabKey).coerceAtLeast(0), containerColor = Color.White, contentColor = StudentBlue) {
            allowedTabs.forEach { key ->
                val label = when (key) {
                    "users" -> cfg.string("admin.label_users", "المستخدمون")
                    "features" -> cfg.string("admin.label_features", "الميزات")
                    "broadcast" -> cfg.string("admin.label_broadcast", "بث")
                    else -> cfg.string("admin.label_operations", "الإدارة")
                }
                Tab(selected = tabKey == key, onClick = { tabKey = key }, text = { Text(label, fontSize = cfg.int("admin.tab_text_sp", 12, 9, 16).sp) })
            }
        }

        when (tabKey) {
            "users" -> LazyColumn(
                contentPadding = PaddingValues(vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(users, key = { it.id }) { user ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selected = user },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE9EDF3))
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StudentAvatar(user.fullName, null, null, 45.dp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    Text(user.fullName, fontWeight = FontWeight.Bold, color = StudentText)
                                    VerificationBadge(user.isVerified, roleVerificationColor(user.role), size = 16.dp)
                                }
                                Text("@${user.username}", color = StudentMuted, fontSize = 11.sp)
                                Text(user.email, color = StudentMuted, fontSize = 10.sp)
                                Text(prettyTime(user.createdAt), color = Color(0xFF98A2B1), fontSize = 9.sp)
                            }
                            Text("إدارة", color = StudentBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (users.isEmpty() && checked && !loading) {
                    item { Text("لا يوجد مستخدمون لعرضهم.", color = StudentMuted, modifier = Modifier.padding(14.dp)) }
                }
            }

            "features" -> LazyColumn(
                contentPadding = PaddingValues(vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(flags, key = { it.id.ifBlank { it.key } }) { flag ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE9EDF3))
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(flag.name, fontWeight = FontWeight.Bold, color = StudentText)
                                Text(flag.key, color = StudentMuted, fontSize = 10.sp)
                            }
                            Switch(
                                checked = flag.enabled,
                                onCheckedChange = { enabled ->
                                    scope.launch {
                                        val r = withContext(Dispatchers.IO) { api.updateFeatureFlag(session, flag.id, enabled) }
                                        r.onSuccess {
                                            flags = flags.map { if (it.id == flag.id) it.copy(enabled = enabled) else it }
                                            message = "تم تحديث الميزة."
                                        }.onFailure { message = it.message }
                                    }
                                }
                            )
                        }
                    }
                }
            }

            "broadcast" -> Column(
                Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("نشر إشعار للجميع", fontWeight = FontWeight.Black, fontSize = 19.sp, color = StudentText)
                OutlinedTextField(
                    value = broadcastTitle,
                    onValueChange = { broadcastTitle = it },
                    label = { Text("العنوان") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = broadcastBody,
                    onValueChange = { broadcastBody = it },
                    label = { Text("النص") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )
                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) {
                                api.adminBroadcast(session, broadcastTitle.trim(), broadcastBody.trim())
                            }
                            loading = false
                            r.onSuccess {
                                message = "تم نشر الإشعار للجميع."
                                broadcastTitle = ""
                                broadcastBody = ""
                            }.onFailure { message = it.message }
                        }
                    },
                    enabled = !loading && broadcastTitle.isNotBlank() && broadcastBody.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = StudentBlue)
                ) { Text("نشر الآن") }
            }
            else -> AdminOperationsPane(api, session) { message = it }
        }
    }
}

@Composable
private fun AdminMetricChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(14.dp), color = Color(0xFF1F2937)) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text(label, color = Color(0xFF9CA3AF), fontSize = 9.sp)
        }
    }
}

@Composable
private fun AdminGiftDialog(
    user: AdminRecentUser,
    loading: Boolean,
    onDismiss: () -> Unit,
    onGiftVerification: (String) -> Unit,
    onGiftFrame: (String, Int?) -> Unit,
    onGiftCustomBadge: (String, String) -> Unit
) {
    var giftTab by remember(user.id) { mutableIntStateOf(0) }
    var verificationColor by remember(user.id) { mutableStateOf(roleVerificationColor(user.role)) }
    var frameKey by remember(user.id) { mutableStateOf("fire") }
    var frameDays by remember(user.id) { mutableStateOf("30") }
    var badgeLabel by remember(user.id) { mutableStateOf("علامة مميزة") }
    var badgeColor by remember(user.id) { mutableStateOf("#7c3aed") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(user.fullName, fontWeight = FontWeight.Black)
                Text("@${user.username}", color = StudentMuted, fontSize = 11.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("اختر الهدية التي تريد منحها للحساب.", color = StudentMuted, fontSize = 12.sp)
                TabRow(selectedTabIndex = giftTab, containerColor = Color.Transparent, contentColor = StudentBlue) {
                    Tab(selected = giftTab == 0, onClick = { giftTab = 0 }, text = { Text("توثيق", fontSize = 11.sp) })
                    Tab(selected = giftTab == 1, onClick = { giftTab = 1 }, text = { Text("إطار", fontSize = 11.sp) })
                    Tab(selected = giftTab == 2, onClick = { giftTab = 2 }, text = { Text("علامة", fontSize = 11.sp) })
                }

                when (giftTab) {
                    0 -> {
                        Text("لون التوثيق", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("blue", "red", "orange").forEach { color ->
                                FilterChip(
                                    selected = verificationColor == color,
                                    onClick = { verificationColor = color },
                                    label = { Text(verificationColorLabel(color), fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                    1 -> {
                        Text("نوع الإطار", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(
                                listOf("fire", "blue-fire", "neon"),
                                listOf("lightning", "royal", "ember")
                            ).forEach { rowKeys ->
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                    rowKeys.forEach { key ->
                                        FilterChip(
                                            selected = frameKey == key,
                                            onClick = { frameKey = key },
                                            label = { Text(frameShortLabel(key), fontSize = 9.sp) }
                                        )
                                    }
                                }
                            }
                        }
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            StudentAvatar("S", null, "student-frame:$frameKey", 62.dp)
                        }
                        OutlinedTextField(
                            value = frameDays,
                            onValueChange = { frameDays = it.filter { ch -> ch.isDigit() }.take(4) },
                            label = { Text("المدة بالأيام — اتركها فارغة للدائم") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                    else -> {
                        OutlinedTextField(
                            value = badgeLabel,
                            onValueChange = { badgeLabel = it.take(40) },
                            label = { Text("اسم العلامة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = badgeColor,
                            onValueChange = { badgeColor = it.take(20) },
                            label = { Text("اللون مثل #7c3aed") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when (giftTab) {
                        0 -> onGiftVerification(verificationColor)
                        1 -> onGiftFrame(frameKey, frameDays.toIntOrNull()?.takeIf { it > 0 })
                        else -> onGiftCustomBadge(badgeLabel.trim(), badgeColor.trim())
                    }
                },
                enabled = !loading && (giftTab != 2 || badgeLabel.isNotBlank()),
                colors = ButtonDefaults.buttonColors(containerColor = StudentBlue)
            ) { Text(if (loading) "جارٍ الإرسال..." else "إرسال الهدية") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !loading) { Text("إغلاق") }
        }
    )
}

private fun roleVerificationColor(role: String): String = when (role.lowercase()) {
    "admin" -> "orange"
    "teacher" -> "red"
    else -> "blue"
}

private fun verificationColorLabel(color: String): String = when (color) {
    "orange" -> "برتقالي"
    "red" -> "أحمر"
    else -> "أزرق"
}

private fun frameShortLabel(key: String): String = when (key) {
    "fire" -> "نار"
    "blue-fire" -> "نار زرقاء"
    "neon" -> "نيون"
    "lightning" -> "برق"
    "royal" -> "ملكي"
    "ember" -> "جمر"
    else -> key
}
