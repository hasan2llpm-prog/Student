const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
  });
}

function extractText(data: any): string {
  if (typeof data?.output_text === "string" && data.output_text.trim()) return data.output_text.trim();
  const chunks: string[] = [];
  for (const item of Array.isArray(data?.output) ? data.output : []) {
    for (const content of Array.isArray(item?.content) ? item.content : []) {
      if (content?.type === "output_text" && typeof content?.text === "string") chunks.push(content.text);
    }
  }
  return chunks.join("\n").trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "METHOD_NOT_ALLOWED" }, 405);

  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "AUTH_REQUIRED" }, 401);

  const apiKey = Deno.env.get("OPENAI_API_KEY") || "";
  if (!apiKey) return json({ error: "STUDENT_AI_NOT_CONFIGURED", message: "خدمة Student AI غير مفعلة على الخادم." }, 503);

  let payload: any;
  try { payload = await req.json(); } catch { return json({ error: "INVALID_JSON" }, 400); }

  const mode = payload?.mode === "translate" ? "translate" : "ask";
  const text = String(payload?.text ?? "").trim().slice(0, 4000);
  if (!text) return json({ error: "EMPTY_TEXT", message: "اكتب نصًا أولًا." }, 400);

  const instructions = mode === "translate"
    ? `You are Student AI translator. Detect whether the input is Arabic or English. Translate Arabic to natural, accurate English and English to natural, accurate Arabic. Preserve names, meaning, tone, academic terminology, punctuation, and context. Do not add explanations unless the input itself requires clarification. Return only the translation.`
    : `You are Student AI, an educational assistant for students. Answer accurately, clearly, and directly. Use the language of the user's question. For English-learning questions, explain examples precisely. Do not invent facts. If the question is ambiguous, state the most useful interpretation concisely.`;

  const model = Deno.env.get("OPENAI_MODEL") || "gpt-5.6";
  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      instructions,
      input: text,
      max_output_tokens: mode === "translate" ? 1200 : 1800,
    }),
  });

  const raw = await response.text();
  let data: any = {};
  try { data = JSON.parse(raw); } catch { data = {}; }
  if (!response.ok) {
    console.error("OpenAI error", response.status, raw.slice(0, 1000));
    return json({ error: "AI_PROVIDER_ERROR", message: "تعذر الوصول إلى Student AI حاليًا." }, 502);
  }

  const answer = extractText(data);
  if (!answer) return json({ error: "EMPTY_AI_RESPONSE", message: "لم تُرجع خدمة Student AI جوابًا." }, 502);
  return json({ answer, mode, model });
});
