package com.student.feature.home

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.NativeRemoteConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

private const val STUDIO_A4_W = 595f
private const val STUDIO_A4_H = 842f

private enum class StudioElementType { TEXT, TEXT_BOX, RECT, CIRCLE, LINE, ARROW, STAR, IMAGE }

private data class StudioElement(
    val id: String = UUID.randomUUID().toString(),
    val type: StudioElementType,
    val text: String = "",
    val imageUri: String? = null,
    val x: Float = 50f,
    val y: Float = 80f,
    val width: Float = 260f,
    val height: Float = 90f,
    val fontSize: Float = 20f,
    val textColor: Long = 0xFF111827,
    val fill1: Long = 0xFFFFFFFF,
    val fill2: Long = 0xFFFFFFFF,
    val borderColor: Long = 0xFF111827,
    val borderWidth: Float = 1.5f,
    val cornerRadius: Float = 12f,
    val rotation: Float = 0f,
    val alpha: Float = 1f,
    val gradient: Boolean = false,
    val gradientAngle: Float = 0f,
)

private data class StudioPage(
    val id: String = UUID.randomUUID().toString(),
    val elements: List<StudioElement> = emptyList(),
    val background1: Long = 0xFFFFFFFF,
    val background2: Long = 0xFFFFFFFF,
    val backgroundGradient: Boolean = false,
    val border1: Long = 0xFFCBD5E1,
    val border2: Long = 0xFFCBD5E1,
    val borderGradient: Boolean = false,
    val borderWidth: Float = 1.5f,
    val margin: Float = 0f,
)

private data class StudioDocument(
    val title: String = "مستند جديد",
    val pages: List<StudioPage> = listOf(StudioPage()),
    val landscape: Boolean = false,
)

private data class GradientPreset(val name: String, val first: Long, val second: Long)

private val studioGradients = listOf(
    GradientPreset("أزرق", 0xFF2563EB, 0xFF7C3AED),
    GradientPreset("سماء", 0xFF06B6D4, 0xFF3B82F6),
    GradientPreset("غروب", 0xFFF97316, 0xFFEC4899),
    GradientPreset("زمرد", 0xFF10B981, 0xFF06B6D4),
    GradientPreset("ذهبي", 0xFFF59E0B, 0xFFEF4444),
    GradientPreset("داكن", 0xFF111827, 0xFF475569),
    GradientPreset("بنفسجي", 0xFF7C3AED, 0xFFDB2777),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentStudioScreen(
    config: NativeRemoteConfig,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var document by remember { mutableStateOf(StudioDocument()) }
    var pageIndex by remember { mutableIntStateOf(0) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    var showTextDialog by remember { mutableStateOf<StudioElementType?>(null) }
    var showPageSettings by remember { mutableStateOf(false) }
    var showDeletePageConfirm by remember { mutableStateOf(false) }
    var showGradientSheet by remember { mutableStateOf(false) }
    val undo = remember { mutableStateListOf<StudioDocument>() }
    val redo = remember { mutableStateListOf<StudioDocument>() }

    fun commit(next: StudioDocument) {
        undo.add(document)
        if (undo.size > 40) undo.removeAt(0)
        document = next
        redo.clear()
    }

    fun updatePage(transform: (StudioPage) -> StudioPage) {
        val oldPages = document.pages
        if (pageIndex !in oldPages.indices) return
        val next = oldPages.toMutableList()
        next[pageIndex] = transform(oldPages[pageIndex])
        commit(document.copy(pages = next))
    }

    fun updateElement(id: String, transform: (StudioElement) -> StudioElement) {
        updatePage { page ->
            page.copy(elements = page.elements.map { if (it.id == id) transform(it) else it })
        }
    }

    fun addElement(element: StudioElement) {
        updatePage { it.copy(elements = it.elements + element) }
        selectedId = element.id
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            val start = document.pages[pageIndex].elements.size
            val added = uris.take(20).mapIndexed { index, uri ->
                runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                StudioElement(
                    type = StudioElementType.IMAGE,
                    imageUri = uri.toString(),
                    x = 36f + ((start + index) % 3) * 24f,
                    y = 70f + ((start + index) % 4) * 24f,
                    width = 300f,
                    height = 220f,
                    borderWidth = 0f,
                )
            }
            updatePage { it.copy(elements = it.elements + added) }
            selectedId = added.last().id
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            scope.launch {
                status = "جارٍ إنشاء PDF..."
                val result = withContext(Dispatchers.IO) { runCatching { exportStudioPdf(context, uri, document) } }
                status = result.fold({ "تم إنشاء PDF بنجاح." }, { "تعذر إنشاء الملف: ${it.message ?: "خطأ غير معروف"}" })
            }
        }
    }

    val page = document.pages.getOrElse(pageIndex) { StudioPage() }
    val selected = page.elements.firstOrNull { it.id == selectedId }

    Scaffold(
        containerColor = Color(0xFFF5F7FB),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("محرر المستندات", fontWeight = FontWeight.Black)
                        Text("PDF Studio", fontSize = 11.sp, color = StudentMuted)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "رجوع") } },
                actions = {
                    IconButton(
                        enabled = undo.isNotEmpty(),
                        onClick = {
                            if (undo.isNotEmpty()) {
                                redo.add(document)
                                document = undo.removeAt(undo.lastIndex)
                                pageIndex = pageIndex.coerceAtMost(document.pages.lastIndex)
                                selectedId = null
                            }
                        }
                    ) { Icon(Icons.Rounded.Undo, "تراجع") }
                    IconButton(
                        enabled = redo.isNotEmpty(),
                        onClick = {
                            if (redo.isNotEmpty()) {
                                undo.add(document)
                                document = redo.removeAt(redo.lastIndex)
                                pageIndex = pageIndex.coerceAtMost(document.pages.lastIndex)
                                selectedId = null
                            }
                        }
                    ) { Icon(Icons.Rounded.Redo, "إعادة") }
                    IconButton(onClick = { exportLauncher.launch(document.title.ifBlank { "Student-Document" } + ".pdf") }) {
                        Icon(Icons.Rounded.PictureAsPdf, "تصدير PDF", tint = Color(0xFFC62828))
                    }
                }
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp, color = Color.White) {
                Column(Modifier.navigationBarsPadding()) {
                    DocumentToolRow(
                        onText = { showTextDialog = StudioElementType.TEXT },
                        onTextBox = { showTextDialog = StudioElementType.TEXT_BOX },
                        onImage = { imagePicker.launch("image/*") },
                        onShape = { addElement(StudioElement(type = StudioElementType.RECT, x = 90f, y = 180f, width = 220f, height = 120f, fill1 = 0xFFE0F2FE, fill2 = 0xFF818CF8, gradient = true)) },
                        onCircle = { addElement(StudioElement(type = StudioElementType.CIRCLE, x = 160f, y = 220f, width = 140f, height = 140f, fill1 = 0xFFFCE7F3, fill2 = 0xFFC4B5FD, gradient = true)) },
                        onArrow = { addElement(StudioElement(type = StudioElementType.ARROW, x = 120f, y = 260f, width = 220f, height = 70f, fill1 = 0xFF2563EB, fill2 = 0xFF7C3AED, gradient = true)) },
                        onStar = { addElement(StudioElement(type = StudioElementType.STAR, x = 200f, y = 300f, width = 120f, height = 120f, fill1 = 0xFFF59E0B, fill2 = 0xFFEC4899, gradient = true)) },
                        onPage = { showPageSettings = true },
                    )
                    if (selected != null) SelectedElementTools(
                        element = selected,
                        onDelete = {
                            updatePage { p -> p.copy(elements = p.elements.filterNot { it.id == selected.id }) }
                            selectedId = null
                        },
                        onDuplicate = {
                            addElement(selected.copy(id = UUID.randomUUID().toString(), x = selected.x + 16f, y = selected.y + 16f))
                        },
                        onBringFront = {
                            updatePage { p -> p.copy(elements = p.elements.filterNot { it.id == selected.id } + selected) }
                        },
                        onGradient = { showGradientSheet = true },
                        onRotate = { updateElement(selected.id) { it.copy(rotation = (it.rotation + 15f) % 360f) } },
                        onLarger = { updateElement(selected.id) { it.copy(width = min(540f, it.width + 18f), height = min(780f, it.height + 12f), fontSize = min(72f, it.fontSize + 2f)) } },
                        onSmaller = { updateElement(selected.id) { it.copy(width = max(35f, it.width - 18f), height = max(25f, it.height - 12f), fontSize = max(8f, it.fontSize - 2f)) } },
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            StudioPageStrip(
                count = document.pages.size,
                selected = pageIndex,
                onSelect = { pageIndex = it; selectedId = null },
                onAdd = {
                    commit(document.copy(pages = document.pages + StudioPage()))
                    pageIndex = document.pages.lastIndex
                    selectedId = null
                },
                onDuplicate = {
                    val source = document.pages[pageIndex]
                    val copy = source.copy(id = UUID.randomUUID().toString(), elements = source.elements.map { it.copy(id = UUID.randomUUID().toString()) })
                    val list = document.pages.toMutableList().apply { add(pageIndex + 1, copy) }
                    commit(document.copy(pages = list)); pageIndex += 1; selectedId = null
                },
                onDelete = { if (document.pages.size > 1) showDeletePageConfirm = true },
            )
            status?.let { text ->
                Surface(color = if (text.startsWith("تم")) Color(0xFFE8F7EE) else Color(0xFFFFF4E5), modifier = Modifier.fillMaxWidth()) {
                    Text(text, Modifier.padding(horizontal = 14.dp, vertical = 7.dp), fontSize = 12.sp, color = StudentText)
                }
            }
            Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.TopCenter) {
                StudioPageCanvas(
                    page = page,
                    landscape = document.landscape,
                    selectedId = selectedId,
                    onSelect = { selectedId = it },
                    onMove = { id, dx, dy ->
                        updateElement(id) { e ->
                            val maxW = if (document.landscape) STUDIO_A4_H else STUDIO_A4_W
                            val maxH = if (document.landscape) STUDIO_A4_W else STUDIO_A4_H
                            e.copy(
                                x = (e.x + dx).coerceIn(-e.width * .7f, maxW - e.width * .3f),
                                y = (e.y + dy).coerceIn(-e.height * .7f, maxH - e.height * .3f),
                            )
                        }
                    }
                )
            }
        }
    }

    showTextDialog?.let { type ->
        TextInsertDialog(
            type = type,
            onDismiss = { showTextDialog = null },
            onAdd = { text ->
                addElement(
                    StudioElement(
                        type = type,
                        text = text,
                        x = if (page.margin > 0) page.margin else 12f,
                        y = 60f,
                        width = if (type == StudioElementType.TEXT_BOX) 360f else 500f,
                        height = if (type == StudioElementType.TEXT_BOX) 120f else 70f,
                        fill1 = if (type == StudioElementType.TEXT_BOX) 0xFFF8FAFC else 0x00FFFFFF,
                        fill2 = if (type == StudioElementType.TEXT_BOX) 0xFFE0E7FF else 0x00FFFFFF,
                        gradient = type == StudioElementType.TEXT_BOX,
                        borderWidth = if (type == StudioElementType.TEXT_BOX) 1.4f else 0f,
                    )
                )
                showTextDialog = null
            }
        )
    }

    if (showPageSettings) {
        PageDesignSheet(
            page = page,
            landscape = document.landscape,
            onDismiss = { showPageSettings = false },
            onLandscapeChange = { next -> commit(document.copy(landscape = next)) },
            onMargin = { margin -> updatePage { it.copy(margin = margin) } },
            onBorderWidth = { width -> updatePage { it.copy(borderWidth = width) } },
            onBorderGradient = { preset -> updatePage { it.copy(border1 = preset.first, border2 = preset.second, borderGradient = true) } },
            onBackgroundGradient = { preset -> updatePage { it.copy(background1 = preset.first, background2 = preset.second, backgroundGradient = true) } },
            onWhiteBackground = { updatePage { it.copy(background1 = 0xFFFFFFFF, background2 = 0xFFFFFFFF, backgroundGradient = false) } },
        )
    }

    if (showGradientSheet && selected != null) {
        ModalBottomSheet(onDismissRequest = { showGradientSheet = false }) {
            Column(Modifier.fillMaxWidth().padding(16.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ألوان وتدرجات العنصر", fontWeight = FontWeight.Black, fontSize = 19.sp)
                Text("ليست ألوانًا أساسية فقط؛ اختر تدرجًا جاهزًا ثم يمكنك تطويره من Supabase لاحقًا.", color = StudentMuted, fontSize = 12.sp)
                studioGradients.forEach { preset ->
                    Row(
                        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(listOf(Color(preset.first), Color(preset.second)))).clickableNoIndication {
                            updateElement(selected.id) { it.copy(fill1 = preset.first, fill2 = preset.second, gradient = true) }
                            showGradientSheet = false
                        }.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) { Text(preset.name, color = Color.White, fontWeight = FontWeight.Black) }
                }
            }
        }
    }

    if (showDeletePageConfirm) {
        AlertDialog(
            onDismissRequest = { showDeletePageConfirm = false },
            title = { Text("حذف الصفحة؟") },
            text = { Text("سيتم حذف الصفحة ومحتواها من المسودة الحالية.") },
            confirmButton = {
                Button(
                    onClick = {
                        val list = document.pages.toMutableList().also { it.removeAt(pageIndex) }
                        commit(document.copy(pages = list))
                        pageIndex = pageIndex.coerceAtMost(list.lastIndex)
                        selectedId = null
                        showDeletePageConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { showDeletePageConfirm = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun DocumentToolRow(
    onText: () -> Unit,
    onTextBox: () -> Unit,
    onImage: () -> Unit,
    onShape: () -> Unit,
    onCircle: () -> Unit,
    onArrow: () -> Unit,
    onStar: () -> Unit,
    onPage: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        StudioTool(Icons.Rounded.TextFields, "نص", onText)
        StudioTool(Icons.Rounded.ChatBubbleOutline, "مربع", onTextBox)
        StudioTool(Icons.Rounded.Image, "صورة", onImage)
        StudioTool(Icons.Rounded.CropSquare, "شكل", onShape)
        StudioTool(Icons.Rounded.Circle, "دائرة", onCircle)
        StudioTool(Icons.Rounded.ArrowForward, "سهم", onArrow)
        StudioTool(Icons.Rounded.StarOutline, "رمز", onStar)
        StudioTool(Icons.Rounded.Tune, "الصفحة", onPage)
    }
}

@Composable
private fun StudioTool(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, action: () -> Unit) {
    FilledTonalButton(onClick = action, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)) {
        Icon(icon, null, Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text(label, fontSize = 10.sp)
    }
}

@Composable
private fun SelectedElementTools(
    element: StudioElement,
    onDelete: () -> Unit,
    onDuplicate: () -> Unit,
    onBringFront: () -> Unit,
    onGradient: () -> Unit,
    onRotate: () -> Unit,
    onLarger: () -> Unit,
    onSmaller: () -> Unit,
) {
    HorizontalDivider(color = Color(0xFFE5E7EB))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        StudioTool(Icons.Rounded.Palette, "ألوان", onGradient)
        StudioTool(Icons.Rounded.RotateRight, "تدوير", onRotate)
        StudioTool(Icons.Rounded.ZoomIn, "تكبير", onLarger)
        StudioTool(Icons.Rounded.ZoomOut, "تصغير", onSmaller)
        StudioTool(Icons.Rounded.ContentCopy, "نسخ", onDuplicate)
        StudioTool(Icons.Rounded.VerticalAlignTop, "للأمام", onBringFront)
        TextButton(onClick = onDelete) { Icon(Icons.Rounded.DeleteOutline, null, tint = Color(0xFFC62828)); Spacer(Modifier.width(3.dp)); Text("حذف", color = Color(0xFFC62828), fontSize = 10.sp) }
    }
}

@Composable
private fun StudioPageStrip(
    count: Int,
    selected: Int,
    onSelect: (Int) -> Unit,
    onAdd: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(color = Color.White) {
        LazyRow(contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            itemsIndexed(List(count) { it }) { index, _ ->
                FilterChip(selected = index == selected, onClick = { onSelect(index) }, label = { Text("${index + 1}", fontSize = 10.sp) })
            }
            item { FilledTonalIconButton(onClick = onAdd, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.Add, "صفحة جديدة", Modifier.size(18.dp)) } }
            item { IconButton(onClick = onDuplicate, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.ContentCopy, "نسخ الصفحة", Modifier.size(18.dp)) } }
            if (count > 1) item { IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) { Icon(Icons.Rounded.DeleteOutline, "حذف الصفحة", Modifier.size(18.dp), tint = Color(0xFFC62828)) } }
        }
    }
}

@Composable
private fun StudioPageCanvas(
    page: StudioPage,
    landscape: Boolean,
    selectedId: String?,
    onSelect: (String?) -> Unit,
    onMove: (String, Float, Float) -> Unit,
) {
    val baseW = if (landscape) STUDIO_A4_H else STUDIO_A4_W
    val baseH = if (landscape) STUDIO_A4_W else STUDIO_A4_H
    BoxWithConstraints(
        Modifier.fillMaxWidth().fillMaxHeight(),
        contentAlignment = Alignment.TopCenter
    ) {
        val availableW = maxWidth - 12.dp
        val availableH = maxHeight - 12.dp
        val ratio = baseH / baseW
        val pageW: Dp
        val pageH: Dp
        if (availableW * ratio <= availableH) {
            pageW = availableW
            pageH = availableW * ratio
        } else {
            pageH = availableH
            pageW = availableH / ratio
        }
        val scale = pageW.value / baseW
        val bgBrush = if (page.backgroundGradient) Brush.linearGradient(listOf(Color(page.background1), Color(page.background2))) else Brush.linearGradient(listOf(Color(page.background1), Color(page.background1)))
        val borderBrush = if (page.borderGradient) Brush.linearGradient(listOf(Color(page.border1), Color(page.border2))) else Brush.linearGradient(listOf(Color(page.border1), Color(page.border1)))
        Box(
            Modifier.size(pageW, pageH)
                .background(bgBrush)
                .border((page.borderWidth * scale).coerceAtLeast(.4f).dp, borderBrush, RoundedCornerShape(1.dp))
                .clip(RoundedCornerShape(1.dp))
                .clickableNoIndication { onSelect(null) }
        ) {
            if (page.margin > 0f) {
                Box(
                    Modifier.fillMaxSize().padding((page.margin * scale).dp)
                        .border(.6.dp, Color(0xFF94A3B8).copy(alpha = .35f), RoundedCornerShape(1.dp))
                )
            }
            page.elements.forEach { element ->
                StudioElementView(
                    element = element,
                    scale = scale,
                    selected = selectedId == element.id,
                    onSelect = { onSelect(element.id) },
                    onMove = { dx, dy -> onMove(element.id, dx / scale, dy / scale) }
                )
            }
        }
    }
}

@Composable
private fun StudioElementView(
    element: StudioElement,
    scale: Float,
    selected: Boolean,
    onSelect: () -> Unit,
    onMove: (Float, Float) -> Unit,
) {
    val fillBrush = if (element.gradient) Brush.linearGradient(listOf(Color(element.fill1), Color(element.fill2))) else Brush.linearGradient(listOf(Color(element.fill1), Color(element.fill1)))
    val base = Modifier
        .offset((element.x * scale).dp, (element.y * scale).dp)
        .size((element.width * scale).dp, (element.height * scale).dp)
        .rotate(element.rotation)
        .alpha(element.alpha)
        .pointerInput(element.id, scale) {
            detectDragGestures(
                onDragStart = { onSelect() },
                onDrag = { change, drag -> change.consume(); onMove(drag.x, drag.y) }
            )
        }
        .clickableNoIndication(onSelect)
        .then(if (selected) Modifier.border(1.2.dp, StudentBlue, RoundedCornerShape((element.cornerRadius * scale).dp)) else Modifier)

    when (element.type) {
        StudioElementType.TEXT -> Box(base.padding(2.dp), contentAlignment = Alignment.CenterStart) {
            Text(element.text, color = Color(element.textColor), fontSize = (element.fontSize * scale).coerceAtLeast(7f).sp, maxLines = 8)
        }
        StudioElementType.TEXT_BOX -> Box(
            base.background(fillBrush, RoundedCornerShape((element.cornerRadius * scale).dp))
                .border((element.borderWidth * scale).coerceAtLeast(.4f).dp, Color(element.borderColor), RoundedCornerShape((element.cornerRadius * scale).dp))
                .padding((10f * scale).coerceAtLeast(3f).dp),
            contentAlignment = Alignment.Center
        ) { Text(element.text, color = Color(element.textColor), fontSize = (element.fontSize * scale).coerceAtLeast(7f).sp, textAlign = TextAlign.Center) }
        StudioElementType.RECT -> Box(base.background(fillBrush, RoundedCornerShape((element.cornerRadius * scale).dp)).border((element.borderWidth * scale).coerceAtLeast(.4f).dp, Color(element.borderColor), RoundedCornerShape((element.cornerRadius * scale).dp)))
        StudioElementType.CIRCLE -> Box(base.background(fillBrush, CircleShape).border((element.borderWidth * scale).coerceAtLeast(.4f).dp, Color(element.borderColor), CircleShape))
        StudioElementType.IMAGE -> AsyncImage(model = element.imageUri, contentDescription = null, modifier = base.clip(RoundedCornerShape((element.cornerRadius * scale).dp)), contentScale = ContentScale.Crop)
        StudioElementType.LINE -> Box(base.height((max(2f, element.borderWidth) * scale).dp).background(Color(element.borderColor)))
        StudioElementType.ARROW -> Box(base, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.ArrowForward, null, tint = Color(element.fill1), modifier = Modifier.fillMaxSize())
        }
        StudioElementType.STAR -> Box(base, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Star, null, tint = Color(element.fill1), modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun TextInsertDialog(type: StudioElementType, onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == StudioElementType.TEXT_BOX) "مربع نص / حوار" else "إضافة نص") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(4000) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                placeholder = { Text("اكتب بالعربية أو الإنجليزية...") },
            )
        },
        confirmButton = { Button(onClick = { if (text.isNotBlank()) onAdd(text.trim()) }, enabled = text.isNotBlank()) { Text("إضافة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PageDesignSheet(
    page: StudioPage,
    landscape: Boolean,
    onDismiss: () -> Unit,
    onLandscapeChange: (Boolean) -> Unit,
    onMargin: (Float) -> Unit,
    onBorderWidth: (Float) -> Unit,
    onBorderGradient: (GradientPreset) -> Unit,
    onBackgroundGradient: (GradientPreset) -> Unit,
    onWhiteBackground: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        LazyColumn(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 26.dp)
        ) {
            item { Text("خصائص الصفحة", fontWeight = FontWeight.Black, fontSize = 20.sp) }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("اتجاه أفقي", modifier = Modifier.weight(1f)); Switch(landscape, onLandscapeChange)
                }
            }
            item {
                Text("الهامش: ${page.margin.toInt()} pt — يمكن جعله صفرًا حتى يبدأ المحتوى من حدود الصفحة.", fontSize = 12.sp)
                Slider(value = page.margin, onValueChange = onMargin, valueRange = 0f..72f, steps = 11)
            }
            item {
                Text("سماكة الإطار: ${"%.1f".format(page.borderWidth)}", fontSize = 12.sp)
                Slider(value = page.borderWidth, onValueChange = onBorderWidth, valueRange = 0f..12f)
            }
            item { Text("تدرج الإطار", fontWeight = FontWeight.Bold) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(studioGradients) { _, p -> GradientSwatch(p) { onBorderGradient(p) } }
                }
            }
            item { Text("خلفية متدرجة", fontWeight = FontWeight.Bold) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(studioGradients) { _, p -> GradientSwatch(p) { onBackgroundGradient(p) } }
                }
            }
            item { OutlinedButton(onClick = onWhiteBackground, modifier = Modifier.fillMaxWidth()) { Text("خلفية بيضاء") } }
        }
    }
}

@Composable
private fun GradientSwatch(preset: GradientPreset, onClick: () -> Unit) {
    Box(
        Modifier.size(92.dp, 50.dp).clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(listOf(Color(preset.first), Color(preset.second)))).clickableNoIndication(onClick),
        contentAlignment = Alignment.Center
    ) { Text(preset.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp) }
}

private fun Modifier.clickableNoIndication(onClick: () -> Unit): Modifier =
    this.then(Modifier.pointerInput(onClick) {
        var moved = false
        detectDragGestures(
            onDragStart = { moved = false },
            onDrag = { _, drag -> if (kotlin.math.abs(drag.x) + kotlin.math.abs(drag.y) > 3f) moved = true },
            onDragEnd = { if (!moved) onClick() }
        )
    })

private fun exportStudioPdf(context: Context, uri: Uri, document: StudioDocument) {
    val pdf = PdfDocument()
    try {
        val pageW = if (document.landscape) STUDIO_A4_H.toInt() else STUDIO_A4_W.toInt()
        val pageH = if (document.landscape) STUDIO_A4_W.toInt() else STUDIO_A4_H.toInt()
        document.pages.forEachIndexed { index, page ->
            val info = PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create()
            val pdfPage = pdf.startPage(info)
            val canvas = pdfPage.canvas
            val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.WHITE
                if (page.backgroundGradient) shader = LinearGradient(0f, 0f, pageW.toFloat(), pageH.toFloat(), page.background1.toInt(), page.background2.toInt(), Shader.TileMode.CLAMP)
                else color = page.background1.toInt()
            }
            canvas.drawRect(0f, 0f, pageW.toFloat(), pageH.toFloat(), backgroundPaint)

            if (page.borderWidth > 0f) {
                val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = page.borderWidth
                    if (page.borderGradient) shader = LinearGradient(0f, 0f, pageW.toFloat(), 0f, page.border1.toInt(), page.border2.toInt(), Shader.TileMode.CLAMP)
                    else color = page.border1.toInt()
                }
                val inset = page.borderWidth / 2f
                canvas.drawRect(inset, inset, pageW - inset, pageH - inset, borderPaint)
            }

            page.elements.forEach { element -> drawPdfElement(context, canvas, element) }
            pdf.finishPage(pdfPage)
        }
        context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) } ?: error("تعذر فتح مكان الحفظ")
    } finally {
        pdf.close()
    }
}

private fun drawPdfElement(context: Context, canvas: android.graphics.Canvas, e: StudioElement) {
    canvas.save()
    canvas.rotate(e.rotation, e.x + e.width / 2f, e.y + e.height / 2f)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        alpha = (255 * e.alpha.coerceIn(0f, 1f)).toInt()
        if (e.gradient) shader = LinearGradient(e.x, e.y, e.x + e.width, e.y + e.height, e.fill1.toInt(), e.fill2.toInt(), Shader.TileMode.CLAMP)
        else color = e.fill1.toInt()
    }
    val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = e.borderWidth
        color = e.borderColor.toInt()
        alpha = (255 * e.alpha.coerceIn(0f, 1f)).toInt()
    }
    val rect = RectF(e.x, e.y, e.x + e.width, e.y + e.height)
    when (e.type) {
        StudioElementType.TEXT -> drawWrappedPdfText(canvas, e.text, e.x, e.y, e.width, e.fontSize, e.textColor.toInt())
        StudioElementType.TEXT_BOX -> {
            canvas.drawRoundRect(rect, e.cornerRadius, e.cornerRadius, fill)
            if (e.borderWidth > 0f) canvas.drawRoundRect(rect, e.cornerRadius, e.cornerRadius, border)
            drawWrappedPdfText(canvas, e.text, e.x + 10f, e.y + 10f, max(10f, e.width - 20f), e.fontSize, e.textColor.toInt(), maxHeight = e.height - 18f)
        }
        StudioElementType.RECT -> {
            canvas.drawRoundRect(rect, e.cornerRadius, e.cornerRadius, fill)
            if (e.borderWidth > 0f) canvas.drawRoundRect(rect, e.cornerRadius, e.cornerRadius, border)
        }
        StudioElementType.CIRCLE -> {
            canvas.drawOval(rect, fill)
            if (e.borderWidth > 0f) canvas.drawOval(rect, border)
        }
        StudioElementType.LINE -> canvas.drawLine(e.x, e.y + e.height / 2f, e.x + e.width, e.y + e.height / 2f, border)
        StudioElementType.ARROW -> {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = e.fill1.toInt(); style = Paint.Style.STROKE; strokeWidth = max(3f, e.height * .18f); strokeCap = Paint.Cap.ROUND }
            val cy = e.y + e.height / 2f
            canvas.drawLine(e.x, cy, e.x + e.width * .82f, cy, p)
            val head = Path().apply { moveTo(e.x + e.width * .68f, e.y + e.height * .18f); lineTo(e.x + e.width, cy); lineTo(e.x + e.width * .68f, e.y + e.height * .82f) }
            canvas.drawPath(head, p)
        }
        StudioElementType.STAR -> {
            val path = Path()
            val cx = e.x + e.width / 2f; val cy = e.y + e.height / 2f
            val outer = min(e.width, e.height) / 2f; val inner = outer * .45f
            for (i in 0 until 10) {
                val a = Math.toRadians((-90 + i * 36).toDouble())
                val r = if (i % 2 == 0) outer else inner
                val px = cx + (kotlin.math.cos(a) * r).toFloat(); val py = cy + (kotlin.math.sin(a) * r).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close(); canvas.drawPath(path, fill); if (e.borderWidth > 0f) canvas.drawPath(path, border)
        }
        StudioElementType.IMAGE -> {
            val uri = e.imageUri?.let(Uri::parse)
            if (uri != null) runCatching {
                context.contentResolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input) }
            }.getOrNull()?.let { bitmap ->
                canvas.drawBitmap(bitmap, null, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                bitmap.recycle()
            }
        }
    }
    canvas.restore()
}

private fun drawWrappedPdfText(
    canvas: android.graphics.Canvas,
    text: String,
    x: Float,
    y: Float,
    maxWidth: Float,
    size: Float,
    color: Int,
    maxHeight: Float = Float.MAX_VALUE,
) {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color }
    val lineHeight = size * 1.35f
    var cy = y + size
    text.split("\n").forEach { paragraph ->
        val words = paragraph.split(Regex("\\s+"))
        var line = ""
        words.forEach { word ->
            val candidate = if (line.isBlank()) word else "$line $word"
            if (paint.measureText(candidate) > maxWidth && line.isNotBlank()) {
                if (cy - y <= maxHeight) canvas.drawText(line, x, cy, paint)
                cy += lineHeight
                line = word
            } else line = candidate
        }
        if (line.isNotBlank() && cy - y <= maxHeight) canvas.drawText(line, x, cy, paint)
        cy += lineHeight
    }
}
