package com.student.feature.home

import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.student.core.data.OfflineStore
import com.student.core.data.StudentSession
import com.student.core.data.SupabaseApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun CreateScreen(api: SupabaseApi, session: StudentSession, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val offline = remember { OfflineStore(context) }
    val drafts = remember { context.getSharedPreferences("student_drafts", android.content.Context.MODE_PRIVATE) }
    var target by remember { mutableStateOf("post") }
    var text by remember { mutableStateOf(drafts.getString("post_text", "").orEmpty()) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedMime by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var confirmPublish by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        if (message != null) {
            kotlinx.coroutines.delay(2800)
            message = null
        }
    }
    LaunchedEffect(target) {
        text = drafts.getString("${target}_text", "").orEmpty()
        selectedUri = null
        selectedMime = null
        confirmPublish = false
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedUri = uri
        selectedMime = uri?.let { context.contentResolver.getType(it) }
    }

    fun publish() {
        if (text.isBlank() && selectedUri == null) return
        scope.launch {
            busy = true
            message = null
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    var mediaUrl: String? = null
                    var mediaType = "text"
                    selectedUri?.let { uri ->
                        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الملف.")
                        if (bytes.size > 20 * 1024 * 1024) throw IllegalStateException("حجم الملف أكبر من الحد المسموح.")
                        val mime = selectedMime ?: "application/octet-stream"
                        mediaType = when {
                            mime.startsWith("image/") -> "image"
                            mime.startsWith("video/") -> "video"
                            else -> "file"
                        }
                        val ext = when (mediaType) { "image" -> "jpg"; "video" -> "mp4"; else -> "bin" }
                        val path = "${session.userId}/${System.currentTimeMillis()}_native.$ext"
                        mediaUrl = api.uploadObject(session, "stories", path, bytes, mime).getOrThrow()
                    }
                    if (target == "story") {
                        api.createStory(session, text.trim(), mediaUrl, if (mediaUrl == null) "text" else mediaType).getOrThrow()
                    } else {
                        if (mediaType == "video") throw IllegalStateException("الفيديو يُنشر من قسم Reels أو القصص.")
                        api.createPost(session, text.trim(), mediaUrl).getOrThrow()
                    }
                }
            }
            result.onSuccess {
                drafts.edit().remove("${target}_text").apply()
                text = ""
                selectedUri = null
                selectedMime = null
                message = "تم النشر بنجاح."
                onDone()
            }.onFailure { err ->
                if (selectedUri == null && text.isNotBlank()) {
                    offline.enqueue(if (target == "story") "story_text" else "post_text", JSONObject().put("content", text.trim()))
                    drafts.edit().remove("${target}_text").apply()
                    text = ""
                    message = "تم حفظ النص وسيتم نشره عند عودة الإنترنت."
                } else {
                    message = err.message ?: "تعذر النشر."
                }
            }
            busy = false
        }
    }

    if (confirmPublish) {
        AlertDialog(
            onDismissRequest = { if (!busy) confirmPublish = false },
            title = { Text(if (target == "story") "تأكيد نشر القصة" else "تأكيد نشر المنشور") },
            text = { Text("راجع المحتوى. لن يتم النشر إلا بعد التأكيد.") },
            confirmButton = {
                Button(enabled = !busy, onClick = { confirmPublish = false; publish() }) { Text("تأكيد ونشر") }
            },
            dismissButton = {
                TextButton(enabled = !busy, onClick = { confirmPublish = false }) { Text("رجوع للتحرير") }
            }
        )
    }

    Column(
        Modifier.fillMaxSize().imePadding().navigationBarsPadding().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("إنشاء محتوى", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = target == "post", onClick = { target = "post" }, label = { Text("منشور") })
            FilterChip(selected = target == "story", onClick = { target = "story" }, label = { Text("قصة") })
        }
        OutlinedTextField(
            value = text,
            onValueChange = { value -> text = value; drafts.edit().putString("${target}_text", value).apply() },
            label = { Text(if (target == "story") "نص القصة" else "ماذا تريد أن تنشر؟") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
            enabled = !busy
        )
        OutlinedButton(
            onClick = { picker.launch(if (target == "story") "*/*" else "image/*") },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (selectedUri == null) "اختيار ${if (target == "story") "صورة أو فيديو" else "صورة"}" else "تغيير الوسائط")
        }

        selectedUri?.let { uri ->
            when {
                selectedMime?.startsWith("image/") == true -> AsyncImage(
                    model = uri,
                    contentDescription = "معاينة",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                )
                selectedMime?.startsWith("video/") == true -> AndroidView(
                    factory = { ctx -> VideoView(ctx).apply {
                        setVideoURI(uri)
                        setOnPreparedListener { mp -> mp.isLooping = true; start() }
                    } },
                    modifier = Modifier.fillMaxWidth().height(260.dp)
                )
                else -> Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Text("تم اختيار الملف.", Modifier.padding(16.dp))
                }
            }
        }

        message?.let {
            Text(it, color = if (it.startsWith("تم")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        }
        Button(
            onClick = { confirmPublish = true },
            enabled = !busy && (text.isNotBlank() || selectedUri != null),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else Text("مراجعة وتأكيد")
        }
    }
}
