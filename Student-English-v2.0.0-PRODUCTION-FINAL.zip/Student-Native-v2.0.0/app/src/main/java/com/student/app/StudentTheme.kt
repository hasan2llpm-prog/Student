package com.student.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

private val StudentLightColors = lightColorScheme(
    primary = Color(0xFF6D28D9),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF1EAFE),
    onPrimaryContainer = Color(0xFF2E1065),
    secondary = Color(0xFF7C3AED),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF5F0FF),
    onSecondaryContainer = Color(0xFF3B1678),
    tertiary = Color(0xFF0EA5E9),
    background = Color(0xFFFCFBFF),
    onBackground = Color(0xFF17151C),
    surface = Color.White,
    onSurface = Color(0xFF17151C),
    surfaceVariant = Color(0xFFF7F4FB),
    onSurfaceVariant = Color(0xFF6B6572),
    outline = Color(0xFFE2DDE8),
    outlineVariant = Color(0xFFF0ECF4),
    error = Color(0xFFB42318),
    errorContainer = Color(0xFFFFEDEA)
)

private val BaseTypography = Typography()
private val StudentTypography = Typography(
    displaySmall = BaseTypography.displaySmall.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp),
    headlineLarge = BaseTypography.headlineLarge.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.35).sp),
    headlineMedium = BaseTypography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
    headlineSmall = BaseTypography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
    titleLarge = BaseTypography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
    titleMedium = BaseTypography.titleMedium.copy(fontWeight = FontWeight.Bold),
    titleSmall = BaseTypography.titleSmall.copy(fontWeight = FontWeight.Bold),
    bodyLarge = BaseTypography.bodyLarge.copy(lineHeight = 23.sp),
    bodyMedium = BaseTypography.bodyMedium.copy(lineHeight = 20.sp),
    labelLarge = BaseTypography.labelLarge.copy(fontWeight = FontWeight.Bold)
)

private val StudentShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(32.dp)
)

@Composable
fun StudentTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = StudentLightColors,
            typography = StudentTypography,
            shapes = StudentShapes,
            content = content
        )
    }
}
