package com.student.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class ForcedUpdateInfo(
    val minimumVersionCode: Int,
    val latestVersionCode: Int,
    val apkUrl: String,
    val message: String
)

@Composable
fun ForcedUpdateScreen(info: ForcedUpdateInfo) {
    val uri = LocalUriHandler.current
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(13.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(58.dp),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("↑", fontSize = 32.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Text("تحديث Student مطلوب", fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text(
                        info.message.ifBlank { "يتوفر تحديث ضروري لمتابعة استخدام Student." },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "نسختك الحالية لم تعد مدعومة. يجب تحديث التطبيق للمتابعة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = { if (info.apkUrl.isNotBlank()) runCatching { uri.openUri(info.apkUrl) } },
                        enabled = info.apkUrl.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("تحديث الآن", fontWeight = FontWeight.Bold) }
                    if (info.apkUrl.isBlank()) {
                        Text("رابط التحديث غير مضبوط من لوحة الإدارة.", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun UpdateAvailableDialog(info: ForcedUpdateInfo, onLater: () -> Unit) {
    val uri = LocalUriHandler.current
    AlertDialog(
        onDismissRequest = onLater,
        title = { Text("تحديث جديد لـ Student", fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(info.message.ifBlank { "يتوفر إصدار أحدث من Student." })
                Text(
                    "يمكنك بدء التحديث من داخل التطبيق. سيطلب Android تأكيد التثبيت لحماية جهازك.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(onClick = { if (info.apkUrl.isNotBlank()) runCatching { uri.openUri(info.apkUrl) } }) {
                Text("تحديث الآن", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onLater) { Text("لاحقاً") } }
    )
}
