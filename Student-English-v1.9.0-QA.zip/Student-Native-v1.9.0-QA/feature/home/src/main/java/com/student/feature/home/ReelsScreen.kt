@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package com.student.feature.home

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ReelsScreen(
    api: SupabaseApi,
    session: StudentSession,
    initialReelId: String? = null,
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    val context = LocalContext.current
    var reels by remember { mutableStateOf<List<ReelItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var commentsFor by remember { mutableStateOf<ReelItem?>(null) }
    var shareFor by remember { mutableStateOf<ReelItem?>(null) }
    var uploadOpen by remember { mutableStateOf(false) }
    var uploadCaption by remember { mutableStateOf("") }
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            withContext(Dispatchers.IO) { api.reels(session, cfg.int("reels.page_size", 24, 5, 60), 0) }
                .onSuccess { reels = it }
                .onFailure { message = it.message ?: "تعذر تحميل الريلز." }
            loading = false
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        if (it != null) { selectedVideo = it; uploadOpen = true }
    }

    LaunchedEffect(session.userId) { refresh() }

    if (uploadOpen) {
        ModalBottomSheet(onDismissRequest = { if (!loading) { uploadOpen = false; selectedVideo = null } }) {
            Column(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("نشر Reel", fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("الفيديو المختار جاهز للرفع.", color = StudentMuted, fontSize = 12.sp)
                OutlinedTextField(
                    uploadCaption,
                    { uploadCaption = it.take(2200) },
                    label = { Text("الوصف") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
                Button(
                    onClick = {
                        val picked = selectedVideo ?: return@Button
                        scope.launch {
                            loading = true
                            val result = withContext(Dispatchers.IO) {
                                runCatching {
                                    val mime = context.contentResolver.getType(picked) ?: "video/mp4"
                                    require(mime.startsWith("video/")) { "اختر ملف فيديو." }
                                    val bytes = context.contentResolver.openInputStream(picked)?.use { it.readBytes() }
                                        ?: error("تعذر قراءة الفيديو.")
                                    val maxMb = cfg.int("reels.max_upload_mb", 80, 5, 300)
                                    require(bytes.size <= maxMb * 1024 * 1024) { "الحد الأقصى للفيديو ${maxMb}MB." }
                                    val path = "${session.userId}/${System.currentTimeMillis()}_reel.mp4"
                                    val url = api.uploadObject(session, "reels", path, bytes, mime).getOrThrow()
                                    api.createReel(session, url, uploadCaption).getOrThrow()
                                }
                            }
                            loading = false
                            result.onSuccess {
                                uploadOpen = false; selectedVideo = null; uploadCaption = ""
                                message = "تم نشر الريل."; refresh()
                            }.onFailure { message = it.message ?: "تعذر نشر الريل." }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !loading
                ) { Text(if (loading) "جارٍ الرفع..." else "نشر") }
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    commentsFor?.let { reel ->
        ReelCommentsSheet(api, session, reel, onDismiss = { commentsFor = null }) {
            message = it
            refresh()
        }
    }

    shareFor?.let { reel ->
        ReelShareSheet(api, session, reel, onDismiss = { shareFor = null }) { message = it }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            loading && reels.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
            reels.isEmpty() -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.SmartDisplay, null, tint = Color.White, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(10.dp))
                Text("لا توجد Reels بعد", color = Color.White, fontWeight = FontWeight.Bold)
                if (cfg.bool("reels.upload_enabled", true)) {
                    TextButton(onClick = { picker.launch("video/*") }) { Text("انشر أول Reel") }
                }
            }
            else -> {
                val initial = remember(reels, initialReelId) {
                    reels.indexOfFirst { it.id == initialReelId }.takeIf { it >= 0 } ?: 0
                }
                val pager = rememberPagerState(initialPage = initial, pageCount = { reels.size })
                VerticalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                    val reel = reels[page]
                    ReelPage(
                        reel = reel,
                        active = pager.currentPage == page,
                        onProfile = { onOpenProfile(reel.userId) },
                        onFollow = {
                            val target = !reel.following
                            scope.launch {
                                withContext(Dispatchers.IO) { api.setFollowing(session, reel.userId, target) }
                                    .onSuccess { reels = reels.map { if (it.id == reel.id) it.copy(following = target) else it } }
                                    .onFailure { message = it.message }
                            }
                        },
                        onLike = {
                            val target = !reel.liked
                            scope.launch {
                                withContext(Dispatchers.IO) { api.setReelLiked(session, reel.id, target) }
                                    .onSuccess {
                                        reels = reels.map {
                                            if (it.id == reel.id) it.copy(
                                                liked = target,
                                                likeCount = (it.likeCount + if (target) 1 else -1).coerceAtLeast(0)
                                            ) else it
                                        }
                                    }.onFailure { message = it.message }
                            }
                        },
                        onComments = { commentsFor = reel },
                        onShare = { shareFor = reel },
                        onSave = {
                            val target = !reel.saved
                            scope.launch {
                                withContext(Dispatchers.IO) { api.setReelSaved(session, reel.id, target) }
                                    .onSuccess { reels = reels.map { if (it.id == reel.id) it.copy(saved = target) else it } }
                                    .onFailure { message = it.message }
                            }
                        },
                        onDownload = {
                            runCatching { downloadReel(context, reel.videoUrl, reel.id) }
                                .onSuccess { message = "بدأ تحميل الفيديو." }
                                .onFailure { message = "تعذر بدء التحميل." }
                        }
                    )
                }
                LaunchedEffect(pager.currentPage) {
                    reels.getOrNull(pager.currentPage)?.let { reel ->
                        withContext(Dispatchers.IO) { api.recordReelView(session, reel.id) }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledIconButton(
                onClick = onBack,
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Black.copy(alpha = .35f))
            ) { Icon(Icons.Rounded.ArrowBack, "رجوع", tint = Color.White) }
            if (cfg.bool("reels.upload_enabled", true)) {
                FilledIconButton(
                    onClick = { picker.launch("video/*") },
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Black.copy(alpha = .35f))
                ) { Icon(Icons.Rounded.Add, "نشر Reel", tint = Color.White) }
            }
        }

        message?.let {
            Surface(
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 58.dp, start = 20.dp, end = 20.dp),
                color = Color.Black.copy(alpha = .72f),
                shape = RoundedCornerShape(16.dp)
            ) { Text(it, Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = Color.White, fontSize = 12.sp) }
            LaunchedEffect(it) { kotlinx.coroutines.delay(2200); message = null }
        }
    }
}

@Composable
private fun ReelPage(
    reel: ReelItem,
    active: Boolean,
    onProfile: () -> Unit,
    onFollow: () -> Unit,
    onLike: () -> Unit,
    onComments: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
    onDownload: () -> Unit
) {
    val cfg = LocalNativeRemoteConfig.current
    val context = LocalContext.current
    val player = remember(reel.id) { ExoPlayer.Builder(context).build() }
    var usingFallback by remember(reel.id) { mutableStateOf(false) }
    var paused by remember(reel.id) { mutableStateOf(false) }

    fun source(): String {
        val primary = reel.hlsUrl?.takeIf { it.isNotBlank() } ?: reel.videoUrl
        return if (usingFallback) reel.lowQualityUrl?.takeIf { it.isNotBlank() } ?: primary else primary
    }

    DisposableEffect(reel.id) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (!usingFallback && !reel.lowQualityUrl.isNullOrBlank()) {
                    usingFallback = true
                    player.setMediaItem(MediaItem.fromUri(reel.lowQualityUrl!!))
                    player.prepare()
                    if (active && !paused) player.play()
                }
            }
        }
        player.addListener(listener)
        player.repeatMode = Player.REPEAT_MODE_ONE
        player.setMediaItem(MediaItem.fromUri(source()))
        player.prepare()
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    LaunchedEffect(active, paused) { if (active && !paused) player.play() else player.pause() }

    Box(
        Modifier.fillMaxSize().background(Color.Black).clickable { paused = !paused }
    ) {
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { useController = false; this.player = player } },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize()
        )
        if (paused) {
            Surface(Modifier.align(Alignment.Center).size(62.dp), shape = CircleShape, color = Color.Black.copy(alpha = .42f)) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlayArrow, "تشغيل", tint = Color.White, modifier = Modifier.size(36.dp)) }
            }
        }

        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 10.dp, bottom = 92.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            ReelSideButton(if (reel.liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, reel.likeCount.toString(), onLike)
            ReelSideButton(Icons.Rounded.ChatBubbleOutline, reel.commentCount.toString(), onComments)
            ReelSideButton(Icons.Rounded.Send, "مشاركة", onShare)
            ReelSideButton(if (reel.saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder, "حفظ", onSave)
            if (cfg.bool("reels.download_enabled", true)) ReelSideButton(Icons.Rounded.Download, "تحميل", onDownload)
        }

        Column(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 14.dp, end = 76.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable(onClick = onProfile)) {
                    StudentAvatar(reel.authorName, reel.authorAvatarUrl, reel.authorFrameUrl, 38.dp)
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.clickable(onClick = onProfile)) {
                    StudentName(reel.authorName, reel.authorVerified, reel.authorVerificationColor)
                    Text("@${reel.authorUsername}", color = Color.White.copy(alpha = .82f), fontSize = 10.sp)
                }
                if (!reel.following) {
                    Spacer(Modifier.width(10.dp))
                    OutlinedButton(
                        onClick = onFollow,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                    ) { Text("متابعة", fontSize = 11.sp) }
                }
            }
            if (reel.caption.isNotBlank()) Text(reel.caption, color = Color.White, fontSize = 13.sp, maxLines = 3)
            Text(
                if (!reel.hlsUrl.isNullOrBlank()) "الجودة: تلقائية حسب سرعة الإنترنت" else "الجودة: أصلية${if (!reel.lowQualityUrl.isNullOrBlank()) " + احتياطية منخفضة" else ""}",
                color = Color.White.copy(alpha = .62f), fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun ReelSideButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(onClick = onClick, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Black.copy(alpha = .28f))) {
            Icon(icon, label, tint = Color.White)
        }
        Text(label, color = Color.White, fontSize = 9.sp)
    }
}

@Composable
private fun ReelCommentsSheet(
    api: SupabaseApi,
    session: StudentSession,
    reel: ReelItem,
    onDismiss: () -> Unit,
    onChanged: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var comments by remember(reel.id) { mutableStateOf<List<ReelCommentItem>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<ReelCommentItem?>(null) }
    var edit by remember { mutableStateOf<ReelCommentItem?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            busy = true
            withContext(Dispatchers.IO) { api.reelComments(session, reel.id) }
                .onSuccess { comments = it }
                .onFailure { onChanged(it.message ?: "تعذر تحميل التعليقات.") }
            busy = false
        }
    }
    LaunchedEffect(reel.id) { refresh() }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().heightIn(min = 360.dp, max = 680.dp).navigationBarsPadding()) {
            Text("التعليقات", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), fontWeight = FontWeight.Black, fontSize = 19.sp)
            if (busy && comments.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth())
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                items(comments, key = { it.id }) { c ->
                    val isReply = !c.parentId.isNullOrBlank()
                    Row(
                        Modifier.fillMaxWidth().padding(start = if (isReply) 28.dp else 0.dp, top = 7.dp, bottom = 7.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        StudentAvatar(c.authorName, c.authorAvatarUrl, c.authorFrameUrl, 34.dp)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StudentName(c.authorName, c.authorVerified, c.authorVerificationColor)
                                Spacer(Modifier.width(5.dp))
                                Text("@${c.authorUsername}", color = StudentMuted, fontSize = 9.sp)
                            }
                            Text(c.content, fontSize = 13.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { replyTo = c; edit = null; input = "" }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("رد", fontSize = 10.sp) }
                                TextButton(onClick = {
                                    val next = if (c.myReaction == "❤️") null else "❤️"
                                    scope.launch {
                                        withContext(Dispatchers.IO) { api.setReelCommentReaction(session, c.id, next) }
                                            .onSuccess { refresh() }.onFailure { onChanged(it.message ?: "تعذر حفظ التفاعل.") }
                                    }
                                }, contentPadding = PaddingValues(horizontal = 4.dp)) {
                                    Text("${c.myReaction ?: "♡"}${if (c.reactionCount > 0) " ${c.reactionCount}" else ""}", fontSize = 10.sp)
                                }
                                if (c.userId == session.userId) {
                                    TextButton(onClick = { edit = c; replyTo = null; input = c.content }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("تعديل", fontSize = 10.sp) }
                                    TextButton(onClick = {
                                        scope.launch {
                                            withContext(Dispatchers.IO) { api.deleteReelComment(session, c.id) }
                                                .onSuccess { onChanged("تم حذف التعليق."); refresh() }
                                                .onFailure { onChanged(it.message ?: "تعذر حذف التعليق.") }
                                        }
                                    }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("حذف", fontSize = 10.sp, color = Color(0xFFC62828)) }
                                }
                            }
                        }
                    }
                }
            }
            (replyTo ?: edit)?.let {
                Surface(color = StudentSoft, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (edit != null) "تعديل التعليق" else "رد على ${it.authorName}", Modifier.weight(1f), fontSize = 11.sp, color = StudentMuted)
                        IconButton(onClick = { replyTo = null; edit = null; input = "" }) { Icon(Icons.Rounded.Close, "إلغاء") }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it.take(1500) }, placeholder = { Text("اكتب تعليقًا") }, modifier = Modifier.weight(1f), maxLines = 4)
                Spacer(Modifier.width(6.dp))
                FilledIconButton(onClick = {
                    val body = input.trim()
                    if (body.isBlank()) return@FilledIconButton
                    val editing = edit
                    val parent = replyTo?.id
                    scope.launch {
                        busy = true
                        val r = withContext(Dispatchers.IO) {
                            if (editing != null) api.editReelComment(session, editing.id, body)
                            else api.addReelComment(session, reel.id, body, parent)
                        }
                        busy = false
                        r.onSuccess {
                            input = ""; replyTo = null; edit = null
                            onChanged(if (editing != null) "تم تعديل التعليق." else "تم نشر التعليق.")
                            refresh()
                        }.onFailure { onChanged(it.message ?: "تعذر حفظ التعليق.") }
                    }
                }, enabled = input.isNotBlank() && !busy) { Icon(Icons.Rounded.Send, "إرسال") }
            }
        }
    }
}

@Composable
private fun ReelShareSheet(
    api: SupabaseApi,
    session: StudentSession,
    reel: ReelItem,
    onDismiss: () -> Unit,
    onMessage: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var conversations by remember { mutableStateOf<List<ConversationItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { api.conversations(session) }
            .onSuccess { conversations = it }
            .onFailure { onMessage(it.message ?: "تعذر تحميل المحادثات.") }
        busy = false
    }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().heightIn(max = 650.dp).navigationBarsPadding()) {
            Text("إرسال الريل إلى", Modifier.padding(16.dp), fontWeight = FontWeight.Black, fontSize = 18.sp)
            OutlinedTextField(
                query, { query = it.take(80) },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                placeholder = { Text("بحث في المحادثات") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                singleLine = true
            )
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            val filtered = conversations.filter { query.isBlank() || it.title.contains(query, true) }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(10.dp)) {
                items(filtered, key = { it.id }) { c ->
                    ListItem(
                        headlineContent = { StudentName(c.title, c.isVerified, c.verificationColor) },
                        supportingContent = { Text(c.lastMessage, maxLines = 1) },
                        leadingContent = { StudentAvatar(c.title, c.avatarUrl, c.profileFrameUrl, 42.dp) },
                        modifier = Modifier.clickable {
                            scope.launch {
                                busy = true
                                withContext(Dispatchers.IO) { api.sendReelMessage(session, c.id, reel) }
                                    .onSuccess { onMessage("تم إرسال الريل."); onDismiss() }
                                    .onFailure { onMessage(it.message ?: "تعذر إرسال الريل.") }
                                busy = false
                            }
                        }
                    )
                }
            }
        }
    }
}

private fun downloadReel(context: Context, url: String, reelId: String) {
    val request = DownloadManager.Request(Uri.parse(url))
        .setTitle("Student Reel")
        .setDescription("جارٍ تحميل الفيديو")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Student-Reel-$reelId.mp4")
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(false)
    (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
}
