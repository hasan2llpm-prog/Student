package com.student.feature.home

import android.content.Context
import android.content.Intent
import android.app.Activity
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.student.core.data.StudentSession
import com.student.core.data.SupabaseApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.absoluteValue


private fun studentLearningDate(): LocalDate =
    ZonedDateTime.now(ZoneId.of("Asia/Baghdad")).minusHours(8).toLocalDate()

private fun millisUntilNextLearningRefresh(): Long {
    val zone = ZoneId.of("Asia/Baghdad")
    val now = ZonedDateTime.now(zone)
    var next = now.toLocalDate().atTime(8, 0).atZone(zone)
    if (!next.isAfter(now)) next = next.plusDays(1)
    return java.time.Duration.between(now, next).toMillis().coerceAtLeast(1000L)
}

@Composable
fun EnglishAcademyScreen(api: SupabaseApi, session: StudentSession, initialSection: String = "hub") {
    var section by remember(initialSection) { mutableStateOf(initialSection) }
    var dailyRefreshTick by remember { mutableIntStateOf(0) }
    var featureControls by remember { mutableStateOf<Map<String,Boolean>>(emptyMap()) }
    LaunchedEffect(session.userId) {
        withContext(Dispatchers.IO) { api.v14FeatureControls(session) }.onSuccess { featureControls = it }
    }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(millisUntilNextLearningRefresh() + 1200L)
            dailyRefreshTick++
        }
    }
    if (section == "hub") EnglishLearningHub(featureControls) { section = it }
    else {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { section = "hub" }) { Icon(Icons.Rounded.ArrowBack, "رجوع") }
                Text(sectionTitle(section), fontWeight = FontWeight.Black, fontSize = 20.sp, color = StudentText)
            }
            HorizontalDivider(color = StudentBorder)
            Box(Modifier.fillMaxSize()) {
                key(dailyRefreshTick) {
                when (section) {
                    "vocabulary" -> VocabularySection(api, session)
                    "parts" -> LessonSection("Parts of Speech • Relations • Functions", EnglishSeedContent.posLessons)
                    "verbs" -> VerbsSection(api, session)
                    "grammar" -> LessonSection("Grammar & Tenses", EnglishSeedContent.grammarLessons)
                    "reading" -> ReadingSection()
                    "listening" -> ListeningSection(api, session)
                    "pronunciation" -> PronunciationSection(api, session)
                    "skills" -> SkillsSection(api, session)
                    "phrasal" -> SimpleDailySection("Phrasal Verbs", listOf(
                        "look after — يعتني بـ","find out — يكتشف / يعرف","give up — يستسلم","turn on — يشغّل","pick up — يلتقط",
                        "carry on — يواصل","come across — يصادف","get along — ينسجم","get back — يعود","grow up — يكبر",
                        "look for — يبحث عن","look forward to — يتطلع إلى","put off — يؤجل","run out of — ينفد منه","set up — يؤسس",
                        "take off — يقلع / يخلع","work out — يجد حلاً / يتمرن","bring up — يطرح موضوعاً","call off — يلغي","check in — يسجل الوصول",
                        "fill in — يملأ نموذجاً","go on — يستمر","hold on — ينتظر","make up — يختلق / يتصالح","turn down — يرفض / يخفض"
                    ))
                    "idioms" -> SimpleDailySection("Idioms & Expressions", listOf(
                        "piece of cake — سهل جداً","break the ice — يكسر حاجز الصمت","once in a blue moon — نادراً جداً","under the weather — متوعك","keep an eye on — يراقب",
                        "hit the books — يدرس بجد","cost an arm and a leg — غالي جداً","better late than never — أن تأتي متأخراً خير من ألا تأتي","on the same page — متفقون","call it a day — ينهي العمل لليوم",
                        "get the ball rolling — يبدأ العمل","in hot water — في مشكلة","miss the boat — يفوّت الفرصة","no pain no gain — لا نجاح بلا تعب","speak of the devil — ذكرنا الشخص فظهر",
                        "the best of both worlds — يجمع أفضل ميزتين","time flies — الوقت يمر بسرعة","a blessing in disguise — خير جاء في صورة مشكلة","bite the bullet — يواجه أمراً صعباً","go the extra mile — يبذل جهداً إضافياً",
                        "learn the ropes — يتعلم أساسيات العمل","out of the blue — بشكل مفاجئ","pull yourself together — تمالك نفسك","see eye to eye — يتفق تماماً","take it easy — خذ الأمور ببساطة"
                    ))
                    "spelling" -> SpellingSection()
                    "writing" -> WritingSection()
                    "speaking" -> SpeakingSection(api, session)
                    "progress" -> EnglishProgressSection()
                    "daily" -> DailyChallenge()
                    "cefr" -> CefrPlacementSection()
                    else -> EnglishLearningHub(featureControls) { section = it }
                }
                }
            }
        }
    }
}

private fun sectionTitle(key: String) = when(key) {
    "vocabulary" -> "تعلم المفردات"
    "parts" -> "Parts of Speech"
    "verbs" -> "الأفعال"
    "grammar" -> "الأزمنة والقواعد"
    "reading" -> "Reading"
    "listening" -> "Listening"
    "pronunciation" -> "Pronunciation"
    "skills" -> "مهارات اللغة"
    "phrasal" -> "Phrasal Verbs"
    "idioms" -> "Idioms"
    "spelling" -> "Spelling"
    "writing" -> "Writing"
    "speaking" -> "Speaking"
    "progress" -> "تقدمي"
    "daily" -> "Daily Challenge"
    "cefr" -> "CEFR & تحديد المستوى"
    else -> "Learn English"
}

@Composable
private fun EnglishLearningHub(featureControls: Map<String,Boolean>, onOpen: (String) -> Unit) {
    val cards = listOf(
        Triple("cefr","CEFR & Placement Test","حدد مستواك من A1 إلى C2 وتابع تقدمك"),
        Triple("vocabulary","تعلم المفردات","10 كلمات يومية تتجدد الساعة 8 + مراجعة ذكية واختبارات"),
        Triple("parts","Parts of Speech","الأنواع والعلاقات والوظائف"),
        Triple("verbs","Regular & Irregular Verbs","5 شاذة + 5 قياسية ومراجعة"),
        Triple("grammar","Grammar & Tenses","قواعد وأزمنة واختبار يومي"),
        Triple("reading","Reading","قطعة + نطق + 5 أسئلة"),
        Triple("listening","Listening","استماع وفهم تدريجي"),
        Triple("pronunciation","Pronunciation","نطق أمريكي وبريطاني"),
        Triple("phrasal","Phrasal Verbs","أفعال مركبة شائعة"),
        Triple("idioms","Idioms & Expressions","تعبيرات مستخدمة فعلياً"),
        Triple("spelling","Spelling","اسمع واكتب وصحح فوراً"),
        Triple("writing","Writing","تمرين كتابة يومي بخطوات واضحة"),
        Triple("speaking","Speaking","مواقف يومية ونطق نموذجي"),
        Triple("progress","تقدمي","راجع إنجازك والكلمات المحفوظة"),
        Triple("daily","Daily Challenge","اختبار يومي مختلط")
    ).filter { (key,_,_) -> featureControls[key] != false }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFF111827), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("English Learning Path", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("تعلم يومي تلقائي • مراجعة متباعدة • اختبارات فورية", color = Color(0xFFD1D5DB))
                }
            }
        }
        items(cards) { (key,title,sub) ->
            StudentOutlinedCard(Modifier.fillMaxWidth().clickable { onOpen(key) }) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(15.dp), color = StudentSoft, modifier = Modifier.size(48.dp)) {
                        Box(contentAlignment = Alignment.Center) { Icon(iconFor(key), null, tint = StudentBlue) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Black, color = StudentText); Text(sub, color = StudentMuted, fontSize = 12.sp) }
                    Icon(Icons.Rounded.ChevronRight, null, tint = StudentMuted)
                }
            }
        }
    }
}

private fun iconFor(key:String) = when(key) {
    "cefr" -> Icons.Rounded.TrendingUp
    "vocabulary" -> Icons.Rounded.MenuBook
    "parts" -> Icons.Rounded.AccountTree
    "verbs" -> Icons.Rounded.SyncAlt
    "grammar" -> Icons.Rounded.Spellcheck
    "reading" -> Icons.Rounded.Article
    "listening" -> Icons.Rounded.Headphones
    "pronunciation" -> Icons.Rounded.RecordVoiceOver
    "phrasal" -> Icons.Rounded.Hub
    "idioms" -> Icons.Rounded.Lightbulb
    "spelling" -> Icons.Rounded.EditNote
    "writing" -> Icons.Rounded.Draw
    "speaking" -> Icons.Rounded.Mic
    "progress" -> Icons.Rounded.Insights
    else -> Icons.Rounded.EmojiEvents
}

@Composable
private fun VocabularySection(api: SupabaseApi, session: StudentSession) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("student_english", Context.MODE_PRIVATE) }
    val speech = rememberStudentSpeechController()
    val scope = rememberCoroutineScope()
    var remoteWords by remember { mutableStateOf<List<EnglishWord>>(emptyList()) }
    var extraBatch by remember { mutableIntStateOf(0) }
    LaunchedEffect(session.userId) {
        withContext(Dispatchers.IO) { api.englishVocabulary(session, limit = 5000) }
            .onSuccess { rows ->
                if (rows.isNotEmpty()) remoteWords = rows.map { row ->
                    EnglishWord(row.id, row.word, row.meaningAr, row.level, row.exampleEn.ifBlank { row.word }, row.exampleAr)
                }
            }
    }
    val sourceWords = if (remoteWords.isNotEmpty()) remoteWords else EnglishSeedContent.words
    val dayKey = studentLearningDate().toString()
    val baseStart = remember(dayKey, sourceWords.size) {
        if (sourceWords.isEmpty()) 0 else (dayKey.hashCode().absoluteValue % sourceWords.size)
    }
    fun batch(offset: Int): List<EnglishWord> {
        if (sourceWords.isEmpty()) return emptyList()
        val rotated = sourceWords.drop(baseStart) + sourceWords.take(baseStart)
        return rotated.drop(offset * 10).take(10).distinctBy { it.id }
    }
    val today = batch(extraBatch)
    var accent by remember { mutableStateOf("american") }
    var speed by remember { mutableStateOf("normal") }
    var quiz by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    if (quiz) {
        VocabularyQuiz(today, onClose = { quiz = false }, onNextBatch = { quiz = false; extraBatch++ })
        return
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (extraBatch == 0) "كلمات اليوم الأساسية — 10 كلمات" else "10 كلمات إضافية", fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text(
                        if (extraBatch == 0) "هذه المجموعة تبقى نفسها كل مرة تدخل اليوم. بعد إنهائها يمكنك متابعة مجموعات إضافية، لكن عند الدخول من جديد نبدأ بمجموعة اليوم حتى تثبت في الذاكرة."
                        else "هذه مجموعة إضافية اختيارية. مجموعة اليوم الأساسية لا تتغير حتى نهاية اليوم.",
                        color = StudentMuted
                    )
                    Text("كل كلمة: معنى + نطق + أكثر من مثال + ترجمة + تذكير لاحق. الكلمات الصعبة تعود تلقائياً في المراجعات.", color = StudentBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(accent=="american", {accent="american"}, {Text("US")})
                        FilterChip(accent=="british", {accent="british"}, {Text("UK")})
                        FilterChip(speed=="slow", {speed="slow"}, {Text("بطيء")})
                        FilterChip(speed=="normal", {speed="normal"}, {Text("عادي")})
                    }
                    Button(onClick={quiz=true}, enabled=today.isNotEmpty(), modifier=Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Quiz,null); Spacer(Modifier.width(6.dp)); Text("اختبار متنوع على هذه الكلمات") }
                    if (extraBatch > 0) OutlinedButton(onClick={extraBatch=0}, modifier=Modifier.fillMaxWidth()) { Text("العودة إلى كلمات اليوم الأساسية") }
                    message?.let { Text(it, color=Color(0xFF16834A), fontWeight=FontWeight.Bold) }
                }
            }
        }
        items(today, key={it.id}) { w ->
            var expanded by remember(w.id) { mutableStateOf(false) }
            val saved = prefs.getBoolean("review_${w.id}", false)
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(w.word, fontSize=22.sp, fontWeight=FontWeight.Black)
                            Text("المعنى: ${w.meaningAr}  •  ${w.level}", color=StudentBlue, fontWeight=FontWeight.Bold)
                        }
                        IconButton(onClick={speech.speak(w.word,accent,speed)}) { Icon(Icons.Rounded.VolumeUp,"نطق") }
                    }
                    Text("ابدأ بحفظ المعنى، ثم اسمع النطق، وبعدها اقرأ الأمثلة بصوت مرتفع.", color = StudentMuted, fontSize = 11.sp)
                    OutlinedButton(onClick={expanded=!expanded}, modifier=Modifier.fillMaxWidth()) { Text(if(expanded) "إخفاء الأمثلة" else "أمثلة واستخدام الكلمة") }
                    if(expanded) {
                        Text("1. ${w.example}", fontWeight=FontWeight.Bold)
                        Text("الترجمة: ${w.exampleAr}", color=StudentMuted)
                        Text("2. ${vocabularyExtraExample(w)}", fontWeight=FontWeight.Bold)
                        Text("الترجمة: ${vocabularyExtraExampleAr(w)}", color=StudentMuted)
                        Text("3. حاول الآن أن تقول جملة من عندك باستعمال ${w.word}.", color=StudentBlue, fontWeight=FontWeight.Bold)
                        Button(onClick={speech.speak(w.example,accent,speed)}, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Rounded.GraphicEq,null); Spacer(Modifier.width(6.dp)); Text("نطق المثال الأول") }
                    }
                    OutlinedButton(onClick={
                        prefs.edit().putBoolean("review_${w.id}", true).apply()
                        scope.launch { withContext(Dispatchers.IO) { api.rememberEnglishWord(session, w.word) } }
                        message="تمت إضافة ${w.word} إلى المراجعة اللاحقة."
                    }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.outlinedButtonColors(contentColor=if(saved) Color(0xFF16834A) else StudentBlue)) {
                        Icon(if(saved) Icons.Rounded.CheckCircle else Icons.Rounded.NotificationsActive,null); Spacer(Modifier.width(6.dp)); Text(if(saved) "محفوظة للمراجعة" else "ذكرني بها لاحقاً")
                    }
                }
            }
        }
        item {
            if (today.isEmpty()) {
                MasteryModeCard("المفردات")
            } else {
                OutlinedButton(onClick = { extraBatch++ }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.SkipNext, null); Spacer(Modifier.width(6.dp)); Text("تعلم 10 كلمات إضافية الآن")
                }
            }
        }
    }
}

private fun vocabularyExtraExample(w: EnglishWord): String = when (w.word.lowercase()) {
    "accept" -> "They accepted my invitation."
    "achieve" -> "You can achieve more with daily practice."
    "advice" -> "My teacher gave me useful advice."
    "learn" -> "We learn new things every day."
    "speak" -> "She speaks English with her friends."
    "write" -> "Please write your name here."
    else -> "I want to use the word '${w.word}' correctly."
}
private fun vocabularyExtraExampleAr(w: EnglishWord): String = when (w.word.lowercase()) {
    "accept" -> "لقد قبلوا دعوتي."
    "achieve" -> "يمكنك تحقيق المزيد بالممارسة اليومية."
    "advice" -> "أعطاني مدرسي نصيحة مفيدة."
    "learn" -> "نتعلم أشياء جديدة كل يوم."
    "speak" -> "هي تتحدث الإنجليزية مع أصدقائها."
    "write" -> "من فضلك اكتب اسمك هنا."
    else -> "أريد أن أستخدم هذه الكلمة بشكل صحيح."
}

@Composable
private fun VocabularyQuiz(words: List<EnglishWord>, onClose:()->Unit, onNextBatch:()->Unit) {
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf<String?>(null) }
    if(index >= words.size) {
        Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
            StudentOutlinedCard(Modifier.padding(20.dp)) {
                Column(Modifier.padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text("النتيجة $score / ${words.size}", fontSize=24.sp,fontWeight=FontWeight.Black)
                    Text("الاختبار انتهى. الكلمات التي اخترت لها (ذكرني لاحقاً) ستعود في المراجعات القادمة.", color=StudentMuted)
                    Button(onClick=onNextBatch, modifier=Modifier.fillMaxWidth()){Text("انتقل إلى 10 كلمات إضافية")}
                    OutlinedButton(onClick=onClose, modifier=Modifier.fillMaxWidth()){Text("العودة للكلمات")}
                }
            }
        }; return
    }
    val w=words[index]
    val mode=index%3
    val wordPool=(words.filter{it.id!=w.id}.map{it.word}.shuffled().take(3)+w.word).shuffled()
    val meaningPool=(words.filter{it.id!=w.id}.map{it.meaningAr}.shuffled().take(3)+w.meaningAr).shuffled()
    val question = when(mode) {
        0 -> "اختر المعنى العربي الصحيح للكلمة: ${w.word}"
        1 -> "اختر الكلمة التي تكمل المعنى: (${w.meaningAr})"
        else -> "أي كلمة مناسبة لهذا المثال؟ ${w.example.replace(w.word, "□□□□", ignoreCase = true)}"
    }
    val arabicHelp = when(mode) {
        0 -> "المطلوب: اقرأ الكلمة الإنجليزية واختر ترجمتها الصحيحة."
        1 -> "المطلوب: اقرأ المعنى العربي واختر الكلمة الإنجليزية المناسبة."
        else -> "المطلوب: اختر الكلمة التي تجعل الجملة صحيحة."
    }
    val options = if(mode==0) meaningPool else wordPool
    val correct = if(mode==0) w.meaningAr else w.word
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("السؤال ${index+1} من ${words.size}", color=StudentBlue,fontWeight=FontWeight.Bold)
        Text(question,fontSize=20.sp,fontWeight=FontWeight.Black)
        Text(arabicHelp,color=StudentMuted)
        options.forEach { answer -> OutlinedButton(onClick={ if(feedback==null){ val ok=answer.equals(correct,true); if(ok)score++; feedback=if(ok)"✓ صحيح — ${w.word} تعني ${w.meaningAr}." else "✗ الصحيح: $correct — ${w.word} تعني ${w.meaningAr}." } }, modifier=Modifier.fillMaxWidth()){Text(answer)} }
        feedback?.let { Text(it,color=if(it.startsWith("✓"))Color(0xFF16834A) else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold); Button(onClick={index++;feedback=null},modifier=Modifier.fillMaxWidth()){Text("التالي")}}
    }
}

@Composable
private fun LessonSection(title:String, lessons:List<EnglishMiniLesson>) {
    val dayKey=studentLearningDate().toString()
    val baseIndex=remember(dayKey,lessons.size){ if(lessons.isEmpty())0 else dayKey.hashCode().absoluteValue%lessons.size }
    var extraOffset by remember { mutableIntStateOf(0) }
    val lesson=lessons[(baseIndex+extraOffset)%lessons.size]
    var chosen by remember(lesson.id){mutableStateOf<Int?>(null)}
    var practiceIndex by remember(lesson.id){mutableIntStateOf(0)}
    val practices=beginnerPracticeFor(lesson)
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item {
            Text(if(extraOffset==0)"درس اليوم الأساسي" else "درس إضافي",color=StudentBlue,fontWeight=FontWeight.Bold)
            Text(lesson.title,fontSize=24.sp,fontWeight=FontWeight.Black)
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text("الشرح من الصفر",fontWeight=FontWeight.Black)
                    Text(beginnerExplanationFor(lesson), color=StudentText, lineHeight=23.sp)
                    Text("القاعدة المختصرة: ${lesson.summary}", color=StudentBlue,fontWeight=FontWeight.Bold)
                    Text("مثال 1: ${lesson.example}",fontWeight=FontWeight.Bold)
                    Text("الترجمة: ${translateLessonExample(lesson)}",color=StudentMuted)
                    beginnerExamplesFor(lesson).forEachIndexed { i,e -> Text("مثال ${i+2}: $e",fontWeight=FontWeight.Bold) }
                }
            }
        }
        item {
            Text("اختبارات متنوعة",fontSize=18.sp,fontWeight=FontWeight.Black)
            val p=practices[practiceIndex.coerceIn(0,practices.lastIndex)]
            Text(p.question,fontWeight=FontWeight.Bold)
            Text(p.help,color=StudentMuted)
            p.options.forEachIndexed { i,opt -> OutlinedButton(onClick={chosen=i},modifier=Modifier.fillMaxWidth(),border=BorderStroke(1.dp, if(chosen==i)StudentBlue else StudentBorder)){Text(opt)} }
            chosen?.let { c ->
                Spacer(Modifier.height(5.dp))
                Text(if(c==p.correctIndex)"✓ صحيح — ${p.explanation}" else "✗ الصحيح: ${p.options[p.correctIndex]} — ${p.explanation}",color=if(c==p.correctIndex)Color(0xFF16834A) else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold)
                if(practiceIndex<practices.lastIndex) Button(onClick={practiceIndex++;chosen=null},modifier=Modifier.fillMaxWidth()){Text("سؤال مختلف")}
                else Button(onClick={extraOffset++;practiceIndex=0;chosen=null},modifier=Modifier.fillMaxWidth()){Text("أكملت الدرس — انتقل للدرس التالي")}
            }
        }
        if(extraOffset>0) item { OutlinedButton(onClick={extraOffset=0;practiceIndex=0;chosen=null},modifier=Modifier.fillMaxWidth()){Text("العودة إلى درس اليوم الأساسي")}}
    }
}

data class BeginnerPractice(val question:String,val help:String,val options:List<String>,val correctIndex:Int,val explanation:String)
private fun beginnerExplanationFor(l:EnglishMiniLesson):String = when(l.id) {
    "g01" -> "المضارع البسيط نستخدمه عندما نتكلم عن شيء يحدث بشكل متكرر أو حقيقة عامة. مع I/You/We/They نستخدم الفعل كما هو. مع He/She/It غالباً نضيف s أو es. في النفي نستخدم don't أو doesn't ثم الفعل بدون s."
    "g02" -> "المضارع المستمر يصف شيئاً يحدث الآن في هذه اللحظة. نحتاج أولاً am/is/are ثم نضيف ing إلى الفعل. مثال: I am studying = أنا أدرس الآن."
    "g03" -> "الماضي البسيط يعني أن الفعل بدأ وانتهى في الماضي. الأفعال القياسية غالباً تأخذ ed، أما الأفعال الشاذة فلها شكل خاص يجب حفظه."
    "g04" -> "نستعمل will عندما نتوقع شيئاً في المستقبل أو نقرر شيئاً الآن. بعد will يأتي الفعل بصيغته الأصلية بدون s أو ed أو ing."
    "g05" -> "الشرط الأول نتكلم به عن احتمال حقيقي في المستقبل. الجزء بعد if يكون مضارعاً بسيطاً، والنتيجة غالباً will + فعل أصلي."
    "g06" -> "أدوات الربط توصل فكرتين: and للإضافة، but للتعارض، because لذكر السبب، وso لذكر النتيجة."
    "p01" -> "الاسم Noun هو كلمة نسمي بها شخصاً أو مكاناً أو شيئاً أو فكرة. مثل: teacher, Baghdad, book, love. إذا استطعت أن تسأل (من؟ أو ما؟) فغالباً الإجابة اسم."
    "p02" -> "الفعل Verb يخبرنا ماذا يفعل الشخص أو ما حالته. مثل study, run, speak، وكذلك be مثل is وare."
    "p03" -> "الصفة Adjective تصف الاسم وتخبرنا كيف هو: big house, smart student. الصفة لا تصف الفعل بل تصف الاسم."
    "p04" -> "الظرف Adverb يصف كيف حدث الفعل، مثل slowly وcarefully، وكثير منها ينتهي بـ ly."
    else -> "ابدأ بتحديد الكلمات في الجملة ووظيفة كل كلمة. الفاعل يقوم بالفعل، والمفعول به يتلقى أثر الفعل. اقرأ المثال ببطء وحدد: من فعل؟ وماذا وقع عليه الفعل؟"
}
private fun translateLessonExample(l:EnglishMiniLesson):String = when(l.id) {
    "g01" -> "هي تدرس الإنجليزية كل يوم."
    "g02" -> "هم يدرسون الآن."
    "g03" -> "زرنا بغداد أمس."
    "g04" -> "سأتصل بك لاحقاً."
    "g05" -> "إذا درست فسوف تنجح."
    "g06" -> "بقيت في المنزل لأنني كنت متعباً."
    "p01" -> "طالب، مدينة، كتاب، حرية."
    "p02" -> "يدرس، يتحدث، يكون، يعرف."
    "p03" -> "سؤال صعب."
    "p04" -> "هي تتحدث بوضوح."
    else -> "علي يقرأ الكتاب: علي فاعل، والكتاب مفعول به."
}
private fun beginnerExamplesFor(l:EnglishMiniLesson):List<String> = when(l.id) {
    "g01" -> listOf("I play football every Friday. — ألعب كرة القدم كل جمعة.","He works at a school. — هو يعمل في مدرسة.","She doesn't drink coffee. — هي لا تشرب القهوة.")
    "g02" -> listOf("She is reading now. — هي تقرأ الآن.","We are learning English. — نحن نتعلم الإنجليزية.","He isn't sleeping. — هو لا ينام الآن.")
    "g03" -> listOf("I watched a film yesterday. — شاهدت فلماً أمس.","He went home early. — ذهب إلى البيت مبكراً.","They didn't study. — لم يدرسوا.")
    "g04" -> listOf("We will meet tomorrow. — سنلتقي غداً.","I will help you. — سأساعدك.","She will not be late. — لن تتأخر.")
    "g05" -> listOf("If you practise, you will improve. — إذا تدربت ستتحسن.","If she comes, I will tell her. — إذا جاءت سأخبرها.","If we hurry, we will catch the bus. — إذا أسرعنا سنلحق الحافلة.")
    "g06" -> listOf("I like tea and coffee. — أحب الشاي والقهوة.","He is tired but he is working. — هو متعب لكنه يعمل.","It was raining, so we stayed home. — كانت تمطر لذلك بقينا في المنزل.")
    "p01" -> listOf("Ahmed is a student. — Ahmed وstudent اسمان.","The book is new. — book اسم.","Baghdad is a city. — Baghdad وcity اسمان.")
    "p02" -> listOf("Students study. — study فعل.","She speaks slowly. — speaks فعل.","They are happy. — are فعل حالة.")
    "p03" -> listOf("a beautiful day — يوم جميل.","a small room — غرفة صغيرة.","an easy question — سؤال سهل.")
    "p04" -> listOf("He walks slowly. — يمشي ببطء.","She answered correctly. — أجابت بشكل صحيح.","Speak clearly. — تحدث بوضوح.")
    else -> listOf("Sara opened the door. — Sara فاعل وthe door مفعول به.","Ali reads a book. — Ali فاعل وa book مفعول به.","The teacher helped me. — teacher فاعل وme مفعول به.")
}
private fun beginnerPracticeFor(l:EnglishMiniLesson):List<BeginnerPractice> {
    val base=BeginnerPractice(l.question,"المطلوب: اختر الإجابة التي تطبق القاعدة التي شرحناها.",l.options,l.correctIndex,"ارجع للقاعدة والأمثلة أعلاه وستجد نفس النمط.")
    return when(l.id) {
        "g01" -> listOf(base,BeginnerPractice("She □□□□ English every day.","اختر شكل الفعل الصحيح مع She.",listOf("study","studies","studying","studied"),1,"مع She في المضارع البسيط نضيف s/es."),BeginnerPractice("أي جملة تعبر عن عادة؟","ابحث عن حدث متكرر.",listOf("I am eating now.","I go to university every day.","I went yesterday.","I will go tomorrow."),1,"every day علامة شائعة على المضارع البسيط."))
        "g02" -> listOf(base,BeginnerPractice("They □□□□ now.","المطلوب am/is/are + ing.",listOf("study","are studying","studied","studies"),1,"مع They نستخدم are ثم studying."),BeginnerPractice("Which sentence means: أنا أكتب الآن؟","اختر الجملة التي تصف الآن.",listOf("I write every day.","I am writing now.","I wrote yesterday.","I will write."),1,"am writing هو المضارع المستمر مع I."))
        "g05" -> listOf(base,BeginnerPractice("If you study, you □□□□ pass.","بعد شرط حقيقي في المستقبل اختر will + verb.",listOf("will","did","are","were"),0,"النتيجة في First Conditional غالباً تبدأ بـ will."),BeginnerPractice("اختر الجملة الصحيحة.","If + present, will + base verb.",listOf("If it rains, we will stay home.","If it will rain, we stayed.","If it rained, we will staying.","If rains, stay yesterday."),0,"هذه الجملة تطبق الشكل الصحيح للشرط الأول."))
        else -> listOf(base,BeginnerPractice("أي اختيار يطابق شرح الدرس؟","اقرأ التعريف ثم قارن الخيارات.",l.options,l.correctIndex,"استخدم التعريف والأمثلة لتحديد النوع الصحيح."))
    }
}

@Composable
private fun SkillsSection(api: SupabaseApi, session: StudentSession) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Reading","Listening","Pronunciation").forEachIndexed { i,label ->
                FilterChip(selected=tab==i,onClick={tab=i},label={Text(label)},modifier=Modifier.weight(1f))
            }
        }
        Box(Modifier.weight(1f)) { when(tab){0->ReadingSection();1->ListeningSection(api, session);else->PronunciationSection(api, session)} }
    }
}

@Composable
private fun VerbsSection(api: SupabaseApi, session: StudentSession) {
    val context=LocalContext.current
    val prefs=remember{context.getSharedPreferences("student_english_daily",Context.MODE_PRIVATE)}
    val speech=rememberStudentSpeechController()
    val day=studentLearningDate().dayOfYear
    val irregularPool=EnglishSeedContent.words.filter{it.irregular}
    val regularPool=listOf(
        Triple("work — worked — worked","يعمل","I worked yesterday. — عملتُ أمس."),
        Triple("play — played — played","يلعب","She played football. — لعبت كرة القدم."),
        Triple("study — studied — studied","يدرس","We studied English. — درسنا الإنجليزية."),
        Triple("open — opened — opened","يفتح","He opened the door. — فتح الباب."),
        Triple("watch — watched — watched","يشاهد","They watched a film. — شاهدوا فيلماً."),
        Triple("clean — cleaned — cleaned","ينظف","I cleaned my room. — نظفت غرفتي."),
        Triple("visit — visited — visited","يزور","We visited our teacher. — زرنا مدرسنا."),
        Triple("help — helped — helped","يساعد","She helped me. — ساعدتني."),
        Triple("start — started — started","يبدأ","The class started early. — بدأ الدرس مبكراً."),
        Triple("finish — finished — finished","ينهي","I finished my homework. — أنهيت واجبي."),
        Triple("call — called — called","يتصل","He called his friend. — اتصل بصديقه."),
        Triple("need — needed — needed","يحتاج","They needed more time. — احتاجوا وقتاً أكثر."),
        Triple("change — changed — changed","يغيّر","We changed the plan. — غيّرنا الخطة."),
        Triple("learn — learned — learned","يتعلم","I learned a new word. — تعلمت كلمة جديدة."),
        Triple("answer — answered — answered","يجيب","She answered correctly. — أجابت بشكل صحيح.")
    )
    val irregular=if(irregularPool.isEmpty()) emptyList() else (0 until 5).map{irregularPool[(day*5+it)%irregularPool.size]}
    val regular=(0 until 5).map{regularPool[(day*5+it)%regularPool.size]}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item{Text("أفعال اليوم • تتغير تلقائياً",fontSize=22.sp,fontWeight=FontWeight.Black);Text("5 شاذة + 5 قياسية. اضغط ذكرني لاحقاً لأي فعل صعب، وسنعيده في الأيام القادمة.",color=StudentMuted)}
        item{Text("الأفعال الشاذة",fontSize=19.sp,fontWeight=FontWeight.Black)}
        items(irregular){w->StudentOutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(w.word,fontWeight=FontWeight.Black);Text("${w.past} • ${w.participle} — ${w.meaningAr}",color=StudentMuted);if(w.example.isNotBlank())Text("${w.example} — ${w.exampleAr}");Row{IconButton(onClick={speech.speak("${w.word}, ${w.past}, ${w.participle}","american","normal")}){Icon(Icons.Rounded.VolumeUp,"نطق")};TextButton(onClick={prefs.edit().putBoolean("verb_review_${w.id}",true).apply(); kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { api.rememberEnglishWord(session,w.word) }; android.widget.Toast.makeText(context,"تمت إضافة الكلمة إلى المراجعة",android.widget.Toast.LENGTH_SHORT).show()}){Text("ذكرني لاحقاً")}}}}}
        item{Text("الأفعال القياسية",fontSize=19.sp,fontWeight=FontWeight.Black)}
        items(regular){v->StudentOutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(v.first,fontWeight=FontWeight.Bold);Text(v.second,color=StudentMuted);Text(v.third);Row{IconButton(onClick={speech.speak(v.first.substringBefore(" —"),"american","normal")}){Icon(Icons.Rounded.VolumeUp,"نطق")};TextButton(onClick={prefs.edit().putBoolean("verb_review_${v.first}",true).apply(); kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { api.rememberEnglishWord(session,v.first.substringBefore(" —")) }; android.widget.Toast.makeText(context,"تمت إضافة الكلمة إلى المراجعة",android.widget.Toast.LENGTH_SHORT).show()}){Text("ذكرني لاحقاً")}}}}}
    }
}

@Composable
private fun ReadingSection() {
    val speech = rememberStudentSpeechController()
    val item = EnglishSeedContent.readingPassages[studentLearningDate().dayOfYear % EnglishSeedContent.readingPassages.size]
    val answers = listOf(
        listOf("To improve his English", "To learn math", "To travel", "To sleep"),
        listOf("Five", "Ten", "Two", "Twenty"),
        listOf("Reviewed words and wrote sentences", "Watched TV", "Played games", "Slept"),
        listOf("Reading", "Driving", "Cooking", "Running"),
        listOf("More confident", "More tired", "Angry", "Confused")
    )
    val correct = listOf(0,0,0,0,0)
    var selected by remember(item.first) { mutableStateOf<Map<Int,Int>>(emptyMap()) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(item.first, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text(item.second, lineHeight = 24.sp)
            Button(onClick = { speech.speak(item.second, "british", "slow") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Headphones, null)
                Spacer(Modifier.width(6.dp))
                Text("استمع للقطعة")
            }
            Text("5 أسئلة MCQ", fontSize = 19.sp, fontWeight = FontWeight.Black)
        }
        items(item.third.size) { i ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${i + 1}. ${item.third[i]}", fontWeight = FontWeight.Bold)
                    answers.getOrElse(i) { listOf("A","B","C","D") }.forEachIndexed { optionIndex, option ->
                        OutlinedButton(
                            onClick = { selected = selected + (i to optionIndex) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(option) }
                    }
                    selected[i]?.let { choice ->
                        Text(
                            if (choice == correct[i]) "✓ صحيح" else "✗ حاول مراجعة القطعة مرة أخرى",
                            color = if (choice == correct[i]) Color(0xFF16834A) else MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ListeningSection(api: SupabaseApi, session: StudentSession) {
    val context=LocalContext.current
    val prefs=remember{context.getSharedPreferences("student_english_daily",Context.MODE_PRIVATE)}
    val speech=rememberStudentSpeechController()
    val day=studentLearningDate().dayOfYear
    val lessons=listOf(
        Triple("Learning a language becomes easier when you practise a little every day.","تعلم اللغة يصبح أسهل عندما تتدرب قليلاً كل يوم.","ما الفكرة الرئيسية؟"),
        Triple("Sara takes the bus to university every morning and reviews vocabulary on the way.","تذهب سارة إلى الجامعة بالحافلة كل صباح وتراجع المفردات في الطريق.","ماذا تفعل سارة أثناء الطريق؟"),
        Triple("Yesterday, Ali missed the first class because the traffic was very heavy.","أمس فات عليّ الدرس الأول لأن الازدحام كان شديداً.","لماذا فات عليّ الدرس الأول؟"),
        Triple("Good sleep helps students remember information and focus during lessons.","النوم الجيد يساعد الطلاب على تذكر المعلومات والتركيز أثناء الدروس.","ما فائدة النوم الجيد للطلاب؟"),
        Triple("Mina plans to improve her English by listening to short podcasts and speaking every day.","تخطط مينا لتحسين الإنجليزية عبر الاستماع إلى بودكاست قصير والتحدث يومياً.","كيف ستطور مينا الإنجليزية؟"),
        Triple("The library closes at six, so the students decided to meet there at four.","تغلق المكتبة الساعة السادسة، لذلك قرر الطلاب اللقاء هناك الساعة الرابعة.","في أي وقت قرر الطلاب اللقاء؟"),
        Triple("Omar saved his report online before his laptop suddenly stopped working.","حفظ عمر تقريره على الإنترنت قبل أن يتوقف حاسوبه فجأة.","ماذا فعل عمر قبل تعطل الحاسوب؟")
    )
    val item=lessons[day%lessons.size]
    var show by remember(day){mutableStateOf(false)}
    var answer by remember(day){mutableStateOf<Int?>(null)}
    val options=listOf(item.second,"معلومة غير مذكورة في المقطع","السفر هو الحل الوحيد","لا توجد فكرة رئيسية")
    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(16.dp).navigationBarsPadding(),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("استماع اليوم • ${day}",fontSize=23.sp,fontWeight=FontWeight.Black)
        Text("استمع أولاً دون قراءة، ثم أظهر النص والترجمة. المحتوى يتغير يومياً.",color=StudentMuted)
        Button(onClick={speech.speak(item.first,"british","slow")},modifier=Modifier.fillMaxWidth()){Icon(Icons.Rounded.Headphones,null);Spacer(Modifier.width(6.dp));Text("استمع ببطء") }
        OutlinedButton(onClick={speech.speak(item.first,"american","normal")},modifier=Modifier.fillMaxWidth()){Text("استمع بالنطق الأمريكي") }
        OutlinedButton(onClick={show=!show},modifier=Modifier.fillMaxWidth()){Text(if(show)"إخفاء النص والترجمة" else "إظهار النص والترجمة") }
        if(show){StudentOutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(item.first,fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Text(item.second,color=StudentMuted)}}}
        Text(item.third,fontWeight=FontWeight.Black)
        options.forEachIndexed{i,opt->OutlinedButton(onClick={answer=i},modifier=Modifier.fillMaxWidth()){Text(opt)}}
        answer?.let{Text(if(it==0)"✓ صحيح — ارجع واسمعه مرة أخرى بسرعة طبيعية." else "✗ أعد الاستماع وركز على الكلمات الأساسية.",color=if(it==0)Color(0xFF16834A) else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold)}
        TextButton(onClick={prefs.edit().putBoolean("listening_review_${day}",true).apply(); android.widget.Toast.makeText(context,"تمت إضافة الاستماع إلى المراجعة",android.widget.Toast.LENGTH_SHORT).show()},modifier=Modifier.fillMaxWidth()){Text("ذكرني بهذا الاستماع لاحقاً") }
    }
}

@Composable
private fun PronunciationSection(api: SupabaseApi, session: StudentSession) {
    val context=LocalContext.current
    val prefs=remember{context.getSharedPreferences("student_english_daily",Context.MODE_PRIVATE)}
    val speech=rememberStudentSpeechController()
    val day=studentLearningDate().dayOfYear
    val groups=listOf(
        listOf("ship / sheep — سفينة / خروف","live / leave — يعيش / يغادر","bit / beat — جزء صغير / يهزم","sit / seat — يجلس / مقعد","fill / feel — يملأ / يشعر"),
        listOf("hat / hot — قبعة / حار","cat / cut — قطة / يقطع","bad / bud — سيئ / برعم","cap / cup — قبعة / كوب","ran / run — ركض / يركض"),
        listOf("fan / van — مروحة / شاحنة","fine / vine — جيد / كرمة","safe / save — آمن / يحفظ","half / have — نصف / يملك","leaf / leave — ورقة / يغادر"),
        listOf("think / sink — يفكر / يغرق","three / tree — ثلاثة / شجرة","then / den — ثم / عرين","they / day — هم / يوم","thin / tin — نحيف / قصدير")
    )
    val pairs=groups[day%groups.size]
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        item{Text("نطق اليوم",fontSize=23.sp,fontWeight=FontWeight.Black);Text("كل يوم مجموعة أصوات مختلفة. استمع US وUK وكرر بصوت مرتفع. الترجمة توضح معنى كل كلمة.",color=StudentMuted)}
        items(pairs){pair->val spoken=pair.substringBefore(" —").replace("/",",");StudentOutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(13.dp)){Text(pair,fontWeight=FontWeight.Bold);Row{IconButton(onClick={speech.speak(spoken,"american","slow")}){Icon(Icons.Rounded.VolumeUp,"US")};IconButton(onClick={speech.speak(spoken,"british","slow")}){Icon(Icons.Rounded.RecordVoiceOver,"UK")};TextButton(onClick={prefs.edit().putBoolean("pron_review_${pair.substringBefore(" —")}",true).apply(); kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { api.rememberEnglishWord(session,pair.substringBefore(" /")) }; android.widget.Toast.makeText(context,"تمت إضافة الكلمة إلى المراجعة",android.widget.Toast.LENGTH_SHORT).show()}){Text("ذكرني")}}}}}
    }
}

@Composable
private fun SimpleDailySection(title: String, itemsList: List<String>) {
    val speech = rememberStudentSpeechController()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("student_english_daily", Context.MODE_PRIVATE) }
    val day = studentLearningDate().dayOfYear
    val daily = remember(day, itemsList) {
        if (itemsList.size <= 5) itemsList else List(5) { i -> itemsList[(day * 5 + i) % itemsList.size] }.distinct()
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text(title, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("مجموعة اليوم • تتجدد الساعة 8 صباحاً", color = StudentMuted) }
        items(daily) { value ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(value, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { speech.speak(value.substringBefore(" —"), "american", "normal") }) { Icon(Icons.Rounded.VolumeUp, "نطق") }
                    TextButton(onClick = { prefs.edit().putBoolean("simple_review_${title}_${value.substringBefore(" —")}", true).apply(); android.widget.Toast.makeText(context,"تمت إضافة الكلمة إلى المراجعة",android.widget.Toast.LENGTH_SHORT).show() }) { Text("ذكرني") }
                }
            }
        }
    }
}

@Composable
private fun SpellingSection() {
    val speech = rememberStudentSpeechController()
    val word = EnglishSeedContent.words[studentLearningDate().dayOfYear % EnglishSeedContent.words.size]
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("اسمع واكتب", fontSize = 23.sp, fontWeight = FontWeight.Black)
        Button(onClick = { speech.speak(word.word, "american", "slow") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.VolumeUp, null); Spacer(Modifier.width(6.dp)); Text("اسمع الكلمة")
        }
        OutlinedTextField(input, { input = it.lowercase().filter(Char::isLetter) }, label = { Text("اكتب الكلمة") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { result = if (input.equals(word.word, true)) "✓ صحيح" else "✗ الصحيح: ${word.word}" }, modifier = Modifier.fillMaxWidth()) { Text("تحقق") }
        result?.let { Text(it, color = if (it.startsWith("✓")) Color(0xFF16834A) else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun DailyChallenge() {
    val day=studentLearningDate().dayOfYear
    val pool=EnglishSeedContent.grammarLessons
    val questions=if(pool.isEmpty()) emptyList() else (0 until minOf(5,pool.size)).map{pool[(day*3+it)%pool.size]}
    var score by remember(day){mutableIntStateOf(0)}
    var done by remember(day){mutableStateOf(setOf<String>())}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("تحدي اليوم",fontSize=24.sp,fontWeight=FontWeight.Black);Text("الأسئلة تتغير يومياً وتعود لاحقاً للمراجعة. اقرأ المطلوب بالإنجليزية والعربية.",color=StudentMuted);Text("النتيجة: $score / ${questions.size}",color=StudentBlue,fontWeight=FontWeight.Bold)}
        items(questions){q->StudentOutlinedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(q.question,fontWeight=FontWeight.Black);Text("اختر الإجابة الأنسب، ثم اقرأ التصحيح فوراً.",color=StudentMuted,fontSize=12.sp);q.options.forEachIndexed{i,opt->OutlinedButton(onClick={if(q.id !in done){done=done+q.id;if(i==q.correctIndex)score++}},modifier=Modifier.fillMaxWidth()){Text(opt)}};if(q.id in done)Text("الإجابة الصحيحة: ${q.options[q.correctIndex]} — راجع القاعدة وحاول تكوين مثال جديد بنفسك.",color=Color(0xFF16834A),fontWeight=FontWeight.Bold)}}}
    }
}



@Composable
private fun WritingSection() {
    val prompts = listOf(
        "Write 5 sentences about your daily routine.",
        "Describe a person you admire in 5–7 sentences.",
        "Write a short paragraph about why learning English is important.",
        "Write a message inviting a friend to study with you.",
        "Describe your city using at least three adjectives."
    )
    val prompt = prompts[studentLearningDate().dayOfYear % prompts.size]
    var answer by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf(false) }
    val sentenceCount = remember(answer) { answer.split(Regex("[.!?]+")).count { it.trim().isNotBlank() } }
    val wordCount = remember(answer) { answer.trim().split(Regex("\\s+")).count { it.isNotBlank() } }

    LazyColumn(Modifier.fillMaxSize().imePadding().navigationBarsPadding(), contentPadding = PaddingValues(14.dp,14.dp,14.dp,90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Writing Task", fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text(prompt, color = StudentBlue, fontWeight = FontWeight.Bold)
        }
        item {
            OutlinedTextField(
                value = answer,
                onValueChange = { answer = it.take(1800); checked = false },
                label = { Text("اكتب إجابتك بالإنجليزية") },
                minLines = 8,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Text("$wordCount كلمة • $sentenceCount جملة", color = StudentMuted)
            Button(onClick = { checked = true }, enabled = answer.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text("فحص سريع")
            }
        }
        if (checked) item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("مراجعة ذاتية", fontWeight = FontWeight.Black)
                    Text(if (wordCount >= 25) "✓ الطول مناسب" else "• حاول كتابة 25 كلمة على الأقل")
                    Text(if (sentenceCount >= 4) "✓ عدد الجمل مناسب" else "• أضف جمل أكثر")
                    Text(if (answer.firstOrNull()?.isUpperCase() == true) "✓ بدأت بحرف كبير" else "• ابدأ الجملة بحرف كبير")
                    Text(if (answer.trim().lastOrNull() in listOf('.', '!', '?')) "✓ علامة نهاية موجودة" else "• أضف علامة نهاية للجملة")
                }
            }
        }
    }
}

@Composable
private fun SpeakingSection(api: SupabaseApi, session: StudentSession) {
    val speech = rememberStudentSpeechController()
    val scope = rememberCoroutineScope()
    val tasks = listOf(
        "Introduce yourself in five sentences.",
        "Talk about your university or school.",
        "Describe what you did yesterday.",
        "Explain your plans for next weekend.",
        "Describe your favourite book, film, or game."
    )
    val task = tasks[studentLearningDate().dayOfYear % tasks.size]
    val model = when {
        task.startsWith("Introduce") -> "Hello. My name is ... I am from ... I study ... In my free time, I like ... My goal is to improve my English."
        task.startsWith("Talk") -> "I study at ... My favourite subject is ... I enjoy learning because ..."
        task.startsWith("Describe what") -> "Yesterday, I woke up at ... Then I ... In the evening, I ..."
        task.startsWith("Explain") -> "Next weekend, I am going to ... I hope to ... because ..."
        else -> "My favourite ... is ... I like it because ... I would recommend it to ..."
    }
    var transcript by remember { mutableStateOf("") }
    var confidence by remember { mutableStateOf<Float?>(null) }
    var analysis by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            transcript = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            confidence = result.data?.getFloatArrayExtra(RecognizerIntent.EXTRA_CONFIDENCE_SCORES)?.firstOrNull()?.takeIf { it >= 0f }
            analysis = null
        }
    }
    fun startRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak English")
        }
        runCatching { launcher.launch(intent) }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("AI Speaking Coach", fontSize = 23.sp, fontWeight = FontWeight.Black); Text(task, color = StudentBlue, fontWeight = FontWeight.Bold) }
        item { StudentOutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("نموذج مساعد", fontWeight = FontWeight.Black); Text(model)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { speech.speak(model, "american", "slow") }) { Text("US بطيء") }; OutlinedButton(onClick = { speech.speak(model, "british", "normal") }) { Text("UK") } }
        } } }
        item { Button(onClick = ::startRecognition, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Mic, null); Spacer(Modifier.width(6.dp)); Text("تحدث الآن") } }
        if (transcript.isNotBlank()) item { StudentOutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("ما التقطه Student", fontWeight = FontWeight.Black); Text(transcript)
            confidence?.let { Text("وضوح التعرف التقريبي: ${(it * 100).toInt()}%", color = StudentMuted) }
            Button(enabled = !busy, onClick = { scope.launch { busy = true; val prompt = "Act as an English speaking coach. The learner task is: $task\nSpeech transcript: $transcript\nGive concise feedback in Arabic with: fluency estimate, grammar corrections, better natural phrasing, and 3 words/phrases to practise. Do not claim you heard pronunciation because you only received a transcript."; analysis = withContext(Dispatchers.IO) { api.callStudentAi(session, "speaking_coach", prompt) }.getOrElse { it.message ?: "تعذر تحليل المحاولة." }; busy = false } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "جاري التحليل..." else "حلل محاولتي بالذكاء الاصطناعي") }
        } } }
        analysis?.let { a -> item { StudentOutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text("تقييم المدرب", fontWeight = FontWeight.Black); Text(a) } } } }
    }
}

@Composable
private fun CefrPlacementSection() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("student_cefr", Context.MODE_PRIVATE) }
    var level by remember { mutableStateOf(prefs.getString("level", "غير محدد").orEmpty()) }
    val qs = remember { listOf(
        Triple("I ___ a student.", listOf("am","is","are","be"), 0),
        Triple("She ___ English every day.", listOf("study","studies","studying","studied"), 1),
        Triple("Yesterday we ___ to the library.", listOf("go","went","gone","going"), 1),
        Triple("I have lived here ___ 2020.", listOf("for","since","from","at"), 1),
        Triple("If I had more time, I ___ more.", listOf("read","will read","would read","am reading"), 2),
        Triple("The report ___ before the meeting started.", listOf("completed","had been completed","has completed","was completing"), 1),
        Triple("Hardly ___ the room when the phone rang.", listOf("I left","had I left","I had left","did I leave"), 1),
        Triple("Her argument was both nuanced and ___.", listOf("compelling","compel","compelledly","compulsion"), 0)
    ) }
    var i by remember { mutableIntStateOf(0) }; var score by remember { mutableIntStateOf(0) }; var started by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CEFR Learning Path", fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text("Pre-A1 → A1 → A2 → B1 → B2 → C1 → C2", color = StudentBlue, fontWeight = FontWeight.Bold)
        Text("مستواك التقديري الحالي: $level", fontWeight = FontWeight.Bold)
        if (!started) {
            Text("اختبار تحديد مستوى أولي قصير. النتيجة تقديرية وليست شهادة CEFR رسمية.", color = StudentMuted)
            Button(onClick = { started = true; i = 0; score = 0 }, modifier = Modifier.fillMaxWidth()) { Text("ابدأ الاختبار") }
        } else if (i < qs.size) {
            val q=qs[i]; Text("${i+1}/${qs.size}  ${q.first}", fontWeight=FontWeight.Black)
            q.second.forEachIndexed { idx,opt -> OutlinedButton(onClick = { if(idx==q.third) score++; i++; if(i>=qs.size){ val final=score; level=when{final<=1->"A1";final<=2->"A2";final<=4->"B1";final<=5->"B2";final<=6->"C1";else->"C2"}; prefs.edit().putString("level",level).apply() } }, modifier=Modifier.fillMaxWidth()){Text(opt)} }
        } else {
            MasteryModeCard("تحديد المستوى $level")
            OutlinedButton(onClick={started=false},modifier=Modifier.fillMaxWidth()){Text("إعادة الاختبار") }
        }
    }
}

@Composable
private fun MasteryModeCard(section: String) {
    StudentOutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("اكتمل محتوى $section", fontWeight = FontWeight.Black, fontSize = 20.sp)
        Text("انتقلت الآن إلى وضع الإتقان: راجع الكلمات الصعبة، اختبر نفسك، وارجع إلى أخطائك السابقة بدل عرض صفحة فارغة.", color = StudentMuted)
        Text("المراجعة الذكية • اختبار شامل • تحديات • أخطاء سابقة • انتقال للمستوى التالي", color = StudentBlue, fontWeight = FontWeight.Bold)
    } }
}

@Composable
private fun EnglishProgressSection() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("student_english", Context.MODE_PRIVATE) }
    val reviewCount = remember { EnglishSeedContent.words.count { prefs.getBoolean("review_${it.id}", false) } }
    val day = studentLearningDate().dayOfMonth
    val completedDays = (day - 1).coerceAtLeast(0)
    LazyColumn(Modifier.fillMaxSize().imePadding().navigationBarsPadding(), contentPadding = PaddingValues(14.dp,14.dp,14.dp,90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("تقدمي", fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("ملخص سريع لمسارك الحالي", color = StudentMuted)
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StudentOutlinedCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("$reviewCount", fontSize = 26.sp, fontWeight = FontWeight.Black, color = StudentBlue)
                        Text("كلمات للمراجعة", fontSize = 12.sp, color = StudentMuted)
                    }
                }
                StudentOutlinedCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("$completedDays", fontSize = 26.sp, fontWeight = FontWeight.Black, color = StudentBlue)
                        Text("أيام هذا الشهر", fontSize = 12.sp, color = StudentMuted)
                    }
                }
            }
        }
        item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("خطة اليوم", fontWeight = FontWeight.Black)
                    Text("1. مفردات اليوم")
                    Text("2. درس قواعد أو Parts of Speech")
                    Text("3. استماع أو قراءة")
                    Text("4. مراجعة الكلمات المحفوظة")
                    Text("5. Daily Challenge")
                }
            }
        }
    }
}
