Student Native Core v0.1
========================

هذه أول نسخة Native بالكامل بدون WebView.

الموجود الآن:
- Kotlin + Jetpack Compose
- package: com.student.app
- Modular Gradle structure
- Supabase Auth مباشر: Login/Register
- حفظ واستعادة الجلسة
- جلب profiles من نفس قاعدة Student الحالية
- Home Native
- Profile Native أولي
- Bottom Navigation Native
- Firebase Messaging service + Android notification channel
- محاولة تسجيل FCM token في device_push_tokens كـ android-fcm

طريقة التشغيل:
1) افتح مجلد Student-Native-Core-v0.1 في AndroidIDE.
2) انتظر Gradle Sync لأول مرة.
3) Build > Assemble Debug.
4) ثبت APK وسجل دخول بحساب Student الحالي.

مهم:
Firebase Android App الرسمي لحزمة com.student.app يجب أن يكون مسجلاً داخل مشروع Firebase نفسه حتى يصبح Native FCM موثوقاً للإصدار النهائي. الكود موجود من الآن، ونثبت Firebase Android configuration النهائي ضمن مرحلة Native Core قبل Release.

المرحلة التالية بعد نجاح هذه النسخة:
Native Accounts v0.2
- الملف الشخصي الكامل
- تعديل الحساب
- المتابعة والخصوصية
- التوثيق
- الإطارات
- البحث عن المستخدمين
