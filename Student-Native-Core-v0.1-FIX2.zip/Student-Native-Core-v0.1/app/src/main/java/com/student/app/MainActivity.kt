package com.student.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import com.google.firebase.messaging.FirebaseMessaging
import com.student.core.data.*
import com.student.feature.auth.AuthScreen
import com.student.feature.home.HomeScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val api = SupabaseApi()
    private lateinit var store: SessionStore

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SessionStore(this)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { StudentRoot() }
            }
        }
    }

    @Composable
    private fun StudentRoot() {
        val scope = rememberCoroutineScope()
        var session by remember { mutableStateOf<StudentSession?>(store.load()) }
        var profile by remember { mutableStateOf<StudentProfile?>(null) }
        var busy by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }

        fun loadProfile(current: StudentSession) {
            scope.launch {
                busy = true
                val refreshed = withContext(Dispatchers.IO) {
                    val result = api.profile(current)
                    if (result.isFailure && current.refreshToken.isNotBlank()) {
                        api.refresh(current.refreshToken).getOrNull()?.let { fresh ->
                            store.save(fresh)
                            session = fresh
                            api.profile(fresh)
                        } ?: result
                    } else result
                }
                profile = refreshed.getOrNull()
                message = refreshed.exceptionOrNull()?.message
                busy = false
                registerPush(session ?: current)
            }
        }

        LaunchedEffect(session?.accessToken) {
            session?.let { loadProfile(it) }
        }

        if (session == null) {
            AuthScreen(
                busy = busy,
                message = message,
                onLogin = { email, password ->
                    scope.launch {
                        busy = true; message = null
                        val result = withContext(Dispatchers.IO) { api.login(email, password) }
                        result.onSuccess { store.save(it); session = it }
                            .onFailure { message = it.message ?: "تعذر تسجيل الدخول." }
                        busy = false
                    }
                },
                onRegister = { name, email, password ->
                    scope.launch {
                        busy = true; message = null
                        val result = withContext(Dispatchers.IO) { api.register(name, email, password) }
                        result.onSuccess { created ->
                            if (created == null) message = "تم إنشاء الحساب. أكّد البريد ثم سجّل الدخول."
                            else { store.save(created); session = created }
                        }.onFailure { message = it.message ?: "تعذر إنشاء الحساب." }
                        busy = false
                    }
                }
            )
        } else {
            HomeScreen(
                profile = profile,
                loading = busy,
                onRefresh = { session?.let { loadProfile(it) } },
                onLogout = {
                    store.clear(); profile = null; session = null; message = null
                }
            )
        }
    }

    private fun registerPush(session: StudentSession) {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            getSharedPreferences("student_push", MODE_PRIVATE).edit().putString("fcm_token", token).apply()
            Thread { api.registerPushToken(session, token) }.start()
        }
    }
}
