package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.StudentProfile

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(profile: StudentProfile?, loading: Boolean, onRefresh: () -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Student") },
                actions = { TextButton(onClick = onLogout) { Text("خروج") } }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("⌂") }, label = { Text("الرئيسية") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("◉") }, label = { Text("حسابي") })
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            if (loading) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            } else if (tab == 0) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("مرحبًا ${profile?.fullName ?: "بك"}", style = MaterialTheme.typography.headlineSmall)
                    Text("هذه أول واجهة Native حقيقية في Student. لا يوجد WebView في هذا المشروع.")
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("المرحلة الحالية", style = MaterialTheme.typography.titleMedium)
                            Text("Native Core: الحسابات + الجلسة + الرئيسية + الملف الشخصي")
                        }
                    }
                    Button(onClick = onRefresh) { Text("تحديث البيانات") }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(profile?.fullName ?: "مستخدم", style = MaterialTheme.typography.headlineSmall)
                    Text("@${profile?.username ?: "student"}")
                    Text(profile?.email.orEmpty())
                    if (!profile?.bio.isNullOrBlank()) Text(profile?.bio.orEmpty())
                    HorizontalDivider()
                    Text("الدور: ${profile?.role ?: "student"}")
                    Text("الحساب: ${profile?.accountStatus ?: "public"}")
                    profile?.profileFrameUrl?.let { Text("الإطار: $it") }
                }
            }
        }
    }
}
