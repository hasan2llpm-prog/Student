package com.student.core.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class SupabaseApi {
    private val client = OkHttpClient()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    fun login(email: String, password: String): Result<StudentSession> = runCatching {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .post(body.toRequestBody(jsonType))
            .build()
        executeAuth(request)
    }

    fun register(fullName: String, email: String, password: String): Result<StudentSession?> = runCatching {
        val body = JSONObject()
            .put("email", email)
            .put("password", password)
            .put("data", JSONObject().put("full_name", fullName))
            .toString()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/auth/v1/signup")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .post(body.toRequestBody(jsonType))
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(errorMessage(raw, response.code))
            val root = JSONObject(raw)
            if (!root.has("access_token")) null else sessionFrom(root)
        }
    }

    fun refresh(refreshToken: String): Result<StudentSession> = runCatching {
        val body = JSONObject().put("refresh_token", refreshToken).toString()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .post(body.toRequestBody(jsonType))
            .build()
        executeAuth(request)
    }

    fun profile(session: StudentSession): Result<StudentProfile> = runCatching {
        val url = "${StudentConfig.SUPABASE_URL}/rest/v1/profiles?id=eq.${session.userId}" +
            "&select=id,full_name,username,email,bio,avatar_url,role,account_status,profile_frame_url&limit=1"
        val request = Request.Builder()
            .url(url)
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .header("Authorization", "Bearer ${session.accessToken}")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(errorMessage(raw, response.code))
            val arr = JSONArray(raw)
            if (arr.length() == 0) throw IllegalStateException("تعذر العثور على ملف الحساب.")
            val o = arr.getJSONObject(0)
            StudentProfile(
                id = o.optString("id"),
                fullName = o.optString("full_name", "مستخدم"),
                username = o.optString("username", "student"),
                email = o.optString("email", session.email),
                bio = o.optString("bio", ""),
                avatarUrl = o.optString("avatar_url").takeIf { it.isNotBlank() && it != "null" },
                role = o.optString("role", "student"),
                accountStatus = o.optString("account_status", "public"),
                profileFrameUrl = o.optString("profile_frame_url").takeIf { it.isNotBlank() && it != "null" }
            )
        }
    }

    fun registerPushToken(session: StudentSession, token: String): Result<Unit> = runCatching {
        val body = JSONObject()
            .put("user_id", session.userId)
            .put("fcm_token", token)
            .put("platform", "android-fcm")
            .put("is_active", true)
            .toString()
        val request = Request.Builder()
            .url("${StudentConfig.SUPABASE_URL}/rest/v1/device_push_tokens?on_conflict=fcm_token")
            .header("apikey", StudentConfig.SUPABASE_KEY)
            .header("Authorization", "Bearer ${session.accessToken}")
            .header("Prefer", "resolution=merge-duplicates,return=minimal")
            .post(body.toRequestBody(jsonType))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val raw = response.body?.string().orEmpty()
                throw IllegalStateException(errorMessage(raw, response.code))
            }
        }
    }

    private fun executeAuth(request: Request): StudentSession {
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException(errorMessage(raw, response.code))
            return sessionFrom(JSONObject(raw))
        }
    }

    private fun sessionFrom(root: JSONObject): StudentSession {
        val user = root.optJSONObject("user") ?: throw IllegalStateException("بيانات المستخدم غير مكتملة.")
        return StudentSession(
            accessToken = root.getString("access_token"),
            refreshToken = root.getString("refresh_token"),
            userId = user.getString("id"),
            email = user.optString("email", "")
        )
    }

    private fun errorMessage(raw: String, code: Int): String {
        return try {
            val o = JSONObject(raw)
            o.optString("msg").ifBlank { o.optString("message") }.ifBlank { o.optString("error_description") }
                .ifBlank { "تعذر إكمال العملية ($code)." }
        } catch (_: Exception) {
            "تعذر إكمال العملية ($code)."
        }
    }
}
