package com.student.core.data

data class StudentSession(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String
)

data class StudentProfile(
    val id: String,
    val fullName: String,
    val username: String,
    val email: String,
    val bio: String,
    val avatarUrl: String?,
    val role: String,
    val accountStatus: String,
    val profileFrameUrl: String?
)
