-- Student v2.7.0 production migration
-- Rooms lifecycle, mutual-follow privacy, public-media moderation, verification sync.
begin;

-- ------------------------------------------------------------------
-- Verification is profile-authoritative and realtime.
-- ------------------------------------------------------------------
alter table public.profiles add column if not exists account_status text not null default 'public';
alter table public.profiles add column if not exists is_verified boolean not null default false;
alter table public.profiles add column if not exists verification_color text;

create or replace function public.student_admin_grant_verification_v27(p_user uuid, p_color text default 'blue')
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if not public.current_user_is_admin() then raise exception 'admin_required'; end if;
  if p_user is null then raise exception 'user_required'; end if;

  update public.profiles
     set is_verified=true,
         verification_color=case
           when lower(coalesce(role,''))='teacher' then 'red'
           when lower(coalesce(role,''))='admin' then 'orange'
           else coalesce(nullif(lower(trim(p_color)),''),'blue')
         end
   where id=p_user;
  if not found then raise exception 'profile_not_found'; end if;
end $$;
revoke all on function public.student_admin_grant_verification_v27(uuid,text) from public,anon;
grant execute on function public.student_admin_grant_verification_v27(uuid,text) to authenticated;

do $$
begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime')
     and not exists(
       select 1 from pg_publication_tables
       where pubname='supabase_realtime' and schemaname='public' and tablename='profiles'
     ) then
    execute 'alter publication supabase_realtime add table public.profiles';
  end if;
exception when others then
  raise notice 'profiles realtime publication unchanged: %', sqlerrm;
end $$;

-- ------------------------------------------------------------------
-- Private account visibility: only self or mutual followers.
-- RESTRICTIVE policies are ANDed with existing read policies.
-- ------------------------------------------------------------------
create or replace function public.student_can_view_owner_content_v27(p_owner uuid)
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select case
    when auth.uid() is null then false
    when p_owner=auth.uid() then true
    when coalesce((select lower(account_status) from public.profiles where id=p_owner),'public') <> 'private' then true
    else exists(
      select 1
      from public.follows a
      join public.follows b
        on b.follower_id=a.following_id and b.following_id=a.follower_id
      where a.follower_id=auth.uid()
        and a.following_id=p_owner
    )
  end
$$;

-- ------------------------------------------------------------------
-- Public-media moderation audit. Only the server function writes here.
-- ------------------------------------------------------------------
create table if not exists public.student_public_media_moderation_v27(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  media_url text not null,
  media_type text not null check(media_type in ('image','video')),
  status text not null check(status in ('approved','rejected','review')),
  reason text,
  provider text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists student_public_media_moderation_v27_lookup
  on public.student_public_media_moderation_v27(user_id,media_url,created_at desc);
alter table public.student_public_media_moderation_v27 enable row level security;
revoke all on public.student_public_media_moderation_v27 from anon,authenticated;
grant select,insert,update,delete on public.student_public_media_moderation_v27 to service_role;

alter table if exists public.posts add column if not exists moderation_status text not null default 'approved';
alter table if exists public.stories add column if not exists moderation_status text not null default 'approved';
alter table if exists public.reels add column if not exists moderation_status text not null default 'approved';

create or replace function public.student_require_public_media_approval_v27()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  uid uuid:=auth.uid();
  url text;
  st text;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if new.user_id <> uid then raise exception 'owner_mismatch'; end if;

  if tg_table_name='reels' then
    url:=nullif(trim(coalesce(new.video_url,'')),'');
  else
    url:=nullif(trim(coalesce(new.media_url,'')),'');
  end if;

  if url is null then
    new.moderation_status:='approved';
    return new;
  end if;

  select m.status into st
  from public.student_public_media_moderation_v27 m
  where m.user_id=uid and m.media_url=url
    and m.created_at >= now()-interval '60 minutes'
  order by m.created_at desc
  limit 1;

  if st='approved' then
    new.moderation_status:='approved';
    return new;
  elsif st='rejected' then
    raise exception 'public_media_rejected';
  else
    raise exception 'public_media_review_required';
  end if;
end $$;

-- Attach moderation enforcement only when the tables exist.
do $$
begin
  if to_regclass('public.posts') is not null then
    execute 'drop trigger if exists trg_student_posts_moderation_v27 on public.posts';
    execute 'create trigger trg_student_posts_moderation_v27 before insert or update of media_url on public.posts for each row execute function public.student_require_public_media_approval_v27()';
    execute 'drop policy if exists student_posts_privacy_guard_v27 on public.posts';
    execute 'create policy student_posts_privacy_guard_v27 on public.posts as restrictive for select to authenticated using (public.student_can_view_owner_content_v27(user_id) and moderation_status=''approved'')';
  end if;
  if to_regclass('public.stories') is not null then
    execute 'drop trigger if exists trg_student_stories_moderation_v27 on public.stories';
    execute 'create trigger trg_student_stories_moderation_v27 before insert or update of media_url on public.stories for each row execute function public.student_require_public_media_approval_v27()';
    execute 'drop policy if exists student_stories_privacy_guard_v27 on public.stories';
    execute 'create policy student_stories_privacy_guard_v27 on public.stories as restrictive for select to authenticated using (public.student_can_view_owner_content_v27(user_id) and moderation_status=''approved'')';
  end if;
  if to_regclass('public.reels') is not null then
    execute 'drop trigger if exists trg_student_reels_moderation_v27 on public.reels';
    execute 'create trigger trg_student_reels_moderation_v27 before insert or update of video_url on public.reels for each row execute function public.student_require_public_media_approval_v27()';
    execute 'drop policy if exists student_reels_privacy_guard_v27 on public.reels';
    execute 'create policy student_reels_privacy_guard_v27 on public.reels as restrictive for select to authenticated using (public.student_can_view_owner_content_v27(user_id) and moderation_status=''approved'')';
  end if;
end $$;

-- ------------------------------------------------------------------
-- Voice room leave v27: always releases the microphone immediately.
-- Owners remain members but never keep a ghost speaker seat.
-- ------------------------------------------------------------------
create or replace function public.student_voice_room_leave_v27(p_room_id uuid)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare uid uuid:=auth.uid(); owner_row boolean:=false;
begin
  if uid is null then return; end if;
  select exists(
    select 1 from public.student_voice_room_members
    where room_id=p_room_id and user_id=uid and room_role='owner'
  ) into owner_row;

  update public.student_voice_room_members
     set mic_state='listener', mic_slot=null
   where room_id=p_room_id and user_id=uid;

  if not owner_row then
    delete from public.student_voice_room_members
     where room_id=p_room_id and user_id=uid;
  end if;
end $$;
revoke all on function public.student_voice_room_leave_v27(uuid) from public,anon;
grant execute on function public.student_voice_room_leave_v27(uuid) to authenticated;

-- Server automation privileges used by the signed GitHub release workflow.
grant usage on schema public to service_role;
grant select,insert,update,delete on public.student_runtime_settings to service_role;
grant select,insert,update,delete on public.notifications to service_role;

commit;
