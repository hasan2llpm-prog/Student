package com.student.core.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class OfflineStore(context: Context) {
    private val prefs = context.getSharedPreferences("student_native_offline", Context.MODE_PRIVATE)

    fun saveProfile(profile: StudentProfile) {
        val o = JSONObject()
            .put("id", profile.id)
            .put("full_name", profile.fullName)
            .put("username", profile.username)
            .put("email", profile.email)
            .put("bio", profile.bio)
            .put("avatar_url", profile.avatarUrl ?: JSONObject.NULL)
            .put("role", profile.role)
            .put("account_status", profile.accountStatus)
            .put("profile_frame_url", profile.profileFrameUrl ?: JSONObject.NULL)
            .put("is_verified", profile.isVerified)
            .put("verification_color", profile.verificationColor ?: JSONObject.NULL)
            .put("custom_badge_label", profile.customBadgeLabel ?: JSONObject.NULL)
            .put("custom_badge_color", profile.customBadgeColor ?: JSONObject.NULL)
            .put("created_at", profile.createdAt ?: JSONObject.NULL)
        prefs.edit().putString("profile", o.toString()).apply()
    }

    fun loadProfile(): StudentProfile? = runCatching {
        val o = JSONObject(prefs.getString("profile", null) ?: return null)
        StudentProfile(
            id = o.optString("id"),
            fullName = o.optString("full_name", "مستخدم"),
            username = o.optString("username", "student"),
            email = o.optString("email", ""),
            bio = o.optString("bio", ""),
            avatarUrl = strOrNull(o, "avatar_url"),
            role = o.optString("role", "student"),
            accountStatus = o.optString("account_status", "public"),
            profileFrameUrl = strOrNull(o, "profile_frame_url"),
            isVerified = o.optBoolean("is_verified", false),
            verificationColor = strOrNull(o, "verification_color"),
            customBadgeLabel = strOrNull(o, "custom_badge_label"),
            customBadgeColor = strOrNull(o, "custom_badge_color"),
            createdAt = strOrNull(o, "created_at")
        )
    }.getOrNull()

    fun savePosts(items: List<PostItem>) {
        val a = JSONArray()
        items.forEach { p ->
            a.put(JSONObject()
                .put("id", p.id).put("user_id", p.userId).put("post_type", p.postType)
                .put("content", p.content).put("media_url", p.mediaUrl ?: JSONObject.NULL)
                .put("created_at", p.createdAt).put("author_name", p.authorName).put("author_username", p.authorUsername))
        }
        prefs.edit().putString("posts", a.toString()).apply()
    }

    fun loadPosts(): List<PostItem> = runCatching {
        val a = JSONArray(prefs.getString("posts", "[]"))
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(PostItem(o.optString("id"), o.optString("user_id"), o.optString("post_type", "text"), o.optString("content"), strOrNull(o,"media_url"), o.optString("created_at"), o.optString("author_name","مستخدم"), o.optString("author_username","student")))
            }
        }
    }.getOrDefault(emptyList())

    fun saveStories(items: List<StoryItem>) {
        val a = JSONArray()
        items.forEach { s ->
            a.put(JSONObject().put("id",s.id).put("user_id",s.userId).put("type",s.type).put("content",s.content)
                .put("media_url",s.mediaUrl ?: JSONObject.NULL).put("created_at",s.createdAt).put("expires_at",s.expiresAt ?: JSONObject.NULL).put("author_name",s.authorName))
        }
        prefs.edit().putString("stories", a.toString()).apply()
    }

    fun loadStories(): List<StoryItem> = runCatching {
        val a = JSONArray(prefs.getString("stories", "[]"))
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(StoryItem(o.optString("id"), o.optString("user_id"), o.optString("type","text"), o.optString("content"), strOrNull(o,"media_url"), o.optString("created_at"), strOrNull(o,"expires_at"), o.optString("author_name","مستخدم")))
            }
        }
    }.getOrDefault(emptyList())

    fun saveNotifications(items: List<StudentNotification>) {
        val a = JSONArray()
        items.forEach { n -> a.put(JSONObject().put("id",n.id).put("title",n.title).put("body",n.body).put("kind",n.kind).put("created_at",n.createdAt).put("is_read",n.isRead)) }
        prefs.edit().putString("notifications",a.toString()).apply()
    }

    fun loadNotifications(): List<StudentNotification> = runCatching {
        val a = JSONArray(prefs.getString("notifications", "[]"))
        buildList {
            for (i in 0 until a.length()) {
                val o=a.getJSONObject(i)
                add(StudentNotification(o.optString("id"),o.optString("title","Student"),o.optString("body"),o.optString("kind","general"),o.optString("created_at"),o.optBoolean("is_read",false)))
            }
        }
    }.getOrDefault(emptyList())

    fun saveProducts(items: List<StoreProduct>) {
        val a=JSONArray()
        items.forEach { p -> a.put(JSONObject().put("id",p.id).put("name",p.name).put("description",p.description).put("product_type",p.productType)
            .put("price_money",p.priceMoney).put("currency",p.currency).put("price_diamonds",p.priceDiamonds).put("allow_money",p.allowMoney).put("allow_diamonds",p.allowDiamonds).put("image_url",p.imageUrl ?: JSONObject.NULL)) }
        prefs.edit().putString("products",a.toString()).apply()
    }

    fun loadProducts(): List<StoreProduct> = runCatching {
        val a=JSONArray(prefs.getString("products","[]"))
        buildList {
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                add(StoreProduct(o.optString("id"),o.optString("name","منتج"),o.optString("description"),o.optString("product_type","product"),o.optDouble("price_money",0.0),o.optString("currency","IQD"),o.optInt("price_diamonds",0),o.optBoolean("allow_money",true),o.optBoolean("allow_diamonds",false),strOrNull(o,"image_url")))
            }
        }
    }.getOrDefault(emptyList())


    data class PendingAction(val id: String, val type: String, val data: JSONObject)

    fun enqueue(type: String, data: JSONObject) {
        val a = runCatching { JSONArray(prefs.getString("pending_actions", "[]")) }.getOrDefault(JSONArray())
        a.put(JSONObject().put("id", System.currentTimeMillis().toString() + "-" + a.length()).put("type", type).put("data", data))
        prefs.edit().putString("pending_actions", a.toString()).apply()
    }

    fun pendingActions(): List<PendingAction> = runCatching {
        val a = JSONArray(prefs.getString("pending_actions", "[]"))
        buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(PendingAction(o.optString("id"), o.optString("type"), o.optJSONObject("data") ?: JSONObject()))
            }
        }
    }.getOrDefault(emptyList())

    fun removePending(id: String) {
        val remaining = pendingActions().filterNot { it.id == id }
        val a = JSONArray()
        remaining.forEach { a.put(JSONObject().put("id", it.id).put("type", it.type).put("data", it.data)) }
        prefs.edit().putString("pending_actions", a.toString()).apply()
    }

    fun pendingCount(): Int = pendingActions().size

    fun flushPending(api: SupabaseApi, session: StudentSession): Int {
        var sent = 0
        pendingActions().forEach { action ->
            val result = when (action.type) {
                "post_text" -> api.createPost(session, action.data.optString("content"))
                "story_text" -> api.createTextStory(session, action.data.optString("content"))
                "message_text" -> api.sendMessage(session, action.data.optString("conversation_id"), action.data.optString("body"))
                "comment_text" -> api.addComment(session, action.data.optString("post_id"), action.data.optString("content"))
                else -> Result.failure(IllegalArgumentException("Unknown pending action"))
            }
            if (result.isSuccess) { removePending(action.id); sent++ }
        }
        return sent
    }

    fun clear() = prefs.edit().clear().apply()

    private fun strOrNull(o: JSONObject, key: String): String? = if (!o.has(key) || o.isNull(key)) null else o.optString(key).takeIf { it.isNotBlank() && it != "null" }
}
