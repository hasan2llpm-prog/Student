package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AdminScreen(api: SupabaseApi, session: StudentSession, profile: StudentProfile?) {
    val scope = rememberCoroutineScope()
    var allowed by remember { mutableStateOf(profile?.role.equals("admin", true)) }
    var checked by remember { mutableStateOf(false) }
    var users by remember { mutableStateOf<List<AdminRecentUser>>(emptyList()) }
    var flags by remember { mutableStateOf<List<FeatureFlag>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<AdminRecentUser?>(null) }
    var broadcastTitle by remember { mutableStateOf("") }
    var broadcastBody by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch {
            loading = true
            val adminResult = withContext(Dispatchers.IO) { api.isAdmin(session) }
            allowed = adminResult.getOrDefault(profile?.role.equals("admin", true))
            checked = true
            if (allowed) {
                val result = withContext(Dispatchers.IO) { api.adminRecentUsers(session) to api.featureFlags(session) }
                result.first.onSuccess { users = it }.onFailure { message = it.message }
                result.second.onSuccess { flags = it }
            }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    selected?.let { user ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(user.fullName) },
            text = { Text("@${user.username}\n${user.email}\nالدور: ${user.role}") },
            confirmButton = {
                Button(onClick = {
                    scope.launch {
                        loading = true
                        val color = when (user.role.lowercase()) { "admin" -> "orange"; "teacher" -> "red"; else -> "blue" }
                        val r = withContext(Dispatchers.IO) { api.grantVerification(session, user.id, color) }
                        loading = false
                        r.onSuccess { message = "تم إرسال التوثيق كهدية للمستخدم."; selected = null; refresh() }
                            .onFailure { message = it.message }
                    }
                }) { Text("منح التوثيق") }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("إغلاق") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (checked && !allowed) {
            Text("هذه الصفحة متاحة لحساب الأدمن فقط.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.error)
            return@Column
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("لوحة الإدارة", style = MaterialTheme.typography.headlineSmall); Text("إدارة Student Native", style = MaterialTheme.typography.bodySmall) }
            TextButton(onClick = { refresh() }) { Text("تحديث") }
        }
        message?.let { Text(it, Modifier.padding(horizontal = 12.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.primary) }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("المستخدمون") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("الميزات") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("بث") })
        }
        when (tab) {
            0 -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(users, key = { it.id }) { user ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(user.fullName + if (user.isVerified) " ✓" else "", style = MaterialTheme.typography.titleMedium)
                            Text("@${user.username} · ${user.role}")
                            Text(user.email, style = MaterialTheme.typography.bodySmall)
                            Text(prettyTime(user.createdAt), style = MaterialTheme.typography.labelSmall)
                            TextButton(onClick = { selected = user }) { Text("إدارة الحساب") }
                        }
                    }
                }
            }
            1 -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(flags, key = { it.id.ifBlank { it.key } }) { flag ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) { Text(flag.name, style = MaterialTheme.typography.titleMedium); Text(flag.key, style = MaterialTheme.typography.bodySmall) }
                            Switch(checked = flag.enabled, onCheckedChange = { enabled ->
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { api.updateFeatureFlag(session, flag.id, enabled) }
                                    r.onSuccess { flags = flags.map { if (it.id == flag.id) it.copy(enabled = enabled) else it }; message = "تم تحديث الميزة." }
                                        .onFailure { message = it.message }
                                }
                            })
                        }
                    }
                }
            }
            else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("نشر إشعار للجميع", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(broadcastTitle, { broadcastTitle = it }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(broadcastBody, { broadcastBody = it }, label = { Text("النص") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.adminBroadcast(session, broadcastTitle.trim(), broadcastBody.trim()) }
                            loading = false
                            r.onSuccess { message = "تم نشر الإشعار للجميع."; broadcastTitle = ""; broadcastBody = "" }
                                .onFailure { message = it.message }
                        }
                    },
                    enabled = !loading && broadcastTitle.isNotBlank() && broadcastBody.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("نشر الآن") }
            }
        }
    }
}
