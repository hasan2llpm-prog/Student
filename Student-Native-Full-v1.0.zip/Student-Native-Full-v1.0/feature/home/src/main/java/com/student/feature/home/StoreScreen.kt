package com.student.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StoreScreen(api: SupabaseApi, session: StudentSession) {
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf(offline.loadProducts()) }
    var wallet by remember { mutableStateOf(WalletSummary()) }
    var orders by remember { mutableStateOf<List<StoreOrder>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<StoreProduct?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            busy = true
            val triple = withContext(Dispatchers.IO) {
                Triple(api.storeProducts(session), api.walletSummary(session), api.storeOrders(session))
            }
            triple.first.onSuccess { products = it; offline.saveProducts(it) }.onFailure { if (products.isEmpty()) message = it.message }
            triple.second.onSuccess { wallet = it }
            triple.third.onSuccess { orders = it }
            busy = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    selected?.let { p ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(p.name) },
            text = { Text(p.description.ifBlank { "اختر طريقة الدفع" }) },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (p.allowDiamonds) TextButton(onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.createStoreOrder(session, p.id, "diamonds") }
                            busy = false
                            r.onSuccess { message = "تم إنشاء الطلب بالألماس."; selected = null; refresh() }.onFailure { message = it.message }
                        }
                    }) { Text("${p.priceDiamonds} 💎") }
                    if (p.allowMoney) Button(onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.createStoreOrder(session, p.id, "money") }
                            busy = false
                            r.onSuccess { message = "تم إنشاء طلب الدفع المالي. أكمل إثبات الدفع حسب تعليمات المتجر."; selected = null; refresh() }.onFailure { message = it.message }
                        }
                    }) { Text("${p.priceMoney.toLong()} ${p.currency}") }
                }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("إلغاء") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Surface(color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("المحفظة", style = MaterialTheme.typography.titleMedium)
                Text("المتاح: ${wallet.availableBalance.toLong()} · محجوز: ${wallet.heldBalance.toLong()} · المصروف: ${wallet.totalSpent.toLong()}")
                Text("الألماس: ${wallet.diamonds} 💎")
            }
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("المنتجات") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("طلباتي") })
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary) }
        if (tab == 0) {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(products, key = { it.id }) { p ->
                    ElevatedCard(Modifier.fillMaxWidth().clickable { selected = p }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            if (p.description.isNotBlank()) Text(p.description, maxLines = 3)
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                if (p.allowMoney) Text("${p.priceMoney.toLong()} ${p.currency}")
                                if (p.allowDiamonds) Text("${p.priceDiamonds} 💎")
                            }
                            Text("النوع: ${p.productType}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(orders, key = { it.id }) { o ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(o.productName, style = MaterialTheme.typography.titleMedium)
                            Text("الحالة: ${o.status}")
                            Text("الدفع: ${o.paymentMethod}")
                            Text(prettyTime(o.createdAt), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                if (orders.isEmpty() && !busy) item { Text("لا توجد طلبات.") }
            }
        }
    }
}
