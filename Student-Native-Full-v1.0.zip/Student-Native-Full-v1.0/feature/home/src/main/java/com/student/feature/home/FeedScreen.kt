package com.student.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FeedScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    onOpenStories: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf(offline.loadPosts()) }
    var stories by remember { mutableStateOf(offline.loadStories()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            message = null
            val result = withContext(Dispatchers.IO) {
                api.feed(session) to api.stories(session)
            }
            result.first.onSuccess { fresh -> posts = fresh; offline.savePosts(fresh) }
                .onFailure { if (posts.isEmpty()) message = it.message ?: "تعذر تحميل المنشورات." }
            result.second.onSuccess { fresh -> stories = fresh; offline.saveStories(fresh) }
            loading = false
        }
    }

    LaunchedEffect(session.userId) { refresh() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text("مرحبًا ${profile?.fullName ?: "بك"}", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.clickable(onClick = onOpenProfile))
                Text("منصة Student", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("القصص", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onOpenStories) { Text("عرض الكل") }
            }
            if (stories.isEmpty()) {
                Text("لا توجد قصص حاليًا.", Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            } else {
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(stories.take(15), key = { it.id }) { story ->
                        ElevatedCard(modifier = Modifier.width(120.dp).clickable(onClick = onOpenStories)) {
                            Column(Modifier.padding(10.dp)) {
                                Text(story.authorName, maxLines = 1, style = MaterialTheme.typography.labelLarge)
                                Spacer(Modifier.height(5.dp))
                                Text(if (story.type == "text") story.content.take(45) else "${story.type} story", maxLines = 2, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(top = 12.dp))
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("آخر المنشورات", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { refresh() }, enabled = !loading) { Text(if (loading) "..." else "تحديث") }
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
        }
        if (posts.isEmpty() && !loading) {
            item { Text("لا توجد منشورات بعد.", Modifier.padding(18.dp)) }
        }
        items(posts, key = { it.id }) { post -> PostCard(api, session, post) }
    }
}

@Composable
private fun PostCard(api: SupabaseApi, session: StudentSession, post: PostItem) {
    val uriHandler = LocalUriHandler.current
    val scope = rememberCoroutineScope()
    var savedMessage by remember { mutableStateOf<String?>(null) }
    var liked by remember { mutableStateOf(false) }
    var showComments by remember { mutableStateOf(false) }
    var comments by remember { mutableStateOf<List<CommentItem>>(emptyList()) }
    var commentText by remember { mutableStateOf("") }

    LaunchedEffect(post.id) {
        liked = withContext(Dispatchers.IO) { api.isPostLiked(session, post.id).getOrDefault(false) }
    }

    if (showComments) {
        AlertDialog(
            onDismissRequest = { showComments = false },
            title = { Text("التعليقات") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (comments.isEmpty()) Text("لا توجد تعليقات بعد.")
                    comments.takeLast(8).forEach { c -> Text("${c.authorName}: ${c.content}", style = MaterialTheme.typography.bodyMedium) }
                    OutlinedTextField(commentText, { commentText = it }, label = { Text("أضف تعليقًا") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    val body = commentText.trim()
                    if (body.isBlank()) return@Button
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { api.addComment(session, post.id, body) }
                        r.onSuccess {
                            commentText = ""
                            comments = withContext(Dispatchers.IO) { api.comments(session, post.id).getOrDefault(comments) }
                        }
                    }
                }) { Text("إرسال") }
            },
            dismissButton = { TextButton(onClick = { showComments = false }) { Text("إغلاق") } }
        )
    }
    ElevatedCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(post.authorName, style = MaterialTheme.typography.titleMedium)
            Text("@${post.authorUsername}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            if (post.content.isNotBlank()) Text(post.content, style = MaterialTheme.typography.bodyLarge)
            post.mediaUrl?.let { url ->
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { runCatching { uriHandler.openUri(url) } }) { Text("فتح الوسائط") }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = {
                    scope.launch {
                        val next = !liked
                        val r = withContext(Dispatchers.IO) { api.setPostLiked(session, post.id, next) }
                        if (r.isSuccess) liked = next
                    }
                }) { Text(if (liked) "♥ أعجبني" else "♡ إعجاب") }
                TextButton(onClick = {
                    scope.launch {
                        comments = withContext(Dispatchers.IO) { api.comments(session, post.id).getOrDefault(emptyList()) }
                        showComments = true
                    }
                }) { Text("تعليقات") }
                TextButton(onClick = {
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { api.saveItem(session, "post", post.id) }
                        savedMessage = if (r.isSuccess) "تم الحفظ" else if ((r.exceptionOrNull()?.message ?: "").contains("duplicate", true)) "محفوظ" else "تعذر الحفظ"
                    }
                }) { Text("☆ حفظ") }
            }
            Text(prettyTime(post.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            savedMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
        }
    }
}

internal fun prettyTime(raw: String): String {
    if (raw.isBlank()) return ""
    return raw.replace("T", " ").take(16)
}
