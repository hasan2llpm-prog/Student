package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ProfileScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    loadingProfile: Boolean,
    onProfileChanged: (StudentProfile) -> Unit,
    onRefreshProfile: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("public") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var stats by remember { mutableStateOf(ProfileStats()) }

    LaunchedEffect(profile?.id, profile?.fullName, profile?.username, profile?.bio, profile?.accountStatus) {
        profile?.let {
            fullName = it.fullName
            username = it.username
            bio = it.bio
            status = it.accountStatus
            val r = withContext(Dispatchers.IO) { api.profileStats(session, it.id) }
            r.onSuccess { value -> stats = value }
        }
    }

    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (loadingProfile || profile == null) {
            CircularProgressIndicator()
            Text("جارٍ تحميل الملف الشخصي...")
            return@Column
        }
        Text(profile.fullName + if (profile.isVerified) " ✓" else "", style = MaterialTheme.typography.headlineSmall)
        Text("@${profile.username}")
        Text(profile.email, style = MaterialTheme.typography.bodySmall)
        Text("الدور: ${profile.role}")
        Text("الحساب: ${profile.accountStatus}")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Text("${stats.posts} منشور")
            Text("${stats.followers} متابع")
            Text("${stats.following} يتابع")
        }
        profile.verificationColor?.let { Text("التوثيق: $it") }
        profile.customBadgeLabel?.let { Text("العلامة: $it") }
        profile.profileFrameUrl?.let { Text("إطار الحساب مفعّل") }
        if (profile.bio.isNotBlank()) Text(profile.bio)
        HorizontalDivider()

        if (!editing) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { editing = true }) { Text("تعديل الملف") }
                OutlinedButton(onClick = onRefreshProfile) { Text("تحديث") }
            }
        } else {
            OutlinedTextField(fullName, { fullName = it }, label = { Text("الاسم الكامل") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(username, { username = it }, label = { Text("اسم المستخدم") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(bio, { bio = it }, label = { Text("النبذة") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = status == "public", onClick = { status = "public" }, label = { Text("عام") })
                FilterChip(selected = status == "private", onClick = { status = "private" }, label = { Text("خاص") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    scope.launch {
                        busy = true; message = null
                        val r = withContext(Dispatchers.IO) { api.updateProfile(session, fullName.trim(), username.trim(), bio.trim(), status) }
                        if (r.isSuccess) {
                            val fresh = withContext(Dispatchers.IO) { api.profile(session) }
                            fresh.onSuccess { onProfileChanged(it); editing = false; message = "تم حفظ التعديلات." }
                                .onFailure { message = it.message }
                        } else message = r.exceptionOrNull()?.message
                        busy = false
                    }
                }, enabled = !busy && fullName.isNotBlank() && username.isNotBlank()) { Text(if (busy) "جارٍ الحفظ..." else "حفظ") }
                TextButton(onClick = { editing = false }) { Text("إلغاء") }
            }
        }
        message?.let { Text(it, color = if (it.startsWith("تم")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
    }
}
