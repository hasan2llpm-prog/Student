package com.student.feature.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.*

enum class StudentRoute {
    HOME, SEARCH, CREATE, SAVED, MENU,
    PROFILE, MESSAGES, NOTIFICATIONS, EDUCATION, STORE, ADMIN, SETTINGS, STORIES
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    loadingProfile: Boolean,
    offlineMode: Boolean,
    rootMessage: String?,
    onProfileChanged: (StudentProfile) -> Unit,
    onRefreshProfile: () -> Unit,
    onLogout: () -> Unit
) {
    var route by remember { mutableStateOf(StudentRoute.HOME) }
    BackHandler(enabled = route != StudentRoute.HOME) { route = StudentRoute.HOME }

    val title = when (route) {
        StudentRoute.HOME -> "Student"
        StudentRoute.SEARCH -> "البحث"
        StudentRoute.CREATE -> "إضافة"
        StudentRoute.SAVED -> "المحفوظات"
        StudentRoute.MENU -> "القائمة"
        StudentRoute.PROFILE -> "الملف الشخصي"
        StudentRoute.MESSAGES -> "الرسائل"
        StudentRoute.NOTIFICATIONS -> "الإشعارات"
        StudentRoute.EDUCATION -> "التعليم"
        StudentRoute.STORE -> "المتجر"
        StudentRoute.ADMIN -> "الإدارة"
        StudentRoute.SETTINGS -> "الإعدادات"
        StudentRoute.STORIES -> "القصص"
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (route !in listOf(StudentRoute.HOME, StudentRoute.SEARCH, StudentRoute.CREATE, StudentRoute.SAVED, StudentRoute.MENU)) {
                        TextButton(onClick = { route = StudentRoute.HOME }) { Text("‹ رجوع") }
                    } else {
                        TextButton(onClick = { route = StudentRoute.NOTIFICATIONS }) { Text("🔔") }
                    }
                },
                actions = {
                    TextButton(onClick = { route = StudentRoute.MESSAGES }) { Text("✉") }
                    TextButton(onClick = { route = StudentRoute.MENU }) { Text("☰") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                BottomItem("⌂", "الرئيسية", route == StudentRoute.HOME) { route = StudentRoute.HOME }
                BottomItem("⌕", "البحث", route == StudentRoute.SEARCH) { route = StudentRoute.SEARCH }
                BottomItem("＋", "إضافة", route == StudentRoute.CREATE) { route = StudentRoute.CREATE }
                BottomItem("★", "المحفوظات", route == StudentRoute.SAVED) { route = StudentRoute.SAVED }
                BottomItem("☰", "القائمة", route == StudentRoute.MENU) { route = StudentRoute.MENU }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (offlineMode) {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                    Text("وضع Offline — يتم عرض آخر بيانات محفوظة", Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                }
            }
            rootMessage?.takeIf { it.isNotBlank() && !offlineMode }?.let {
                Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                    Text(it, Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
                }
            }
            Box(Modifier.fillMaxSize()) {
                when (route) {
                    StudentRoute.HOME -> FeedScreen(api, session, profile, onOpenStories = { route = StudentRoute.STORIES }, onOpenProfile = { route = StudentRoute.PROFILE })
                    StudentRoute.SEARCH -> SearchScreen(api, session, onOpenMessages = { route = StudentRoute.MESSAGES })
                    StudentRoute.CREATE -> CreateScreen(api, session, onDone = { route = StudentRoute.HOME })
                    StudentRoute.SAVED -> SavedScreen(api, session)
                    StudentRoute.MENU -> MenuScreen(
                        profile = profile,
                        onProfile = { route = StudentRoute.PROFILE },
                        onMessages = { route = StudentRoute.MESSAGES },
                        onEducation = { route = StudentRoute.EDUCATION },
                        onStore = { route = StudentRoute.STORE },
                        onNotifications = { route = StudentRoute.NOTIFICATIONS },
                        onAdmin = { route = StudentRoute.ADMIN },
                        onSettings = { route = StudentRoute.SETTINGS },
                        onLogout = onLogout
                    )
                    StudentRoute.PROFILE -> ProfileScreen(api, session, profile, loadingProfile, onProfileChanged, onRefreshProfile)
                    StudentRoute.MESSAGES -> MessagesScreen(api, session)
                    StudentRoute.NOTIFICATIONS -> NotificationsScreen(api, session)
                    StudentRoute.EDUCATION -> EducationScreen(api, session)
                    StudentRoute.STORE -> StoreScreen(api, session)
                    StudentRoute.ADMIN -> AdminScreen(api, session, profile)
                    StudentRoute.SETTINGS -> SettingsScreen(profile, offlineMode, onRefreshProfile, onLogout)
                    StudentRoute.STORIES -> StoriesScreen(api, session)
                }
            }
        }
    }
}

@Composable
private fun RowScope.BottomItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Text(icon) },
        label = { Text(label, maxLines = 1) }
    )
}
