package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StoriesScreen(api: SupabaseApi, session: StudentSession) {
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    val uri = LocalUriHandler.current
    val scope = rememberCoroutineScope()
    var stories by remember { mutableStateOf(offline.loadStories()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            val r = withContext(Dispatchers.IO) { api.stories(session, 80) }
            r.onSuccess { stories = it; offline.saveStories(it) }.onFailure { message = it.message }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("القصص", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = { refresh() }) { Text("تحديث") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(stories, key = { it.id }) { s ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(s.authorName, style = MaterialTheme.typography.titleMedium)
                        if (s.content.isNotBlank()) Text(s.content)
                        s.mediaUrl?.let { url -> OutlinedButton(onClick = { runCatching { uri.openUri(url) } }) { Text("فتح ${s.type}") } }
                        Text(prettyTime(s.createdAt), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
