package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SearchScreen(api: SupabaseApi, session: StudentSession, onOpenMessages: () -> Unit) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ProfileSearchItem>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun search() {
        if (query.isBlank()) return
        scope.launch {
            busy = true; message = null
            val r = withContext(Dispatchers.IO) { api.searchProfiles(session, query) }
            r.onSuccess { results = it }.onFailure { message = it.message }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("الاسم أو اسم المستخدم") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { search() }, enabled = !busy && query.isNotBlank()) { Text("بحث") }
        }
        message?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 14.dp)) }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results, key = { it.id }) { item ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(item.fullName + if (item.isVerified) " ✓" else "", style = MaterialTheme.typography.titleMedium)
                            Text("@${item.username} · ${item.role}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (item.id != session.userId) {
                            Column {
                                TextButton(onClick = {
                                    scope.launch {
                                        busy = true
                                        val r = withContext(Dispatchers.IO) { api.startDirectChat(session, item.id) }
                                        busy = false
                                        r.onSuccess { onOpenMessages() }.onFailure { message = it.message }
                                    }
                                }) { Text("مراسلة") }
                                TextButton(onClick = {
                                    scope.launch {
                                        val r = withContext(Dispatchers.IO) {
                                            val following = api.isFollowing(session, item.id).getOrDefault(false)
                                            api.setFollowing(session, item.id, !following).map { !following }
                                        }
                                        r.onSuccess { now -> message = if (now) "تمت المتابعة." else "تم إلغاء المتابعة." }
                                            .onFailure { message = it.message }
                                    }
                                }) { Text("متابعة") }
                            }
                        }
                    }
                }
            }
        }
    }
}
