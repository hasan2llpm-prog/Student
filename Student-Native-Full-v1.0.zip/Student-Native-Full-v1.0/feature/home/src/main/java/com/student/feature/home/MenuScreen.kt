package com.student.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.StudentProfile

@Composable
fun MenuScreen(
    profile: StudentProfile?,
    onProfile: () -> Unit,
    onMessages: () -> Unit,
    onEducation: () -> Unit,
    onStore: () -> Unit,
    onNotifications: () -> Unit,
    onAdmin: () -> Unit,
    onSettings: () -> Unit,
    onLogout: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            ElevatedCard(Modifier.fillMaxWidth().clickable(onClick = onProfile)) {
                Column(Modifier.padding(18.dp)) {
                    Text(profile?.fullName ?: "مستخدم", style = MaterialTheme.typography.titleLarge)
                    Text("@${profile?.username ?: "student"}")
                    Text("الملف الشخصي")
                }
            }
        }
        item { MenuEntry("✉", "الرسائل", onMessages) }
        item { MenuEntry("🎓", "التعليم", onEducation) }
        item { MenuEntry("🛍", "المتجر والمحفظة", onStore) }
        item { MenuEntry("🔔", "الإشعارات", onNotifications) }
        if (profile?.role.equals("admin", true)) item { MenuEntry("⚙", "لوحة الأدمن", onAdmin) }
        item { MenuEntry("☷", "الإعدادات", onSettings) }
        item {
            OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج") }
        }
    }
}

@Composable
private fun MenuEntry(icon: String, title: String, onClick: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(icon)
            Text(title, style = MaterialTheme.typography.titleMedium)
        }
    }
}
