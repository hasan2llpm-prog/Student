package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.StudentProfile

@Composable
fun SettingsScreen(profile: StudentProfile?, offlineMode: Boolean, onRefresh: () -> Unit, onLogout: () -> Unit) {
    var dataSaver by remember { mutableStateOf(true) }
    var autoRefresh by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("إعدادات Student", style = MaterialTheme.typography.headlineSmall)
        Text("الحساب: ${profile?.email.orEmpty()}")
        Text(if (offlineMode) "الحالة: Offline" else "الحالة: متصل")
        HorizontalDivider()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("توفير البيانات"); Text("تقليل التحميل غير الضروري", style = MaterialTheme.typography.bodySmall) }
            Switch(checked = dataSaver, onCheckedChange = { dataSaver = it })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("التحديث التلقائي"); Text("تحديث المحتوى عند فتح الشاشة", style = MaterialTheme.typography.bodySmall) }
            Switch(checked = autoRefresh, onCheckedChange = { autoRefresh = it })
        }
        Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("مزامنة الحساب الآن") }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج") }
        Text("Student Native · بدون WebView", style = MaterialTheme.typography.labelMedium)
    }
}
