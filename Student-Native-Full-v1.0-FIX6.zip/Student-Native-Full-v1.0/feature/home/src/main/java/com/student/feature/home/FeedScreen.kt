@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun FeedScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    onOpenStories: (String?) -> Unit,
    onOpenProfile: () -> Unit,
    onOpenEducation: (String) -> Unit,
    onOpenStudentAi: () -> Unit,
    onOpenLearnEnglish: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var ads by remember { mutableStateOf<List<HomeAd>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            loading = true
            val loaded = withContext(Dispatchers.IO) { api.stories(session, 30) to api.homeAds(session) }
            loaded.first.onSuccess { stories = it }
            loaded.second.onSuccess { ads = it }
            loading = false
        }
    }
    LaunchedEffect(session.userId) { refresh() }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFF169CF0))
        HomeStoriesStrip(stories, profile, onOpenStories, onOpenProfile)
        HorizontalDivider(color = Color(0xFFE8E8E8))

        Spacer(Modifier.height(20.dp))
        HomeFeatureGrid(
            onPrimary = { onOpenEducation("primary") },
            onMiddle = { onOpenEducation("middle") },
            onSecondary = { onOpenEducation("secondary") },
            onUniversity = { onOpenEducation("university") },
            onAi = onOpenStudentAi,
            onLearnEnglish = onOpenLearnEnglish
        )

        Spacer(Modifier.weight(1f))
        if (ads.isNotEmpty()) {
            HomeAdsCarousel(ads)
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun HomeStoriesStrip(
    stories: List<StoryItem>,
    profile: StudentProfile?,
    onOpenStories: (String?) -> Unit,
    onOpenProfile: () -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxWidth().height(152.dp),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        item {
            HomeStoryCircle(
                name = "ستوري",
                avatarUrl = profile?.avatarUrl,
                frameUrl = profile?.profileFrameUrl,
                addBadge = true,
                ringColor = Color(0xFF159BF0),
                onClick = { onOpenStories("__create__") }
            )
        }
        item {
            val own = stories.firstOrNull { it.userId == profile?.id }
            HomeStoryCircle(
                name = "قصتي",
                avatarUrl = own?.authorAvatarUrl ?: profile?.avatarUrl,
                frameUrl = own?.authorFrameUrl ?: profile?.profileFrameUrl,
                mediaUrl = own?.takeIf { it.type.equals("image", true) }?.mediaUrl,
                ringColor = Color(0xFFEF233C),
                onClick = { onOpenStories(own?.id ?: "__create__") }
            )
        }
        items(stories.filter { it.userId != profile?.id }.take(12), key = { it.id }) { story ->
            HomeStoryCircle(
                name = story.authorName,
                avatarUrl = story.authorAvatarUrl,
                frameUrl = story.authorFrameUrl,
                mediaUrl = story.takeIf { it.type.equals("image", true) }?.mediaUrl,
                ringColor = Color(0xFFEF233C),
                onClick = { onOpenStories(story.id) }
            )
        }
    }
}

@Composable
private fun HomeStoryCircle(
    name: String,
    avatarUrl: String?,
    frameUrl: String?,
    mediaUrl: String? = null,
    addBadge: Boolean = false,
    ringColor: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.width(92.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Box(
                modifier = Modifier.size(84.dp).clip(CircleShape).border(4.dp, ringColor, CircleShape).padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                if (!mediaUrl.isNullOrBlank()) {
                    AsyncImage(mediaUrl, "ستوري", Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
                } else {
                    StudentAvatar(name, avatarUrl, frameUrl, 68.dp)
                }
            }
            if (addBadge) {
                Surface(
                    modifier = Modifier.size(29.dp), shape = CircleShape, color = Color(0xFFEF233C),
                    border = BorderStroke(3.dp, Color.White)
                ) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Add, "إضافة ستوري", tint = Color.White, modifier = Modifier.size(19.dp)) } }
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(name, maxLines = 1, fontSize = 13.sp, color = StudentText)
    }
}

@Composable
private fun HomeFeatureGrid(
    onPrimary: () -> Unit,
    onMiddle: () -> Unit,
    onSecondary: () -> Unit,
    onUniversity: () -> Unit,
    onAi: () -> Unit,
    onLearnEnglish: () -> Unit
) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { HomeCompactFeature(Icons.Rounded.School, "الابتدائي", Color(0xFFE7F6FF), Color(0xFF159BF0), onPrimary) }
        item { HomeCompactFeature(Icons.Rounded.AccountBalance, "الإعدادي", Color(0xFFF0EAFE), Color(0xFF7357D9), onMiddle) }
        item { HomeCompactFeature(Icons.Rounded.AccountBalance, "الثانوي", Color(0xFFE9F8F2), Color(0xFF138B62), onSecondary) }
        item { HomeCompactFeature(Icons.Rounded.AccountBalance, "الجامعة", Color(0xFFFFF6D9), Color(0xFFB87500), onUniversity) }
        item { HomeCompactFeature(Icons.Rounded.AutoAwesome, "Student AI", Color(0xFFF2E6FF), Color(0xFF8B42D9), onAi) }
        item { HomeCompactFeature(Icons.Rounded.Translate, "Learn English", Color(0xFFE5F7F8), Color(0xFF138A94), onLearnEnglish) }
    }
}

@Composable
private fun HomeCompactFeature(icon: ImageVector, title: String, bg: Color, tint: Color, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.widthIn(min = 118.dp).height(54.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = bg,
        border = BorderStroke(1.dp, tint.copy(alpha = .16f))
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, title, tint = tint, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(7.dp))
            Text(title, color = StudentText, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun HomeAdsCarousel(ads: List<HomeAd>) {
    val uri = LocalUriHandler.current
    val pager = rememberPagerState(pageCount = { ads.size })
    LaunchedEffect(ads.size, pager.currentPage) {
        if (ads.size > 1) {
            delay(4500)
            pager.animateScrollToPage((pager.currentPage + 1) % ads.size)
        }
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
        HorizontalPager(state = pager, pageSpacing = 10.dp) { index ->
            val ad = ads[index]
            Card(
                modifier = Modifier.fillMaxWidth().height(156.dp).clickable(enabled = !ad.actionUrl.isNullOrBlank()) {
                    ad.actionUrl?.let { runCatching { uri.openUri(it) } }
                },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F8FB)),
                border = BorderStroke(1.dp, Color(0xFFE8E8E8))
            ) {
                Box(Modifier.fillMaxSize()) {
                    if (!ad.imageUrl.isNullOrBlank()) {
                        AsyncImage(ad.imageUrl, ad.title.ifBlank { "إعلان Student" }, Modifier.fillMaxSize().background(Color.White), contentScale = ContentScale.Fit)
                    }
                    if (ad.title.isNotBlank()) {
                        Surface(
                            modifier = Modifier.align(Alignment.BottomStart).padding(9.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = Color.Black.copy(alpha = .55f)
                        ) { Text(ad.title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) }
                    }
                }
            }
        }
        if (ads.size > 1) {
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center) {
                repeat(ads.size) { i ->
                    Box(Modifier.padding(horizontal = 3.dp).size(if (i == pager.currentPage) 8.dp else 6.dp).clip(CircleShape).background(if (i == pager.currentPage) Color(0xFF169CF0) else Color(0xFFD6D6D6)))
                }
            }
        }
    }
}
