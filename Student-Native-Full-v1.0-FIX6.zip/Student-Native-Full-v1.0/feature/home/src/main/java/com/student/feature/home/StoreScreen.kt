package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StoreScreen(api: SupabaseApi, session: StudentSession, onProfileRefresh: () -> Unit = {}) {
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf(offline.loadProducts()) }
    var wallet by remember { mutableStateOf(WalletSummary()) }
    var orders by remember { mutableStateOf<List<StoreOrder>>(emptyList()) }
    var frames by remember { mutableStateOf<List<OwnedProfileFrame>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<StoreProduct?>(null) }
    var deleteFrame by remember { mutableStateOf<OwnedProfileFrame?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(3000); message = null } }

    fun refresh() {
        scope.launch {
            busy = true
            message = null
            val productResult = withContext(Dispatchers.IO) { api.storeProducts(session) }
            val walletResult = withContext(Dispatchers.IO) { api.walletSummary(session) }
            val orderResult = withContext(Dispatchers.IO) { api.storeOrders(session) }
            val frameResult = withContext(Dispatchers.IO) { api.myProfileFrames(session) }
            productResult.onSuccess { products = it; offline.saveProducts(it) }.onFailure { if (products.isEmpty()) message = it.message }
            walletResult.onSuccess { wallet = it }
            orderResult.onSuccess { orders = it }
            frameResult.onSuccess { frames = it }.onFailure { if (tab == 2) message = it.message }
            busy = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    selected?.let { p ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(p.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (p.productType == "frame" && !p.frameKey.isNullOrBlank()) {
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            StudentAvatar("S", null, "student-frame:${p.frameKey}", 74.dp)
                        }
                    }
                    Text(p.description.ifBlank { "اختر طريقة الدفع" })
                    p.frameDurationDays?.let { Text("المدة: $it يوم", color = StudentMuted, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (p.allowDiamonds) TextButton(onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.createStoreOrder(session, p.id, "diamonds") }
                            busy = false
                            r.onSuccess { message = "تم إنشاء الطلب بالألماس."; selected = null; refresh() }.onFailure { message = it.message }
                        }
                    }) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Diamond, null, Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("${p.priceDiamonds}") } }
                    if (p.allowMoney) Button(onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.createStoreOrder(session, p.id, "money") }
                            busy = false
                            r.onSuccess { message = "تم إنشاء طلب الدفع المالي. أكمل إثبات الدفع حسب تعليمات المتجر."; selected = null; refresh() }.onFailure { message = it.message }
                        }
                    }) { Text("${p.priceMoney.toLong()} ${p.currency}") }
                }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("إلغاء") } }
        )
    }

    deleteFrame?.let { frame ->
        AlertDialog(
            onDismissRequest = { deleteFrame = null },
            title = { Text("حذف الإطار؟") },
            text = { Text("سيُحذف ${frameLabel(frame.frameKey)} من إطاراتك. لا يمكن التراجع عن الحذف.") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.deleteProfileFrame(session, frame.id) }
                            busy = false
                            r.onSuccess {
                                deleteFrame = null
                                message = "تم حذف الإطار."
                                refresh()
                                onProfileRefresh()
                            }.onFailure { message = it.message }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleteFrame = null }) { Text("إلغاء") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F6FF)),
            border = BorderStroke(1.dp, Color(0xFFCFEAFF))
        ) {
            Column(Modifier.padding(14.dp)) {
                Text("المحفظة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text("المتاح: ${wallet.availableBalance.toLong()} ${if (wallet.availableBalance > 0) "IQD" else ""}", fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Diamond, null, Modifier.size(16.dp), tint = StudentBlue); Spacer(Modifier.width(4.dp)); Text("الألماس: ${wallet.diamonds}", fontSize = 13.sp) }
            }
        }

        TabRow(selectedTabIndex = tab, containerColor = Color.White, contentColor = StudentBlue) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("المنتجات") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("طلباتي") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("إطاراتي") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("خدمات") })
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = if (it.startsWith("تم")) Color(0xFF16803C) else StudentText, fontSize = 12.sp) }

        when (tab) {
            0 -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(products, key = { it.id }) { p ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selected = p },
                        shape = RoundedCornerShape(17.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE9EDF3)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            when {
                                p.productType == "frame" && !p.frameKey.isNullOrBlank() -> StudentAvatar("S", null, "student-frame:${p.frameKey}", 54.dp)
                                !p.imageUrl.isNullOrBlank() -> AsyncImage(
                                    model = p.imageUrl,
                                    contentDescription = p.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(62.dp).clip(RoundedCornerShape(13.dp))
                                )
                                else -> Surface(Modifier.size(62.dp), shape = RoundedCornerShape(13.dp), color = Color(0xFFF4F7FB)) {
                                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Storefront, null, tint = StudentBlue) }
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                if (p.description.isNotBlank()) Text(p.description, maxLines = 2, color = StudentMuted, fontSize = 11.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    if (p.allowMoney) Text("${p.priceMoney.toLong()} ${p.currency}", fontWeight = FontWeight.Bold, color = StudentBlue, fontSize = 12.sp)
                                    if (p.allowDiamonds) Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Diamond, null, Modifier.size(14.dp)); Spacer(Modifier.width(3.dp)); Text("${p.priceDiamonds}", fontSize = 12.sp) }
                                }
                            }
                            Icon(Icons.Rounded.ChevronRight, null, tint = StudentMuted)
                        }
                    }
                }
            }
            1 -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(orders, key = { it.id }) { o ->
                    StudentOutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(o.productName, fontWeight = FontWeight.Bold)
                            Text("الحالة: ${orderStatusLabel(o.status)}", color = StudentMuted, fontSize = 12.sp)
                            Text("الدفع: ${paymentLabel(o.paymentMethod)}", color = StudentMuted, fontSize = 12.sp)
                            Text(prettyTime(o.createdAt), color = Color(0xFF98A2B1), fontSize = 10.sp)
                        }
                    }
                }
                if (orders.isEmpty() && !busy) item { Text("لا توجد طلبات.", color = StudentMuted, modifier = Modifier.padding(12.dp)) }
            }
            2 -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item {
                    if (frames.any { it.isActive }) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    busy = true
                                    val r = withContext(Dispatchers.IO) { api.clearProfileFrame(session) }
                                    busy = false
                                    r.onSuccess {
                                        message = "تمت إزالة الإطار مؤقتًا."
                                        refresh()
                                        onProfileRefresh()
                                    }.onFailure { message = it.message }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("إزالة الإطار الحالي") }
                    }
                }
                items(frames, key = { it.id }) { frame ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(17.dp),
                        colors = CardDefaults.cardColors(containerColor = if (frame.isActive) Color(0xFFF3FAFF) else Color.White),
                        border = BorderStroke(1.dp, if (frame.isActive) Color(0xFF9FD8FF) else Color(0xFFE9EDF3))
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            StudentAvatar("S", null, "student-frame:${frame.frameKey}", 58.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(frameLabel(frame.frameKey), fontWeight = FontWeight.Bold)
                                Text(if (frame.isActive) "مفعّل الآن" else "متاح", color = if (frame.isActive) StudentBlue else StudentMuted, fontSize = 11.sp)
                                frame.expiresAt?.let { Text("ينتهي: ${prettyTime(it)}", color = StudentMuted, fontSize = 10.sp) }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                if (!frame.isActive) {
                                    TextButton(onClick = {
                                        scope.launch {
                                            busy = true
                                            val r = withContext(Dispatchers.IO) { api.equipProfileFrame(session, frame.id) }
                                            busy = false
                                            r.onSuccess {
                                                message = "تم تفعيل الإطار."
                                                refresh()
                                                onProfileRefresh()
                                            }.onFailure { message = it.message }
                                        }
                                    }) { Text("تفعيل", color = StudentBlue) }
                                }
                                TextButton(onClick = { deleteFrame = frame }) { Text("حذف", color = Color(0xFFC62828), fontSize = 11.sp) }
                            }
                        }
                    }
                }
                if (frames.isEmpty() && !busy) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 50.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Rounded.AutoAwesome, null, tint = StudentBlue, modifier = Modifier.size(30.dp))
                                Text("لا توجد إطارات في حسابك بعد.", color = StudentMuted)
                            }
                        }
                    }
                }
            }
            else -> StoreAdvancedSection(api, session) {
                refresh()
                onProfileRefresh()
            }
        }
    }
}

private fun frameLabel(key: String): String = when (key) {
    "fire" -> "نار مشتعلة"
    "blue-fire" -> "نار زرقاء"
    "neon" -> "نيون"
    "lightning" -> "برق"
    "royal" -> "ملكي ذهبي"
    "ember" -> "جمر"
    else -> "إطار مميز"
}

private fun orderStatusLabel(value: String): String = when (value.lowercase()) {
    "pending" -> "قيد المراجعة"
    "completed", "approved" -> "مكتمل"
    "rejected", "cancelled" -> "مرفوض"
    else -> value
}

private fun paymentLabel(value: String): String = when (value.lowercase()) {
    "diamonds" -> "ألماس"
    "money" -> "دفع مالي"
    else -> value
}
