package com.student.feature.home

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun MessagesScreen(api: SupabaseApi, session: StudentSession, onOpenProfile: (String) -> Unit = {}, onConversationStateChanged: (Boolean) -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val offline = remember { OfflineStore(context) }
    var conversations by remember { mutableStateOf<List<ConversationItem>>(emptyList()) }
    var current by remember { mutableStateOf<ConversationItem?>(null) }
    var messages by remember { mutableStateOf<List<MessageItem>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val messageListState = rememberLazyListState()
    var imagePreview by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(error) { if (error != null) { delay(3200); error = null } }

    fun loadConversations() {
        scope.launch {
            busy = true
            error = null
            val r = withContext(Dispatchers.IO) { api.conversations(session) }
            r.onSuccess { conversations = it }.onFailure { error = it.message }
            busy = false
        }
    }

    fun loadMessages(conv: ConversationItem, quiet: Boolean = false) {
        scope.launch {
            if (!quiet) {
                busy = true
                val cached = offline.loadMessages(conv.id)
                if (cached.isNotEmpty()) messages = cached.sortedBy { it.createdAt }
            }
            val r = withContext(Dispatchers.IO) { api.messages(session, conv.id) }
            r.onSuccess { rows ->
                messages = rows.sortedBy { it.createdAt }
                offline.saveMessages(conv.id, rows)
                withContext(Dispatchers.IO) { api.markConversationRead(session, conv.id) }
            }.onFailure { if (!quiet && messages.isEmpty()) error = it.message else if (!quiet) error = "Offline: يتم عرض آخر رسائل محفوظة." }
            if (!quiet) busy = false
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        val conv = current
        if (picked != null && conv != null) {
            scope.launch {
                busy = true
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val bytes = context.contentResolver.openInputStream(picked)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الملف.")
                        if (bytes.size > 20 * 1024 * 1024) throw IllegalStateException("الحد الأقصى 20MB.")
                        val mime = context.contentResolver.getType(picked) ?: "application/octet-stream"
                        val type = when {
                            mime.startsWith("image/") -> "image"
                            mime.startsWith("video/") -> "video"
                            mime.startsWith("audio/") -> "audio"
                            else -> "file"
                        }
                        val ext = when (type) { "image" -> "jpg"; "video" -> "mp4"; "audio" -> "m4a"; else -> "bin" }
                        val path = "${session.userId}/${System.currentTimeMillis()}_native.$ext"
                        val url = api.uploadObject(session, "chat-media", path, bytes, mime).getOrThrow()
                        api.sendMediaMessage(session, conv.id, url, type, "attachment.$ext", bytes.size.toLong()).getOrThrow()
                    }
                }
                result.onSuccess { loadMessages(conv, quiet = true) }.onFailure { error = it.message }
                busy = false
            }
        }
    }

    BackHandler(enabled = current != null) {
        current = null
        messages = emptyList()
        loadConversations()
    }

    LaunchedEffect(Unit) { loadConversations() }
    LaunchedEffect(current?.id) { onConversationStateChanged(current != null) }
    DisposableEffect(Unit) { onDispose { onConversationStateChanged(false) } }
    DisposableEffect(current?.id, session.accessToken) {
        val conv = current
        val observer = if (conv != null) api.observeConversationMessages(session, conv.id) {
            loadMessages(conv, quiet = true)
        } else null
        onDispose { observer?.close() }
    }
    LaunchedEffect(current?.id, messages.size) {
        if (current != null && messages.isNotEmpty()) {
            delay(60)
            messageListState.animateScrollToItem(messages.lastIndex)
        }
    }
    LaunchedEffect(current?.id) {
        val conv = current ?: return@LaunchedEffect
        while (current?.id == conv.id) {
            delay(15000)
            loadMessages(conv, quiet = true)
        }
    }

    imagePreview?.let { url ->
        Dialog(onDismissRequest = { imagePreview = null }) {
            Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                AsyncImage(model = url, contentDescription = "عرض الصورة", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                IconButton(onClick = { imagePreview = null }, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)) {
                    Icon(Icons.Rounded.Close, "إغلاق", tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }
        }
    }

    if (current == null) {
        Column(Modifier.fillMaxSize().background(StudentMessageBg)) {
            Row(
                Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("المحادثات", fontSize = 20.sp, fontWeight = FontWeight.Black, color = StudentText)
                    Text("رسائلك في Student", fontSize = 11.sp, color = StudentMuted)
                }
                TextButton(onClick = { loadConversations() }) { Text("تحديث", color = StudentBlue) }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp), fontSize = 12.sp) }
            LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(conversations, key = { it.id }) { c ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { current = c; loadMessages(c) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFE9EDF3)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                            StudentAvatar(c.title, c.avatarUrl, c.profileFrameUrl, 50.dp)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                StudentName(c.title, c.isVerified, c.verificationColor)
                                Text(c.lastMessage.ifBlank { "لا توجد رسائل" }, maxLines = 1, color = StudentMuted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(prettyTime(c.lastMessageAt), color = Color(0xFF98A2B1), fontSize = 9.sp)
                                if (c.unreadCount > 0) {
                                    Spacer(Modifier.height(5.dp))
                                    Badge(containerColor = StudentBlue) { Text(if (c.unreadCount > 99) "99+" else c.unreadCount.toString(), color = Color.White) }
                                }
                            }
                        }
                    }
                }
                if (conversations.isEmpty() && !busy) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 70.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Rounded.Email, null, tint = StudentBlue, modifier = Modifier.size(34.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("لا توجد محادثات بعد", fontWeight = FontWeight.Bold)
                                Text("ابحث عن شخص وابدأ المراسلة.", color = StudentMuted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    } else {
        val conv = current!!
        Column(Modifier.fillMaxSize().background(StudentMessageBg)) {
            Row(
                Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { current = null; messages = emptyList(); loadConversations() }) { Icon(Icons.Rounded.ArrowBack, "رجوع", tint = StudentText) }
                Row(Modifier.weight(1f).clickable(enabled = !conv.otherUserId.isNullOrBlank()) { conv.otherUserId?.let(onOpenProfile) }, verticalAlignment = Alignment.CenterVertically) {
                    StudentAvatar(conv.title, conv.avatarUrl, conv.profileFrameUrl, 42.dp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        StudentName(conv.title, conv.isVerified, conv.verificationColor)
                        Text("عرض الحساب", fontSize = 10.sp, color = StudentMuted)
                    }
                }
                IconButton(onClick = { loadMessages(conv) }) { Icon(Icons.Rounded.Refresh, "تحديث", tint = StudentText) }
            }
            HorizontalDivider(color = Color(0xFFE8EDF4))
            if (busy && messages.isEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 11.sp) }
            LazyColumn(
                state = messageListState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(messages, key = { it.id }) { m ->
                    val mine = m.senderId == session.userId
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End) {
                        Surface(
                            color = if (mine) Color(0xFFDFF0FF) else Color.White,
                            shape = RoundedCornerShape(17.dp),
                            shadowElevation = 1.dp,
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 11.dp, vertical = 8.dp)) {
                                if (m.deletedAt != null) {
                                    Text("تم حذف الرسالة", color = StudentMuted, fontSize = 13.sp)
                                } else {
                                    if (m.body.isNotBlank()) Text(m.body, color = StudentText, lineHeight = 20.sp)
                                    m.mediaUrl?.let { url ->
                                        if (m.messageType.lowercase() == "image") {
                                            Spacer(Modifier.height(5.dp))
                                            AsyncImage(
                                                model = url,
                                                contentDescription = "صورة مرفقة",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.widthIn(max = 260.dp).heightIn(min = 120.dp, max = 320.dp).clip(RoundedCornerShape(12.dp)).clickable { imagePreview = url }
                                            )
                                        } else {
                                            Spacer(Modifier.height(5.dp))
                                            TextButton(onClick = { runCatching { uriHandler.openUri(url) } }) {
                                                Icon(when (m.messageType.lowercase()) { "video" -> Icons.Rounded.PlayCircle; "audio" -> Icons.Rounded.AudioFile; else -> Icons.Rounded.AttachFile }, null)
                                                Spacer(Modifier.width(4.dp))
                                                Text(when (m.messageType.lowercase()) { "video" -> "فيديو"; "audio" -> "ملف صوتي"; else -> m.fileName ?: "ملف" })
                                            }
                                        }
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(prettyTime(m.createdAt), style = MaterialTheme.typography.labelSmall, color = Color(0xFF8792A0))
                                    if (mine) Icon(if (m.readCount > 0) Icons.Rounded.DoneAll else Icons.Rounded.Done, "حالة القراءة", tint = if (m.readCount > 0) StudentBlue else StudentMuted, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().background(Color.White).imePadding().padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                OutlinedIconButton(onClick = { filePicker.launch("*/*") }, enabled = !busy, modifier = Modifier.size(45.dp), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Rounded.AttachFile, "إرفاق") }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("اكتب رسالة...") },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    shape = RoundedCornerShape(18.dp)
                )
                Button(
                    onClick = {
                        val body = input.trim()
                        if (body.isBlank()) return@Button
                        input = ""
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { api.sendMessage(session, conv.id, body) }
                            r.onSuccess { loadMessages(conv, quiet = true) }.onFailure {
                                offline.enqueue("message_text", JSONObject().put("conversation_id", conv.id).put("body", body))
                                error = "لا يوجد اتصال. تم حفظ الرسالة وستُرسل عند رجوع الإنترنت."
                            }
                        }
                    },
                    enabled = input.isNotBlank(),
                    modifier = Modifier.height(46.dp),
                    shape = RoundedCornerShape(15.dp)
                ) { Text("إرسال") }
            }
        }
    }
}
