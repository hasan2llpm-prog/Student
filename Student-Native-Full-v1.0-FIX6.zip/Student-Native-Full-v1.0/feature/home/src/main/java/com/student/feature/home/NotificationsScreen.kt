package com.student.feature.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun NotificationsScreen(api: SupabaseApi, session: StudentSession, onOpenTarget: (String) -> Unit = {}, onUnreadChanged: (Int) -> Unit = {}) {
    val cfg = LocalNativeRemoteConfig.current
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(offline.loadNotifications()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            val r = withContext(Dispatchers.IO) { api.notifications(session, cfg.int("notifications.limit", 60, 10, 200)) }
            r.onSuccess { fresh -> items = fresh; offline.saveNotifications(fresh); message = null; onUnreadChanged(fresh.count { !it.isRead }) }
                .onFailure { message = if (items.isEmpty()) it.message else "Offline: آخر إشعارات محفوظة" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(cfg.long("notifications.status_duration_ms", 2600L, 500L, 10000L)); message = null } }

    Column(Modifier.fillMaxSize()) {
        if (cfg.bool("notifications.show_header", true)) Row(Modifier.fillMaxWidth().padding(cfg.int("notifications.header_padding_dp", 12, 4, 24).dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(cfg.string("notifications.header_title", "الإشعارات"), style = MaterialTheme.typography.headlineSmall)
            if (cfg.bool("notifications.show_refresh", true)) TextButton(onClick = { refresh() }, enabled = !loading) { Text("تحديث") }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        message?.let { Text(it, Modifier.padding(horizontal = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        LazyColumn(contentPadding = PaddingValues(cfg.int("notifications.list_padding_dp", 12, 4, 24).dp), verticalArrangement = Arrangement.spacedBy(cfg.int("notifications.card_spacing_dp", 8, 2, 20).dp)) {
            items(items, key = { it.id }) { n ->
                ElevatedCard(
                    Modifier.fillMaxWidth().clickable {
                        if (!n.isRead) {
                            scope.launch {
                                withContext(Dispatchers.IO) { api.markNotificationRead(session, n.id) }
                                items = items.map { if (it.id == n.id) it.copy(isRead = true) else it }
                                offline.saveNotifications(items)
                                onUnreadChanged(items.count { !it.isRead })
                            }
                        }
                        onOpenTarget(n.link?.takeIf { it.isNotBlank() } ?: n.kind)
                    }
                ) {
                    Column(Modifier.padding(cfg.int("notifications.card_padding_dp", 14, 8, 24).dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(n.title, style = MaterialTheme.typography.titleMedium)
                            if (cfg.bool("notifications.show_new_badge", true) && !n.isRead) Badge { Text(cfg.string("notifications.new_badge_text", "جديد")) }
                        }
                        if (cfg.bool("notifications.show_body", true) && n.body.isNotBlank()) Text(n.body, style = MaterialTheme.typography.bodyMedium)
                        if (cfg.bool("notifications.show_time", true)) Text(prettyTime(n.createdAt), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (items.isEmpty() && !loading) item { Text("لا توجد إشعارات.") }
        }
    }
}
