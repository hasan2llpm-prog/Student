# Student Native

This repository contains only the Android Native Student application and its native backend support files.

- Android: Kotlin + Jetpack Compose
- Backend: Supabase
- Push: Firebase FCM through Supabase functions
- Build: GitHub Actions

Web/PWA legacy files and old packaged releases were intentionally removed.

## Student v2.1.0 Beta (2026-09-06)
Beta-only test cycle. versionCode 22 / versionName 2.1.0-beta.
Includes Stories V2 editor/grouped viewer, Advanced Translation image-to-text, and 250-item corpora for Reading, Listening, Writing and Speaking.
Do not force-update production users to this beta. Production 2.1.0 will use a higher versionCode after beta validation.
