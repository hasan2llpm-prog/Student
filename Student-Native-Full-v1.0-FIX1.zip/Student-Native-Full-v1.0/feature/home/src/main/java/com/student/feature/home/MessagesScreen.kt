package com.student.feature.home

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun MessagesScreen(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val offline = remember { OfflineStore(context) }
    var conversations by remember { mutableStateOf<List<ConversationItem>>(emptyList()) }
    var current by remember { mutableStateOf<ConversationItem?>(null) }
    var messages by remember { mutableStateOf<List<MessageItem>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun loadConversations() {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.IO) { api.conversations(session) }
            r.onSuccess { conversations = it }.onFailure { error = it.message }
            busy = false
        }
    }

    fun loadMessages(conv: ConversationItem, quiet: Boolean = false) {
        scope.launch {
            if (!quiet) busy = true
            val r = withContext(Dispatchers.IO) { api.messages(session, conv.id) }
            r.onSuccess { rows ->
                messages = rows.sortedBy { it.createdAt }
                withContext(Dispatchers.IO) { api.markConversationRead(session, conv.id) }
            }.onFailure { if (!quiet) error = it.message }
            if (!quiet) busy = false
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        val conv = current
        if (picked != null && conv != null) {
            scope.launch {
                busy = true
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val bytes = context.contentResolver.openInputStream(picked)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الملف.")
                        if (bytes.size > 20 * 1024 * 1024) throw IllegalStateException("الحد الأقصى 20MB.")
                        val mime = context.contentResolver.getType(picked) ?: "application/octet-stream"
                        val type = when { mime.startsWith("image/") -> "image"; mime.startsWith("video/") -> "video"; mime.startsWith("audio/") -> "audio"; else -> "file" }
                        val ext = when (type) { "image" -> "jpg"; "video" -> "mp4"; "audio" -> "m4a"; else -> "bin" }
                        val path = "${session.userId}/${System.currentTimeMillis()}_native.$ext"
                        val url = api.uploadObject(session, "chat-media", path, bytes, mime).getOrThrow()
                        api.sendMediaMessage(session, conv.id, url, type, "attachment.$ext", bytes.size.toLong()).getOrThrow()
                    }
                }
                result.onSuccess { loadMessages(conv, quiet = true) }.onFailure { error = it.message }
                busy = false
            }
        }
    }

    BackHandler(enabled = current != null) { current = null; messages = emptyList() }

    LaunchedEffect(Unit) { loadConversations() }
    LaunchedEffect(current?.id) {
        val conv = current ?: return@LaunchedEffect
        while (current?.id == conv.id) {
            delay(4000)
            loadMessages(conv, quiet = true)
        }
    }

    if (current == null) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("المحادثات", style = MaterialTheme.typography.headlineSmall)
                TextButton(onClick = { loadConversations() }) { Text("تحديث") }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(conversations, key = { it.id }) { c ->
                    ElevatedCard(Modifier.fillMaxWidth().clickable { current = c; loadMessages(c) }) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(c.title, style = MaterialTheme.typography.titleMedium)
                                if (c.unreadCount > 0) Badge { Text(c.unreadCount.toString()) }
                            }
                            if (c.lastMessage.isNotBlank()) Text(c.lastMessage, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
                            Text(prettyTime(c.lastMessageAt), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                if (conversations.isEmpty() && !busy) item { Text("لا توجد محادثات بعد.") }
            }
        }
    } else {
        val conv = current!!
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { current = null; messages = emptyList(); loadConversations() }) { Text("‹") }
                Text(conv.title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { loadMessages(conv) }) { Text("↻") }
            }
            HorizontalDivider()
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(messages, key = { it.id }) { m ->
                    val mine = m.senderId == session.userId
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.widthIn(max = 300.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                Text(if (m.deletedAt != null) "تم حذف الرسالة" else m.body.ifBlank { "${m.messageType} attachment" })
                                Text(prettyTime(m.createdAt), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { filePicker.launch("*/*") }, enabled = !busy) { Text("＋") }
                OutlinedTextField(value = input, onValueChange = { input = it }, placeholder = { Text("اكتب رسالة...") }, modifier = Modifier.weight(1f), maxLines = 4)
                Button(onClick = {
                    val body = input.trim()
                    if (body.isBlank()) return@Button
                    input = ""
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { api.sendMessage(session, conv.id, body) }
                        r.onSuccess { loadMessages(conv, quiet = true) }.onFailure { err ->
                            offline.enqueue("message_text", JSONObject().put("conversation_id", conv.id).put("body", body))
                            error = "لا يوجد اتصال. تم حفظ الرسالة وستُرسل عند رجوع الإنترنت."
                        }
                    }
                }, enabled = input.isNotBlank()) { Text("إرسال") }
            }
        }
    }
}
