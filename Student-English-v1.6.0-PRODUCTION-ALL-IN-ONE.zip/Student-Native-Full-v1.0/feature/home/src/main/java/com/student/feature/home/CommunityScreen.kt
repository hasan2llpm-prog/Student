package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CommunityScreen(api: SupabaseApi, session: StudentSession, onOpenProfile: (String) -> Unit, onCreatePost: () -> Unit) {
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf<List<PostItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var openedComments by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            withContext(Dispatchers.IO) { api.feed(session, 100) }
                .onSuccess { posts = it; message = null }
                .onFailure { message = it.message ?: "تعذر تحميل المجتمع." }
            loading = false
        }
    }
    LaunchedEffect(session.userId) { refresh() }

    openedComments?.let { postId ->
        CommunityComments(api, session, postId, onClose = { openedComments = null })
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("المجتمع", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text("منشورات الطلاب والمدرسين بعيداً عن ازدحام الرئيسية", color = StudentMuted, style = MaterialTheme.typography.bodySmall)
            }
            FilledTonalButton(onClick = onCreatePost) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("نشر") }
        }
        message?.let { Text(it, Modifier.padding(horizontal = 12.dp), color = MaterialTheme.colorScheme.error) }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(posts, key = { it.id }) { post ->
                CommunityPostCard(api, session, post, onOpenProfile, onComments = { openedComments = post.id }, onDeleted = ::refresh)
            }
            if (posts.isEmpty() && !loading) item { Text("لا توجد منشورات بعد. كن أول من ينشر.", color = StudentMuted, modifier = Modifier.padding(18.dp)) }
        }
    }
}

@Composable
private fun CommunityPostCard(api: SupabaseApi, session: StudentSession, post: PostItem, onOpenProfile: (String) -> Unit, onComments: () -> Unit, onDeleted: () -> Unit) {
    val scope = rememberCoroutineScope()
    var liked by remember(post.id) { mutableStateOf(false) }
    var commentCount by remember(post.id) { mutableIntStateOf(0) }
    var deleteConfirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(post.id) {
        liked = withContext(Dispatchers.IO) { api.isPostLiked(session, post.id).getOrDefault(false) }
        commentCount = withContext(Dispatchers.IO) { api.comments(session, post.id).getOrDefault(emptyList()).size }
    }
    if (deleteConfirm) AlertDialog(
        onDismissRequest = { if (!busy) deleteConfirm = false },
        title = { Text("حذف المنشور؟") },
        text = { Text("سيتم حذف المنشور من حسابك والمجتمع. هل أنت متأكد؟") },
        confirmButton = { Button(enabled = !busy, onClick = { scope.launch { busy = true; withContext(Dispatchers.IO) { api.deletePost(session, post.id) }.onSuccess { deleteConfirm = false; onDeleted() }; busy = false } }) { Text("حذف") } },
        dismissButton = { TextButton(enabled = !busy, onClick = { deleteConfirm = false }) { Text("إلغاء") } }
    )
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, StudentBorder)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).clickable { onOpenProfile(post.userId) }, verticalAlignment = Alignment.CenterVertically) {
                    StudentAvatar(post.authorName, post.authorAvatarUrl, post.authorFrameUrl, 44.dp)
                    Spacer(Modifier.width(8.dp))
                    Column { StudentName(post.authorName, post.authorVerified, post.authorVerificationColor); Text("@${post.authorUsername} • ${prettyTime(post.createdAt)}", color = StudentMuted, style = MaterialTheme.typography.labelSmall) }
                }
                if (post.userId == session.userId) IconButton(onClick = { deleteConfirm = true }) { Icon(Icons.Rounded.DeleteOutline, "حذف") }
            }
            if (post.content.isNotBlank()) Text(post.content, style = MaterialTheme.typography.bodyLarge)
            post.mediaUrl?.takeIf { it.isNotBlank() }?.let { url ->
                coil.compose.AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 420.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { scope.launch { val next = !liked; withContext(Dispatchers.IO) { api.setPostLiked(session, post.id, next) }.onSuccess { liked = next } } }) {
                    Icon(if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null); Spacer(Modifier.width(4.dp)); Text(if (liked) "تم التفاعل" else "تفاعل")
                }
                OutlinedButton(onClick = onComments) { Icon(Icons.Rounded.ChatBubbleOutline, null); Spacer(Modifier.width(4.dp)); Text("تعليقات $commentCount") }
            }
        }
    }
}

@Composable
private fun CommunityComments(api: SupabaseApi, session: StudentSession, postId: String, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var comments by remember { mutableStateOf<List<CommentItem>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<CommentItem?>(null) }
    var busy by remember { mutableStateOf(false) }
    fun refresh() { scope.launch { withContext(Dispatchers.IO) { api.comments(session, postId) }.onSuccess { comments = it } } }
    LaunchedEffect(postId) { refresh() }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.ArrowBack, "رجوع") }
            Text("التعليقات والردود", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(comments.filter { it.parentId == null }, key = { it.id }) { c ->
                CommentBubble(c, false, onReply = { replyTo = c })
                comments.filter { it.parentId == c.id }.forEach { r -> Box(Modifier.padding(start = 28.dp)) { CommentBubble(r, true, onReply = { replyTo = c }) } }
            }
        }
        replyTo?.let { Surface(color = StudentSoft, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Text("رد على ${it.authorName}", Modifier.weight(1f), color = StudentBlue); IconButton(onClick = { replyTo = null }) { Icon(Icons.Rounded.Close, null) } } } }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it.take(1500) }, modifier = Modifier.weight(1f), placeholder = { Text(if (replyTo == null) "اكتب تعليقاً..." else "اكتب ردك...") }, maxLines = 4)
            Spacer(Modifier.width(6.dp))
            IconButton(enabled = !busy && text.isNotBlank(), onClick = { scope.launch { busy = true; withContext(Dispatchers.IO) { api.addComment(session, postId, text.trim(), replyTo?.id) }.onSuccess { text = ""; replyTo = null; refresh() }; busy = false } }) { Icon(Icons.Rounded.Send, "إرسال") }
        }
    }
}

@Composable private fun CommentBubble(c: CommentItem, reply: Boolean, onReply: () -> Unit) {
    Surface(shape = RoundedCornerShape(14.dp), color = if (reply) Color(0xFFF7F8FA) else StudentSoft) {
        Column(Modifier.fillMaxWidth().padding(10.dp)) {
            Text(c.authorName, fontWeight = FontWeight.Bold)
            Text(c.content)
            Row { Text(prettyTime(c.createdAt), color = StudentMuted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f)); TextButton(onClick = onReply) { Text("رد") } }
        }
    }
}
