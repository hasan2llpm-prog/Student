package com.student.core.data

import android.content.Context

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("student_native_session", Context.MODE_PRIVATE)

    fun save(session: StudentSession) {
        prefs.edit()
            .putString("access_token", session.accessToken)
            .putString("refresh_token", session.refreshToken)
            .putString("user_id", session.userId)
            .putString("email", session.email)
            .apply()
    }

    fun load(): StudentSession? {
        val access = prefs.getString("access_token", null) ?: return null
        val refresh = prefs.getString("refresh_token", null) ?: return null
        val userId = prefs.getString("user_id", null) ?: return null
        return StudentSession(access, refresh, userId, prefs.getString("email", "").orEmpty())
    }

    fun clear() = prefs.edit().clear().apply()
}
