package com.student.core.data

object StudentConfig {
    const val SUPABASE_URL = "https://mlcbixsyizsuxxfjwrym.supabase.co"
    const val PASSWORD_RECOVERY_REDIRECT = "student://reset-password"
    const val SUPABASE_KEY = "sb_publishable_DDvBmb3o1x_VfArVUg-mzw_nbsR7rRA"
    const val NATIVE_REMOTE_CONFIG_URL = "https://student-b1v.pages.dev/config.json"
    const val NATIVE_REMOTE_CONFIG_FALLBACK_URL = "https://raw.githubusercontent.com/hasan2llpm-prog/Student/main/config.json"
    const val FIREBASE_PROJECT_ID = "student-1fcba"
    const val FIREBASE_SENDER_ID = "898081758778"
    const val FIREBASE_API_KEY = "AIzaSyCWhbGfLtUymIO3O5itIC9054FOgE0aYi0"
    const val FIREBASE_APP_ID = "1:898081758778:web:7c7f0fa6b2cb52387e5f03"
}
