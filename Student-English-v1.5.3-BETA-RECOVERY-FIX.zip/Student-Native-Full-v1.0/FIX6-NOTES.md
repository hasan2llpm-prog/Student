# Student Native FIX6

Functional/UX correction pass based on installed FIX5 testing and the original Student source.

Implemented in this package:
- Student AI request compatibility with original `student-ai` Edge Function (`prompt` payload, with `text` compatibility field).
- Self-notifications filtered from native notification list/count; unread badge falls back to zero, not stale values.
- Notification unread badge updates immediately after marking read.
- Home story circles open the selected story directly; add-story opens the composer; root bars are hidden in story viewer flow.
- Removed instructional story text; preserved native reactions/replies/viewers/delete flow.
- Home education/AI/Learn English controls changed to compact horizontal cards.
- Home ads show full image with `ContentScale.Fit` and more usable height.
- Messages auto-scroll to newest message on open/send/Realtime refresh.
- Chat image attachments open in an in-app full-screen viewer instead of the browser.
- Conversation header and search result profile area can open the selected user's native profile.
- Added native public-profile route with follow/message actions.
- Education: admin can add school/university subjects; approved teacher/admin roles can publish lessons/materials through existing backend APIs/RPCs.
- Store owned-frames now falls back to the original `student_profile_frames` table if `student_get_my_profile_frames` RPC is unavailable.
- Common transient success/error messages in major affected screens auto-dismiss instead of remaining stuck.
- FIX5 Foundation Pager opt-in is applied file-wide so GitHub build does not need the old workflow patch.

Server-side RLS/RPC remains authoritative. A teacher/admin action that the backend does not permit will show the real backend error rather than pretending success.

## Home reference layout patch
- Home stories use compact defaults matching the accepted legacy-home reference.
- Education + Student AI + Learn English use circular home shortcuts: five on the first row and remaining items on the second row.
- Home ads support `ads_position=center` and auto-advance with the pager.
- Student AI and Learn English are intentionally removed from the side menu; they remain available from Home.
- All size/spacing keys above remain remotely adjustable from native_ui.home in config.json.
