package com.student.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

private val StudentLightColors = lightColorScheme(
    primary = Color(0xFF6D28D9),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF0E7FF),
    onPrimaryContainer = Color(0xFF31115E),
    secondary = Color(0xFF5B21B6),
    secondaryContainer = Color(0xFFF4EEFF),
    background = Color.White,
    onBackground = Color(0xFF262626),
    surface = Color.White,
    onSurface = Color(0xFF262626),
    surfaceVariant = Color(0xFFFAF7FF),
    onSurfaceVariant = Color(0xFF6B7280),
    outline = Color(0xFFDBDBDB),
    error = Color(0xFFC62828),
    errorContainer = Color(0xFFFFEBEE)
)

@Composable
fun StudentTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = StudentLightColors, content = content)
    }
}
