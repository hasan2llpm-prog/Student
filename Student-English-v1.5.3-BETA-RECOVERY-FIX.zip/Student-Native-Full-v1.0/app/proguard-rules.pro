# Student Native - initial rules
