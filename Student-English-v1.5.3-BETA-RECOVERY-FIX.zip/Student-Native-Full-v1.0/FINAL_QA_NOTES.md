# Student FIX6 Final QA

This build continues from FIX6 Translation + Push and consolidates the latest requested fixes.

- Story expiry is enforced in the native story loader (expires_at, with created_at + 24h fallback).
- Story viewer: tap left/right, hold to pause/resume, smoother pager, owner edit/delete, polished replies/reactions/views.
- Translation screen scrolls so pronunciation controls remain reachable.
- Notifications: mark all as read; admin-only broadcast to all; real unread badge remains server-derived.
- Notification intent routing reads FCM link/kind extras when app is backgrounded/killed; story/profile/message routes are handled.
- Settings: removed technical WebView/Native footer; logout confirmation; change email; change password.
- Existing native FCM token registration / background delivery from prior build preserved.

QA note: GitHub Actions compile is required. Device QA is still required before MediaFire release.
