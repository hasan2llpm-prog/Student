package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PublicProfileScreen(api: SupabaseApi, session: StudentSession, userId: String, onMessage: () -> Unit) {
    val scope = rememberCoroutineScope()
    var item by remember(userId) { mutableStateOf<ProfileSearchItem?>(null) }
    var stats by remember(userId) { mutableStateOf(ProfileStats()) }
    var following by remember(userId) { mutableStateOf(false) }
    var busy by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    var avatarPreview by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(userId) {
        busy = true
        val profileResult = withContext(Dispatchers.IO) { api.searchProfiles(session, userId) }
        // Search-by-id is not supported by the public search RPC, so use the dedicated lookup below when available.
        val exact = withContext(Dispatchers.IO) { api.profileById(session, userId) }
        exact.onSuccess { p ->
            item = ProfileSearchItem(p.id, p.fullName, p.username, p.role, p.avatarUrl, p.isVerified, p.verificationColor, p.profileFrameUrl)
            stats = withContext(Dispatchers.IO) { api.profileStats(session, p.id).getOrDefault(ProfileStats()) }
            following = withContext(Dispatchers.IO) { api.isFollowing(session, p.id).getOrDefault(false) }
        }.onFailure { message = it.message ?: "تعذر تحميل الحساب." }
        busy = false
    }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(2600); message = null } }

    avatarPreview?.let { url ->
        StudentImageViewer(url = url, fileName = "profile-$userId.jpg", onDismiss = { avatarPreview = null })
    }

    if (busy && item == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }; return }
    val p = item
    if (p == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(message ?: "الحساب غير متاح") }; return }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFE9EDF3))) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.clickable(enabled = !p.avatarUrl.isNullOrBlank()) { p.avatarUrl?.let { avatarPreview = it } }) {
                        StudentAvatar(p.fullName, p.avatarUrl, p.profileFrameUrl, 92.dp)
                    }
                    Spacer(Modifier.height(8.dp))
                    StudentName(p.fullName, p.isVerified, p.verificationColor, style = MaterialTheme.typography.headlineSmall)
                    Text("@${p.username}", color = StudentMuted, fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Text("${stats.posts}\nمنشور", textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("${stats.followers}\nمتابع", textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("${stats.following}\nيتابع", textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                    if (p.id != session.userId) {
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                scope.launch {
                                    busy = true
                                    val r = withContext(Dispatchers.IO) { api.setFollowing(session, p.id, !following) }
                                    busy = false
                                    r.onSuccess { following = !following; message = if (following) "تمت المتابعة." else "تم إلغاء المتابعة." }.onFailure { message = it.message }
                                }
                            }, modifier = Modifier.weight(1f), enabled = !busy) { Text(if (following) "إلغاء المتابعة" else "متابعة") }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    busy = true
                                    val r = withContext(Dispatchers.IO) { api.startDirectChat(session, p.id) }
                                    busy = false
                                    r.onSuccess { onMessage() }.onFailure { message = it.message }
                                }
                            }, modifier = Modifier.weight(1f), enabled = !busy) { Text("مراسلة") }
                        }
                    }
                }
            }
        }
        message?.let { item { Text(it, color = StudentMuted, modifier = Modifier.fillMaxWidth()) } }
    }
}
