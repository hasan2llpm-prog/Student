package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.student.core.data.StudentSession
import com.student.core.data.SupabaseApi

private fun createTranslator(source: String, target: String): Translator {
    val options = TranslatorOptions.Builder()
        .setSourceLanguage(source)
        .setTargetLanguage(target)
        .build()
    return Translation.getClient(options)
}

@Composable
fun StudentAiScreen(api: SupabaseApi, session: StudentSession) {
    // api/session intentionally kept in signature to preserve current navigation contract.
    val clipboard = LocalClipboardManager.current
    val speech = rememberStudentSpeechController()

    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var preparing by remember { mutableStateOf(true) }
    var modelsReady by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var accent by remember { mutableStateOf("american") }
    var speed by remember { mutableStateOf("normal") }

    val arToEn = remember { createTranslator(TranslateLanguage.ARABIC, TranslateLanguage.ENGLISH) }
    val enToAr = remember { createTranslator(TranslateLanguage.ENGLISH, TranslateLanguage.ARABIC) }

    DisposableEffect(Unit) {
        onDispose {
            arToEn.close()
            enToAr.close()
        }
    }

    LaunchedEffect(error) {
        if (error != null) {
            kotlinx.coroutines.delay(3500)
            error = null
        }
    }

    // Download both Arabic/English models once. After this, translation works offline.
    LaunchedEffect(Unit) {
        val conditions = DownloadConditions.Builder().build()
        var completed = 0
        var failed = false
        fun done(ok: Boolean) {
            completed += 1
            if (!ok) failed = true
            if (completed == 2) {
                preparing = false
                modelsReady = !failed
                if (failed) {
                    error = "يحتاج تنزيل نموذج الترجمة مرة واحدة عند توفر الإنترنت، وبعدها تعمل الترجمة بدون نت."
                }
            }
        }
        arToEn.downloadModelIfNeeded(conditions)
            .addOnSuccessListener { done(true) }
            .addOnFailureListener { done(false) }
        enToAr.downloadModelIfNeeded(conditions)
            .addOnSuccessListener { done(true) }
            .addOnFailureListener { done(false) }
    }

    fun translateNow() {
        val text = input.trim()
        if (text.isBlank() || busy) return

        error = null
        busy = true
        val hasArabic = Regex("[\\u0600-\\u06FF]").containsMatchIn(text)
        val translator = if (hasArabic) arToEn else enToAr
        val conditions = DownloadConditions.Builder().build()

        translator.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                modelsReady = true
                translator.translate(text)
                    .addOnSuccessListener { translated ->
                        output = translated.trim()
                        busy = false
                    }
                    .addOnFailureListener {
                        busy = false
                        error = "تعذر إكمال الترجمة. جرّب مرة ثانية."
                    }
            }
            .addOnFailureListener {
                busy = false
                error = "أول استخدام يحتاج إنترنت لتنزيل نموذج العربية والإنجليزية؛ بعدها تعمل بدون نت."
            }
    }

    val inputHasArabic = Regex("[\\u0600-\\u06FF]").containsMatchIn(input)
    val englishForSpeech = when {
        output.isBlank() -> ""
        inputHasArabic -> output
        else -> input.trim()
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        StudentOutlinedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Translate, null, tint = StudentBlue, modifier = Modifier.size(28.dp))
                    Text("الترجمة", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                }
                Text("عربي ⇄ English • مجانية • تعمل بدون إنترنت بعد تنزيل النموذج لأول مرة", color = StudentMuted)
                when {
                    preparing -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text("جارِ تجهيز الترجمة للاستخدام بدون نت...", color = StudentMuted)
                    }
                    modelsReady -> Text("✓ الترجمة Offline جاهزة", color = Color(0xFF16834A), fontWeight = FontWeight.Bold)
                }
            }
        }

        OutlinedTextField(
            value = input,
            onValueChange = { input = it.take(5000) },
            modifier = Modifier.fillMaxWidth(),
            minLines = 4,
            maxLines = 8,
            label = { Text("النص") },
            placeholder = { Text("اكتب بالعربي أو بالإنجليزي...") },
            trailingIcon = {
                if (input.isNotBlank()) IconButton(onClick = { input = ""; output = "" }) {
                    Icon(Icons.Rounded.Close, "مسح")
                }
            }
        )

        Button(
            onClick = ::translateNow,
            enabled = input.isNotBlank() && !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = StudentBlue),
            shape = RoundedCornerShape(16.dp)
        ) {
            if (busy) {
                CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                Icon(Icons.Rounded.Translate, null)
                Spacer(Modifier.width(7.dp))
                Text("ترجم", fontWeight = FontWeight.Black)
            }
        }

        if (output.isNotBlank()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F3FC)),
                border = BorderStroke(1.dp, Color(0xFFE6DDF5))
            ) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الترجمة", color = StudentMuted, style = MaterialTheme.typography.labelLarge)
                    Text(output, style = MaterialTheme.typography.bodyLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clipboard.setText(AnnotatedString(output)) }) {
                            Icon(Icons.Rounded.ContentCopy, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("نسخ")
                        }
                        OutlinedButton(onClick = {
                            val old = input
                            input = output
                            output = old
                        }) {
                            Icon(Icons.Rounded.SwapVert, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("عكس")
                        }
                    }
                }
            }
        }

        StudentOutlinedCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("النطق الإنجليزي", fontWeight = FontWeight.Black)
                Text("اختَر اللكنة والسرعة ثم اضغط تشغيل.", color = StudentMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = accent == "american", onClick = { accent = "american" }, label = { Text("American") })
                    FilterChip(selected = accent == "british", onClick = { accent = "british" }, label = { Text("British") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = speed == "slow", onClick = { speed = "slow" }, label = { Text("بطيء") })
                    FilterChip(selected = speed == "normal", onClick = { speed = "normal" }, label = { Text("طبيعي") })
                    FilterChip(selected = speed == "fast", onClick = { speed = "fast" }, label = { Text("سريع") })
                }
                Button(
                    onClick = {
                        if (englishForSpeech.isBlank()) {
                            error = "ترجم نصًا أولًا حتى يظهر النطق الإنجليزي."
                        } else if (!speech.speak(englishForSpeech, accent, speed)) {
                            error = "صوت English ${if (accent == "british") "UK" else "US"} غير مثبت على الجهاز. نزّله من إعدادات تحويل النص إلى كلام."
                        }
                    },
                    enabled = englishForSpeech.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF24252A)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.VolumeUp, null)
                    Spacer(Modifier.width(6.dp))
                    Text("تشغيل النطق")
                }
            }
        }

        error?.let {
            Surface(color = Color(0xFFFFF1F2), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text(it, color = Color(0xFFB42318), modifier = Modifier.padding(11.dp))
            }
        }
    }
}
