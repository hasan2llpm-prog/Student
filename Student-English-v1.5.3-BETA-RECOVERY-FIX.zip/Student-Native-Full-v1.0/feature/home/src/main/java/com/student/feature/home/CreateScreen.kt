package com.student.feature.home

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.student.core.data.OfflineStore
import com.student.core.data.StudentSession
import com.student.core.data.SupabaseApi
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CreateScreen(api: SupabaseApi, session: StudentSession, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val offline = remember { OfflineStore(context) }
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("post") }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedMime by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(2800); message = null } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedUri = uri
        selectedMime = uri?.let { context.contentResolver.getType(it) }
    }

    fun publish() {
        if (text.isBlank() && selectedUri == null) return
        scope.launch {
            busy = true
            message = null
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    var mediaUrl: String? = null
                    var mediaType = "text"
                    selectedUri?.let { uri ->
                        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("تعذر قراءة الملف.")
                        if (bytes.size > 20 * 1024 * 1024) throw IllegalStateException("حجم الملف الأقصى 20MB.")
                        val mime = selectedMime ?: "application/octet-stream"
                        mediaType = when {
                            mime.startsWith("image/") -> "image"
                            mime.startsWith("video/") -> "video"
                            else -> "file"
                        }
                        val ext = when (mediaType) { "image" -> "jpg"; "video" -> "mp4"; else -> "bin" }
                        val bucket = if (target == "story") "stories" else "stories"
                        val path = "${session.userId}/${System.currentTimeMillis()}_native.$ext"
                        mediaUrl = api.uploadObject(session, bucket, path, bytes, mime).getOrThrow()
                    }
                    if (target == "story") {
                        api.createStory(session, text.trim(), mediaUrl, if (mediaUrl == null) "text" else mediaType).getOrThrow()
                    } else {
                        if (mediaType == "video") throw IllegalStateException("المنشورات الحالية تدعم النص والصورة. الفيديو متاح في الرسائل/القصص.")
                        api.createPost(session, text.trim(), mediaUrl).getOrThrow()
                    }
                }
            }
            result.onSuccess {
                text = ""
                selectedUri = null
                selectedMime = null
                message = "تم النشر بنجاح."
                onDone()
            }.onFailure { err ->
                if (selectedUri == null && text.isNotBlank()) {
                    offline.enqueue(if (target == "story") "story_text" else "post_text", JSONObject().put("content", text.trim()))
                    message = "لا يوجد اتصال. تم حفظ النص وسيُنشر تلقائيًا عند رجوع الإنترنت."
                    text = ""
                } else {
                    message = err.message ?: "تعذر النشر."
                }
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().imePadding().navigationBarsPadding().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("إنشاء محتوى", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = target == "post", onClick = { target = "post" }, label = { Text("منشور") })
            FilterChip(selected = target == "story", onClick = { target = "story" }, label = { Text("قصة") })
        }
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text(if (target == "story") "نص القصة" else "ماذا تريد أن تنشر؟") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
            enabled = !busy
        )
        OutlinedButton(onClick = { picker.launch(if (target == "story") "*/*" else "image/*") }, enabled = !busy) {
            Text(if (selectedUri == null) "اختيار ${if (target == "story") "صورة/فيديو" else "صورة"}" else "تم اختيار ملف — تغييره")
        }
        selectedMime?.let { Text("نوع الملف: $it", style = MaterialTheme.typography.bodySmall) }
        message?.let { Text(it, color = if (it.startsWith("تم")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
        Button(
            onClick = { publish() },
            enabled = !busy && (text.isNotBlank() || selectedUri != null),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text("نشر الآن")
        }
    }
}
