package com.student.feature.home

import androidx.compose.runtime.staticCompositionLocalOf
import com.student.core.data.NativeRemoteConfig

val LocalNativeRemoteConfig = staticCompositionLocalOf { NativeRemoteConfig.EMPTY }
