Deploy this file over the existing Supabase Edge Function named send-push.
It keeps the existing web push behavior, adds explicit high-priority Android FCM delivery, and excludes actor/self notifications.
No OpenAI key is required. Existing FIREBASE_PROJECT_ID and FIREBASE_SERVICE_ACCOUNT_JSON secrets remain required.
