# Student Final Admin Release

- Full admin store management: products, tasks, diamond packages.
- Admin order/diamond/agency review remains enabled.
- Manual diamond credit/debit by username through secure admin RPC.
- Instant admin notifications for new store, diamond, agency and agent-stock requests.
- FCM carries unread_count and Android notification badge number.
- Database migration: supabase/migrations/20260824_student_admin_store_control.sql
- Updated send-push function: supabase/functions/send-push/index.ts

Backend migration and send-push deployment must be applied before functional QA.
