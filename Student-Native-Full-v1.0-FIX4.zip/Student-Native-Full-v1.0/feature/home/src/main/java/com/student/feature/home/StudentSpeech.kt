package com.student.feature.home

import android.speech.tts.TextToSpeech
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

class StudentSpeechController(context: android.content.Context) {
    private var engine: TextToSpeech? = null
    private var ready = false

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
    }

    fun speak(text: String, accent: String, slow: Boolean): Boolean {
        if (!ready || text.isBlank()) return false
        val locale = if (accent.equals("british", true)) Locale.UK else Locale.US
        val result = engine?.setLanguage(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) return false
        engine?.setSpeechRate(if (slow) 0.62f else 1.0f)
        engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "student-${System.nanoTime()}")
        return true
    }

    fun stop() { engine?.stop() }
    fun shutdown() { engine?.stop(); engine?.shutdown(); engine = null; ready = false }
}

@Composable
fun rememberStudentSpeechController(): StudentSpeechController {
    val context = LocalContext.current
    val controller = remember(context) { StudentSpeechController(context) }
    DisposableEffect(controller) { onDispose { controller.shutdown() } }
    return controller
}
