package com.student.feature.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class StudentRoute {
    HOME, SEARCH, CREATE, SAVED, MENU,
    PROFILE, MESSAGES, NOTIFICATIONS, EDUCATION, STORE, ADMIN, SETTINGS, STORIES,
    STUDENT_AI, LEARN_ENGLISH, SUGGESTIONS, TEACHER_PORTAL
}

@Composable
fun HomeScreen(
    api: SupabaseApi,
    session: StudentSession,
    profile: StudentProfile?,
    loadingProfile: Boolean,
    offlineMode: Boolean,
    rootMessage: String?,
    onProfileChanged: (StudentProfile) -> Unit,
    onRefreshProfile: () -> Unit,
    onLogout: () -> Unit,
    onExitApp: () -> Unit
) {
    val backStack = remember { mutableStateListOf(StudentRoute.HOME) }
    var showExitConfirm by remember { mutableStateOf(false) }
    var unreadCount by remember { mutableIntStateOf(0) }
    val route = backStack.lastOrNull() ?: StudentRoute.HOME

    fun navigate(destination: StudentRoute) {
        if (backStack.lastOrNull() != destination) backStack.add(destination)
    }

    fun selectRoot(destination: StudentRoute) {
        backStack.clear()
        backStack.add(StudentRoute.HOME)
        if (destination != StudentRoute.HOME) backStack.add(destination)
    }

    fun goBack() {
        if (backStack.size > 1) backStack.removeAt(backStack.lastIndex)
        else showExitConfirm = true
    }

    LaunchedEffect(route, session.userId) {
        unreadCount = withContext(Dispatchers.IO) { api.unreadNotificationCount(session).getOrDefault(unreadCount) }
    }

    BackHandler { goBack() }

    if (showExitConfirm) {
        AlertDialog(
            onDismissRequest = { showExitConfirm = false },
            title = { Text("الخروج من Student", fontWeight = FontWeight.Bold) },
            text = { Text("هل تريد الخروج من Student؟") },
            confirmButton = { Button(onClick = { showExitConfirm = false; onExitApp() }) { Text("خروج") } },
            dismissButton = { TextButton(onClick = { showExitConfirm = false }) { Text("إلغاء") } }
        )
    }

    val title = when (route) {
        StudentRoute.HOME -> "Student"
        StudentRoute.SEARCH -> "البحث"
        StudentRoute.CREATE -> "إضافة"
        StudentRoute.SAVED -> "المحفوظات"
        StudentRoute.MENU -> "القائمة"
        StudentRoute.PROFILE -> "الملف الشخصي"
        StudentRoute.MESSAGES -> "الرسائل"
        StudentRoute.NOTIFICATIONS -> "الإشعارات"
        StudentRoute.EDUCATION -> "التعليم"
        StudentRoute.STORE -> "المتجر"
        StudentRoute.ADMIN -> "لوحة الأدمن"
        StudentRoute.SETTINGS -> "الإعدادات"
        StudentRoute.STORIES -> "القصص"
        StudentRoute.STUDENT_AI -> "Student AI"
        StudentRoute.LEARN_ENGLISH -> "Learn English"
        StudentRoute.SUGGESTIONS -> "الاقتراحات"
        StudentRoute.TEACHER_PORTAL -> "نظام المدرس"
    }

    Scaffold(
        containerColor = Color.White,
        topBar = {
            StudentNativeTopBar(
                title = title,
                home = route == StudentRoute.HOME,
                canGoBack = backStack.size > 1 && route !in listOf(StudentRoute.SEARCH, StudentRoute.CREATE, StudentRoute.SAVED, StudentRoute.MENU),
                unreadCount = unreadCount,
                onBack = ::goBack,
                onNotifications = { navigate(StudentRoute.NOTIFICATIONS) },
                onMenu = { selectRoot(StudentRoute.MENU) }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
                StudentBottomItem(Icons.Rounded.Home, "الرئيسية", route == StudentRoute.HOME) { selectRoot(StudentRoute.HOME) }
                StudentBottomItem(Icons.Rounded.Search, "البحث", route == StudentRoute.SEARCH) { selectRoot(StudentRoute.SEARCH) }
                StudentBottomItem(Icons.Rounded.AddCircle, "إضافة", route == StudentRoute.CREATE) { selectRoot(StudentRoute.CREATE) }
                StudentBottomItem(Icons.Rounded.Bookmark, "المحفوظات", route == StudentRoute.SAVED) { selectRoot(StudentRoute.SAVED) }
                StudentBottomItem(Icons.Rounded.Menu, "القائمة", route == StudentRoute.MENU) { selectRoot(StudentRoute.MENU) }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Color.White)) {
            if (offlineMode) {
                Surface(color = Color(0xFFFFF5DF), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "وضع Offline — يتم عرض آخر بيانات محفوظة وستتم المزامنة عند عودة الإنترنت",
                        Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = Color(0xFF8A5A0A), fontSize = 12.sp
                    )
                }
            }
            rootMessage?.takeIf { it.isNotBlank() && !offlineMode }?.let {
                Surface(color = StudentSoft, modifier = Modifier.fillMaxWidth()) {
                    Text(it, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = StudentMuted, fontSize = 12.sp)
                }
            }
            Box(Modifier.fillMaxSize()) {
                when (route) {
                    StudentRoute.HOME -> FeedScreen(
                        api, session, profile,
                        onOpenStories = { navigate(StudentRoute.STORIES) },
                        onOpenProfile = { navigate(StudentRoute.PROFILE) },
                        onOpenEducation = { navigate(StudentRoute.EDUCATION) },
                        onOpenStudentAi = { navigate(StudentRoute.STUDENT_AI) },
                        onOpenLearnEnglish = { navigate(StudentRoute.LEARN_ENGLISH) }
                    )
                    StudentRoute.SEARCH -> SearchScreen(api, session, onOpenMessages = { navigate(StudentRoute.MESSAGES) })
                    StudentRoute.CREATE -> CreateScreen(api, session, onDone = { selectRoot(StudentRoute.HOME) })
                    StudentRoute.SAVED -> SavedScreen(api, session)
                    StudentRoute.MENU -> MenuScreen(
                        profile = profile,
                        onProfile = { navigate(StudentRoute.PROFILE) },
                        onMessages = { navigate(StudentRoute.MESSAGES) },
                        onEducation = { navigate(StudentRoute.EDUCATION) },
                        onStudentAi = { navigate(StudentRoute.STUDENT_AI) },
                        onLearnEnglish = { navigate(StudentRoute.LEARN_ENGLISH) },
                        onTeacherPortal = { navigate(StudentRoute.TEACHER_PORTAL) },
                        onSuggestions = { navigate(StudentRoute.SUGGESTIONS) },
                        onStore = { navigate(StudentRoute.STORE) },
                        onNotifications = { navigate(StudentRoute.NOTIFICATIONS) },
                        onAdmin = { navigate(StudentRoute.ADMIN) },
                        onSettings = { navigate(StudentRoute.SETTINGS) },
                        onLogout = onLogout
                    )
                    StudentRoute.PROFILE -> ProfileScreen(api, session, profile, loadingProfile, onProfileChanged, onRefreshProfile)
                    StudentRoute.MESSAGES -> MessagesScreen(api, session)
                    StudentRoute.NOTIFICATIONS -> NotificationsScreen(api, session)
                    StudentRoute.EDUCATION -> EducationScreen(api, session)
                    StudentRoute.STORE -> StoreScreen(api, session, onProfileRefresh = onRefreshProfile)
                    StudentRoute.ADMIN -> AdminScreen(api, session, profile)
                    StudentRoute.SETTINGS -> SettingsScreen(profile, offlineMode, onRefreshProfile, onLogout)
                    StudentRoute.STORIES -> StoriesScreen(api, session)
                    StudentRoute.STUDENT_AI -> StudentAiScreen(api, session)
                    StudentRoute.LEARN_ENGLISH -> LearnEnglishScreen(api, session)
                    StudentRoute.SUGGESTIONS -> SuggestionsScreen(api, session)
                    StudentRoute.TEACHER_PORTAL -> TeacherPortalScreen(api, session, profile)
                }
            }
        }
    }
}

@Composable
private fun StudentNativeTopBar(
    title: String,
    home: Boolean,
    canGoBack: Boolean,
    unreadCount: Int,
    onBack: () -> Unit,
    onNotifications: () -> Unit,
    onMenu: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(color = Color.White, shadowElevation = 0.dp) {
            Column {
                Box(Modifier.fillMaxWidth().height(62.dp).padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
                    BadgedBox(
                        badge = {
                            if (unreadCount > 0) Badge(containerColor = StudentBlue) { Text(if (unreadCount > 99) "99+" else unreadCount.toString(), color = Color.White) }
                        },
                        modifier = Modifier.align(Alignment.CenterStart)
                    ) {
                        IconButton(onClick = onNotifications) { Icon(Icons.Rounded.Notifications, "الإشعارات", tint = StudentText) }
                    }
                    if (home) StudentLogo() else Text(title, color = StudentText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = if (canGoBack) onBack else onMenu, modifier = Modifier.align(Alignment.CenterEnd)) {
                        Icon(if (canGoBack) Icons.Rounded.ArrowBack else Icons.Rounded.Menu, if (canGoBack) "رجوع" else "القائمة", tint = StudentText)
                    }
                }
                HorizontalDivider(color = StudentBorder.copy(alpha = 0.8f))
            }
        }
    }
}

@Composable
private fun RowScope.StudentBottomItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, label) },
        label = { Text(label, maxLines = 1, fontSize = 10.sp) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = StudentBlue,
            selectedTextColor = StudentBlue,
            indicatorColor = Color(0xFFF0E7FF),
            unselectedIconColor = StudentText,
            unselectedTextColor = StudentText
        )
    )
}
