package com.student.feature.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.student.core.data.StudentSession
import com.student.core.data.StudentSuggestion
import com.student.core.data.SupabaseApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SuggestionsScreen(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("اقتراح") }
    var history by remember { mutableStateOf<List<StudentSuggestion>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun refresh() { scope.launch { history = withContext(Dispatchers.IO) { api.mySuggestions(session).getOrDefault(emptyList()) } } }
    LaunchedEffect(session.userId) { refresh() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("أرسل اقتراحك للإدارة", fontWeight = FontWeight.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("اقتراح", "مشكلة", "ميزة").forEach { value ->
                            FilterChip(selected = category == value, onClick = { category = value }, label = { Text(value) })
                        }
                    }
                    OutlinedTextField(title, { title = it.take(120) }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(body, { body = it.take(2000) }, label = { Text("التفاصيل") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                    Button(
                        onClick = {
                            if (title.isBlank() || body.isBlank() || busy) return@Button
                            scope.launch {
                                busy = true; message = null
                                val r = withContext(Dispatchers.IO) { api.submitSuggestion(session, category, title.trim(), body.trim()) }
                                r.onSuccess { title = ""; body = ""; message = "تم إرسال الاقتراح للإدارة."; refresh() }
                                    .onFailure { message = it.message }
                                busy = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = StudentBlue)
                    ) { Text(if (busy) "جارٍ الإرسال..." else "إرسال") }
                    message?.let { Text(it, color = if (it.startsWith("تم")) Color(0xFF16803C) else MaterialTheme.colorScheme.error) }
                }
            }
        }
        if (history.isNotEmpty()) item { Text("اقتراحاتي السابقة", fontWeight = FontWeight.Bold) }
        items(history, key = { it.id }) { item ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(item.title, fontWeight = FontWeight.Bold)
                    Text(item.body, color = StudentMuted)
                    Text("الحالة: ${statusLabel(item.status)}", color = StudentBlue, style = MaterialTheme.typography.labelMedium)
                    item.adminNote?.takeIf { it.isNotBlank() }?.let { Text("رد الإدارة: $it", color = StudentText) }
                }
            }
        }
    }
}

private fun statusLabel(status: String) = when (status.lowercase()) {
    "pending" -> "قيد المراجعة"
    "reviewed" -> "تمت المراجعة"
    "accepted" -> "مقبول"
    "closed" -> "مغلق"
    else -> status
}
