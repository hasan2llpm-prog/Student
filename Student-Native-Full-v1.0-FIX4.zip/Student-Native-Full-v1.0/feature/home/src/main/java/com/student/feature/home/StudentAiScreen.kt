package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.student.core.data.AiChatItem
import com.student.core.data.StudentSession
import com.student.core.data.SupabaseApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StudentAiScreen(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val speech = rememberStudentSpeechController()
    var mode by remember { mutableStateOf("ask") }
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf<List<AiChatItem>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var accent by remember { mutableStateOf("american") }
    var slow by remember { mutableStateOf(false) }
    var lastEnglish by remember { mutableStateOf("") }

    LaunchedEffect(session.userId) {
        messages = withContext(Dispatchers.IO) { api.aiHistory(session).getOrDefault(emptyList()) }
    }

    fun send() {
        val text = input.trim()
        if (text.isBlank() || busy) return
        input = ""
        error = null
        val userMessage = AiChatItem("local-u-${System.nanoTime()}", "user", text, mode)
        messages = messages + userMessage
        scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) {
                api.saveAiMessage(session, "user", text, mode)
                api.callStudentAi(session, mode, text)
            }
            result.onSuccess { answer ->
                val reply = AiChatItem("local-a-${System.nanoTime()}", "assistant", answer, mode)
                messages = messages + reply
                if (mode == "translate") {
                    val arabicRegex = Regex("[\u0600-\u06FF]")
                    lastEnglish = if (arabicRegex.containsMatchIn(answer)) text else answer
                }
                withContext(Dispatchers.IO) { api.saveAiMessage(session, "assistant", answer, mode) }
            }.onFailure {
                error = when {
                    (it.message ?: "").contains("Unable to resolve host", true) -> "لا يوجد اتصال بالإنترنت. لم يتم إنشاء إجابة وهمية."
                    else -> it.message ?: "خدمة Student AI غير متاحة حاليًا."
                }
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = if (mode == "ask") 0 else 1, containerColor = Color.White, contentColor = StudentBlue) {
            Tab(selected = mode == "ask", onClick = { mode = "ask" }, text = { Text("اسأل AI") }, icon = { Icon(Icons.Rounded.AutoAwesome, null) })
            Tab(selected = mode == "translate", onClick = { mode = "translate" }, text = { Text("الترجمة") }, icon = { Icon(Icons.Rounded.Translate, null) })
        }

        if (mode == "translate") {
            Surface(color = StudentSoft, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ترجمة ذكية عربي ⇄ إنجليزي حسب المعنى والسياق", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilterChip(selected = accent == "american", onClick = { accent = "american" }, label = { Text("American") })
                        FilterChip(selected = accent == "british", onClick = { accent = "british" }, label = { Text("British") })
                        FilterChip(selected = slow, onClick = { slow = !slow }, label = { Text(if (slow) "بطيء" else "طبيعي") })
                    }
                    if (lastEnglish.isNotBlank()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(lastEnglish)) }) {
                                Icon(Icons.Rounded.ContentCopy, null); Spacer(Modifier.width(5.dp)); Text("نسخ")
                            }
                            OutlinedButton(onClick = { if (!speech.speak(lastEnglish, accent, slow)) error = "محرك النطق الإنجليزي غير متاح على الجهاز." }) {
                                Icon(Icons.Rounded.VolumeUp, null); Spacer(Modifier.width(5.dp)); Text("نطق")
                            }
                            IconButton(onClick = { speech.speak(lastEnglish, accent, slow) }) { Icon(Icons.Rounded.Replay, "إعادة النطق") }
                        }
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    StudentOutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = StudentBlue, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("Student AI", fontWeight = FontWeight.Black)
                            Text("اكتب سؤالك أو استخدم الترجمة الذكية.", color = StudentMuted)
                        }
                    }
                }
            }
            items(messages, key = { it.id }) { message ->
                val mine = message.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                    Surface(
                        color = if (mine) StudentBlue else Color(0xFFF4F1FA),
                        contentColor = if (mine) Color.White else StudentText,
                        shape = RoundedCornerShape(16.dp),
                        border = if (mine) null else BorderStroke(1.dp, Color(0xFFE6DDF5)),
                        modifier = Modifier.widthIn(max = 330.dp)
                    ) {
                        Column(Modifier.padding(horizontal = 13.dp, vertical = 10.dp)) {
                            Text(message.content)
                            if (!mine) {
                                TextButton(onClick = { clipboard.setText(AnnotatedString(message.content)) }, contentPadding = PaddingValues(0.dp)) {
                                    Icon(Icons.Rounded.ContentCopy, null, Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text("نسخ")
                                }
                            }
                        }
                    }
                }
            }
            if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudentBlue) }
            error?.let { msg -> item { Text(msg, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(4.dp)) } }
        }

        Surface(shadowElevation = 5.dp, color = Color.White) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(4000) },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(if (mode == "ask") "اسأل Student AI..." else "اكتب النص للترجمة...") },
                    minLines = 1,
                    maxLines = 5
                )
                FilledIconButton(onClick = ::send, enabled = input.isNotBlank() && !busy, colors = IconButtonDefaults.filledIconButtonColors(containerColor = StudentBlue)) {
                    Icon(Icons.Rounded.Send, "إرسال", tint = Color.White)
                }
            }
        }
    }
}
