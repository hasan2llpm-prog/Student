package com.student.feature.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun EducationScreen(api: SupabaseApi, session: StudentSession) {
    var mode by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = mode) {
            Tab(selected = mode == 0, onClick = { mode = 0 }, text = { Text("المدارس") })
            Tab(selected = mode == 1, onClick = { mode = 1 }, text = { Text("الجامعات") })
        }
        if (mode == 0) SchoolEducationPanel(api, session) else UniversityEducationPanel(api, session)
    }
}

@Composable
private fun SchoolEducationPanel(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    val offline = remember { OfflineStore(LocalContext.current) }
    var stages by remember { mutableStateOf(offline.loadEducationStages()) }
    var levels by remember { mutableStateOf<List<EducationLevel>>(emptyList()) }
    var subjects by remember { mutableStateOf<List<EducationSubject>>(emptyList()) }
    var materials by remember { mutableStateOf<List<EducationMaterial>>(emptyList()) }
    var stage by remember { mutableStateOf<EducationStage?>(null) }
    var level by remember { mutableStateOf<EducationLevel?>(null) }
    var subject by remember { mutableStateOf<EducationSubject?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun loadStages() {
        scope.launch {
            loading = true
            val r = withContext(Dispatchers.IO) { api.educationStages(session) }
            r.onSuccess {
                stages = it.filter { x -> x.slug != "university" }
                offline.saveEducationStages(stages)
            }.onFailure { if (stages.isEmpty()) error = it.message else error = "Offline: يتم عرض المراحل المحفوظة." }
            loading = false
        }
    }
    LaunchedEffect(Unit) { loadStages() }

    BackHandler(enabled = subject != null || level != null || stage != null) {
        when {
            subject != null -> { subject = null; materials = emptyList() }
            level != null -> { level = null; subjects = emptyList() }
            stage != null -> { stage = null; levels = emptyList() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
        when {
            subject != null -> {
                EducationBackHeader("المواد", subject!!.name) { subject = null; materials = emptyList() }
                MaterialList(materials, loading, uri)
            }
            level != null -> {
                EducationBackHeader("الصفوف", level!!.name) { level = null; subjects = emptyList() }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(subjects, key = { it.id }) { s ->
                        EducationCard(s.name, s.description) {
                            subject = s
                            materials = offline.loadEducationMaterials("school_${s.id}")
                            scope.launch {
                                loading = true
                                val r = withContext(Dispatchers.IO) { api.educationMaterials(session, s.id) }
                                r.onSuccess { materials = it; offline.saveEducationMaterials("school_${s.id}", it) }.onFailure { if (materials.isEmpty()) error = it.message else error = "Offline: يتم عرض الدروس المحفوظة." }
                                loading = false
                            }
                        }
                    }
                    if (subjects.isEmpty() && !loading) item { Text("لا توجد مواد مرتبطة بهذا الصف.") }
                }
            }
            stage != null -> {
                EducationBackHeader("المراحل", stage!!.name) { stage = null; levels = emptyList() }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(levels, key = { it.id }) { l ->
                        EducationCard(l.name, "") {
                            level = l
                            subjects = offline.loadEducationSubjects("school_${l.id}")
                            scope.launch {
                                loading = true
                                val r = withContext(Dispatchers.IO) { api.educationSubjects(session, l.id) }
                                r.onSuccess { subjects = it; offline.saveEducationSubjects("school_${l.id}", it) }.onFailure { if (subjects.isEmpty()) error = it.message else error = "Offline: يتم عرض المواد المحفوظة." }
                                loading = false
                            }
                        }
                    }
                }
            }
            else -> {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("المراحل الدراسية", style = MaterialTheme.typography.headlineSmall)
                    TextButton(onClick = { loadStages() }) { Text("تحديث") }
                }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(stages, key = { it.id }) { s ->
                        EducationCard(s.name, s.description) {
                            stage = s
                            levels = offline.loadEducationLevels(s.id)
                            scope.launch {
                                loading = true
                                val r = withContext(Dispatchers.IO) { api.educationLevels(session, s.id) }
                                r.onSuccess { levels = it; offline.saveEducationLevels(s.id, it) }.onFailure { if (levels.isEmpty()) error = it.message else error = "Offline: يتم عرض الصفوف المحفوظة." }
                                loading = false
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UniversityEducationPanel(api: SupabaseApi, session: StudentSession) {
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current
    val offline = remember { OfflineStore(LocalContext.current) }
    var universities by remember { mutableStateOf(offline.loadUniversityNodes("universities")) }
    var colleges by remember { mutableStateOf<List<UniversityNode>>(emptyList()) }
    var departments by remember { mutableStateOf<List<UniversityNode>>(emptyList()) }
    var levels by remember { mutableStateOf<List<UniversityNode>>(emptyList()) }
    var subjects by remember { mutableStateOf<List<EducationSubject>>(emptyList()) }
    var materials by remember { mutableStateOf<List<EducationMaterial>>(emptyList()) }
    var university by remember { mutableStateOf<UniversityNode?>(null) }
    var college by remember { mutableStateOf<UniversityNode?>(null) }
    var department by remember { mutableStateOf<UniversityNode?>(null) }
    var level by remember { mutableStateOf<UniversityNode?>(null) }
    var subject by remember { mutableStateOf<EducationSubject?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun loadRoot() {
        scope.launch {
            loading = true
            val r = withContext(Dispatchers.IO) { api.universities(session) }
            r.onSuccess { universities = it; offline.saveUniversityNodes("universities", it) }.onFailure { if (universities.isEmpty()) error = it.message else error = "Offline: يتم عرض الجامعات المحفوظة." }
            loading = false
        }
    }
    LaunchedEffect(Unit) { loadRoot() }

    BackHandler(enabled = subject != null || level != null || department != null || college != null || university != null) {
        when {
            subject != null -> { subject = null; materials = emptyList() }
            level != null -> { level = null; subjects = emptyList() }
            department != null -> { department = null; levels = emptyList() }
            college != null -> { college = null; departments = emptyList() }
            university != null -> { university = null; colleges = emptyList() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp)) }
        when {
            subject != null -> {
                EducationBackHeader("المواد", subject!!.name) { subject = null; materials = emptyList() }
                MaterialList(materials, loading, uri)
            }
            level != null -> {
                EducationBackHeader("المراحل", level!!.name) { level = null; subjects = emptyList() }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(subjects, key = { it.id }) { s ->
                        EducationCard(s.name, s.description) {
                            subject = s
                            val levelId = level!!.id
                            materials = offline.loadEducationMaterials("university_${levelId}_${s.id}")
                            scope.launch {
                                loading = true
                                val r = withContext(Dispatchers.IO) { api.universityMaterials(session, levelId, s.id) }
                                r.onSuccess { materials = it; offline.saveEducationMaterials("university_${levelId}_${s.id}", it) }.onFailure { if (materials.isEmpty()) error = it.message else error = "Offline: يتم عرض الدروس المحفوظة." }
                                loading = false
                            }
                        }
                    }
                }
            }
            department != null -> {
                EducationBackHeader("الأقسام", department!!.name) { department = null; levels = emptyList() }
                NodeList(levels) { node ->
                    level = node
                    subjects = offline.loadEducationSubjects("uni_subjects_${node.id}")
                    scope.launch {
                        loading = true
                        val r = withContext(Dispatchers.IO) { api.universitySubjects(session, node.id) }
                        r.onSuccess { subjects = it; offline.saveEducationSubjects("uni_subjects_${node.id}", it) }.onFailure { if (subjects.isEmpty()) error = it.message else error = "Offline: يتم عرض آخر بيانات محفوظة." }
                        loading = false
                    }
                }
            }
            college != null -> {
                EducationBackHeader("الكليات", college!!.name) { college = null; departments = emptyList() }
                NodeList(departments) { node ->
                    department = node
                    levels = offline.loadUniversityNodes("levels_${node.id}")
                    scope.launch {
                        loading = true
                        val r = withContext(Dispatchers.IO) { api.universityLevels(session, node.id) }
                        r.onSuccess { levels = it; offline.saveUniversityNodes("levels_${node.id}", it) }.onFailure { if (levels.isEmpty()) error = it.message else error = "Offline: يتم عرض آخر بيانات محفوظة." }
                        loading = false
                    }
                }
            }
            university != null -> {
                EducationBackHeader("الجامعات", university!!.name) { university = null; colleges = emptyList() }
                NodeList(colleges) { node ->
                    college = node
                    departments = offline.loadUniversityNodes("departments_${node.id}")
                    scope.launch {
                        loading = true
                        val r = withContext(Dispatchers.IO) { api.universityDepartments(session, node.id) }
                        r.onSuccess { departments = it; offline.saveUniversityNodes("departments_${node.id}", it) }.onFailure { if (departments.isEmpty()) error = it.message else error = "Offline: يتم عرض آخر بيانات محفوظة." }
                        loading = false
                    }
                }
            }
            else -> {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("الجامعات", style = MaterialTheme.typography.headlineSmall)
                    TextButton(onClick = { loadRoot() }) { Text("تحديث") }
                }
                NodeList(universities) { node ->
                    university = node
                    colleges = offline.loadUniversityNodes("colleges_${node.id}")
                    scope.launch {
                        loading = true
                        val r = withContext(Dispatchers.IO) { api.universityColleges(session, node.id) }
                        r.onSuccess { colleges = it; offline.saveUniversityNodes("colleges_${node.id}", it) }.onFailure { if (colleges.isEmpty()) error = it.message else error = "Offline: يتم عرض آخر بيانات محفوظة." }
                        loading = false
                    }
                }
            }
        }
    }
}

@Composable
private fun EducationBackHeader(back: String, title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "رجوع") }
        Column {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(back, style = MaterialTheme.typography.labelSmall, color = StudentMuted)
        }
    }
}

@Composable
private fun EducationCard(title: String, description: String, onClick: () -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (description.isNotBlank()) Text(description, maxLines = 2)
        }
    }
}

@Composable
private fun NodeList(nodes: List<UniversityNode>, onClick: (UniversityNode) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(nodes, key = { it.id }) { node -> EducationCard(node.name, node.description) { onClick(node) } }
        if (nodes.isEmpty()) item { Text("لا توجد بيانات مفعلة هنا بعد.") }
    }
}

@Composable
private fun MaterialList(materials: List<EducationMaterial>, loading: Boolean, uri: androidx.compose.ui.platform.UriHandler) {
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(materials, key = { it.id }) { m ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(m.title, style = MaterialTheme.typography.titleMedium)
                    if (m.description.isNotBlank()) Text(m.description)
                    Text("النوع: ${m.materialType}", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        m.fileUrl?.let { url -> TextButton(onClick = { runCatching { uri.openUri(url) } }) { Text("فتح الملف") } }
                        m.externalUrl?.let { url -> TextButton(onClick = { runCatching { uri.openUri(url) } }) { Text("فتح الرابط") } }
                    }
                }
            }
        }
        if (materials.isEmpty() && !loading) item { Text("لا يوجد محتوى منشور لهذه المادة.") }
    }
}
