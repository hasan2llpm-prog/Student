package com.student.feature.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class AdminStoreAction(
    val kind: String,
    val id: String,
    val approve: Boolean? = null,
    val status: String? = null,
    val title: String,
    val message: String
)

@Composable
fun AdminOperationsPane(api: SupabaseApi, session: StudentSession, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var section by remember { mutableIntStateOf(0) }
    var teachers by remember { mutableStateOf<List<TeacherRequest>>(emptyList()) }
    var ads by remember { mutableStateOf<List<HomeAd>>(emptyList()) }
    var suggestions by remember { mutableStateOf<List<StudentSuggestion>>(emptyList()) }
    var storeOrders by remember { mutableStateOf<List<AdminStoreOrder>>(emptyList()) }
    var diamondRequests by remember { mutableStateOf<List<DiamondPurchaseRequest>>(emptyList()) }
    var agencyApplications by remember { mutableStateOf<List<AgencyApplication>>(emptyList()) }
    var wallets by remember { mutableStateOf<List<AdminWalletRow>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var reviewTeacher by remember { mutableStateOf<Pair<TeacherRequest, Boolean>?>(null) }
    var deleteAd by remember { mutableStateOf<HomeAd?>(null) }
    var reviewSuggestion by remember { mutableStateOf<StudentSuggestion?>(null) }
    var storeAction by remember { mutableStateOf<AdminStoreAction?>(null) }
    var note by remember { mutableStateOf("") }
    var storeNote by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch {
            busy = true
            val t = withContext(Dispatchers.IO) { api.adminTeacherRequests(session) }
            val a = withContext(Dispatchers.IO) { api.adminHomeAds(session) }
            val s = withContext(Dispatchers.IO) { api.adminSuggestions(session) }
            t.onSuccess { teachers = it }
            a.onSuccess { ads = it }
            s.onSuccess { suggestions = it }
            busy = false
        }
    }

    fun refreshStore() {
        scope.launch {
            busy = true
            val o = withContext(Dispatchers.IO) { api.adminStoreOrders(session) }
            val d = withContext(Dispatchers.IO) { api.adminDiamondPurchaseRequests(session) }
            val a = withContext(Dispatchers.IO) { api.adminAgencyApplications(session) }
            val w = withContext(Dispatchers.IO) { api.adminWallets(session) }
            o.onSuccess { storeOrders = it }.onFailure { onMessage(it.message ?: "تعذر تحميل طلبات المتجر.") }
            d.onSuccess { diamondRequests = it }.onFailure { onMessage(it.message ?: "تعذر تحميل طلبات الألماس.") }
            a.onSuccess { agencyApplications = it }.onFailure { onMessage(it.message ?: "تعذر تحميل طلبات الوكالة.") }
            w.onSuccess { wallets = it }.onFailure { onMessage(it.message ?: "تعذر تحميل المحافظ.") }
            busy = false
        }
    }

    LaunchedEffect(session.userId) { refresh() }
    LaunchedEffect(section) { if (section == 5) refreshStore() }

    reviewTeacher?.let { (request, approve) ->
        AlertDialog(
            onDismissRequest = { if (!busy) { reviewTeacher = null; note = "" } },
            title = { Text(if (approve) "تأكيد قبول المدرس" else "تأكيد رفض الطلب") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${request.fullName} — ${request.subject}")
                    if (approve) Text("عند الموافقة سيتحول الدور إلى مدرس ويُمنح التوثيق الأحمر تلقائيًا.", color = StudentMuted)
                    OutlinedTextField(note, { note = it.take(500) }, label = { Text("ملاحظة الإدارة") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.adminReviewTeacherRequest(session, request.id, approve, note.trim()) }
                            busy = false
                            r.onSuccess { onMessage(if (approve) "تم قبول طلب المدرس وتفعيل صلاحياته." else "تم رفض طلب المدرس."); reviewTeacher = null; note = ""; refresh() }
                                .onFailure { onMessage(it.message ?: "تعذر تحديث الطلب.") }
                        }
                    },
                    colors = if (approve) ButtonDefaults.buttonColors(containerColor = StudentBlue) else ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text(if (approve) "تأكيد القبول" else "تأكيد الرفض") }
            },
            dismissButton = { TextButton(onClick = { reviewTeacher = null; note = "" }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    deleteAd?.let { ad ->
        AlertDialog(
            onDismissRequest = { if (!busy) deleteAd = null },
            title = { Text("حذف الإعلان") },
            text = { Text("هل تريد حذف إعلان «${ad.title}» نهائيًا؟") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            val r = withContext(Dispatchers.IO) { api.adminDeleteHomeAd(session, ad.id) }
                            busy = false
                            r.onSuccess { onMessage("تم حذف الإعلان."); deleteAd = null; refresh() }.onFailure { onMessage(it.message ?: "تعذر حذف الإعلان.") }
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleteAd = null }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    reviewSuggestion?.let { item ->
        AlertDialog(
            onDismissRequest = { if (!busy) { reviewSuggestion = null; note = "" } },
            title = { Text(item.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(item.body)
                    OutlinedTextField(note, { note = it.take(800) }, label = { Text("رد الإدارة") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                }
            },
            confirmButton = {
                Button(onClick = {
                    scope.launch {
                        busy = true
                        val r = withContext(Dispatchers.IO) { api.adminReviewSuggestion(session, item.id, "reviewed", note.trim()) }
                        busy = false
                        r.onSuccess { onMessage("تمت مراجعة الاقتراح."); reviewSuggestion = null; note = ""; refresh() }.onFailure { onMessage(it.message ?: "تعذر حفظ المراجعة.") }
                    }
                }) { Text("حفظ المراجعة") }
            },
            dismissButton = { TextButton(onClick = { reviewSuggestion = null; note = "" }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    storeAction?.let { action ->
        AlertDialog(
            onDismissRequest = { if (!busy) { storeAction = null; storeNote = "" } },
            title = { Text(action.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(action.message)
                    if (action.kind == "agency") {
                        OutlinedTextField(
                            value = storeNote,
                            onValueChange = { storeNote = it.take(500) },
                            label = { Text("ملاحظة الإدارة — اختياري") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            busy = true
                            val result = withContext(Dispatchers.IO) {
                                when (action.kind) {
                                    "order" -> api.adminUpdateStoreOrder(session, action.id, action.status ?: error("Missing order status"))
                                    "diamond" -> api.adminReviewDiamondRequest(session, action.id, action.approve == true)
                                    "agency" -> api.adminReviewAgencyApplication(session, action.id, action.approve == true, storeNote.trim())
                                    else -> Result.failure(IllegalArgumentException("عملية إدارة غير صالحة."))
                                }
                            }
                            busy = false
                            result.onSuccess {
                                onMessage("تم تنفيذ العملية بنجاح عبر الخادم.")
                                storeAction = null
                                storeNote = ""
                                refreshStore()
                            }.onFailure { onMessage(it.message ?: "تعذر تنفيذ العملية.") }
                        }
                    },
                    enabled = !busy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (action.approve == false || action.status == "cancelled" || action.status == "refunded") Color(0xFFC62828) else StudentBlue
                    )
                ) { Text("تأكيد") }
            },
            dismissButton = { TextButton(onClick = { storeAction = null; storeNote = "" }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = section, edgePadding = 6.dp, containerColor = Color.White, contentColor = StudentBlue) {
            listOf("طلبات المدرسين", "الإعلانات", "Learn English", "الاقتراحات", "التعليم", "المتجر").forEachIndexed { i, label ->
                Tab(selected = section == i, onClick = { section = i }, text = { Text(label) })
            }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = StudentBlue)
        when (section) {
            0 -> TeacherRequestsAdmin(teachers, onApprove = { reviewTeacher = it to true }, onReject = { reviewTeacher = it to false })
            1 -> AdsAdmin(api, session, ads, busy, onMessage, onRefresh = ::refresh, onDelete = { deleteAd = it })
            2 -> LearnEnglishAdmin(api, session, busy, onMessage)
            3 -> SuggestionsAdmin(suggestions) { reviewSuggestion = it }
            4 -> EducationAdmin(api, session, busy, onMessage)
            else -> AdminStorePane(storeOrders, diamondRequests, agencyApplications, wallets) { storeAction = it }
        }
    }
}

@Composable
private fun TeacherRequestsAdmin(items: List<TeacherRequest>, onApprove: (TeacherRequest) -> Unit, onReject: (TeacherRequest) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items, key = { it.id }) { request ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(request.fullName, fontWeight = FontWeight.Black)
                    Text("${request.educationStage} — ${request.subject}", color = StudentMuted)
                    if (request.experience.isNotBlank()) Text(request.experience, color = StudentMuted, style = MaterialTheme.typography.bodySmall)
                    Text("الحالة: ${request.status}", color = StudentBlue)
                    if (request.status == "pending") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onApprove(request) }) { Text("قبول") }
                            OutlinedButton(onClick = { onReject(request) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))) { Text("رفض") }
                        }
                    }
                }
            }
        }
        if (items.isEmpty()) item { Text("لا توجد طلبات مدرسين.", color = StudentMuted, modifier = Modifier.padding(14.dp)) }
    }
}

@Composable
private fun AdsAdmin(
    api: SupabaseApi, session: StudentSession, ads: List<HomeAd>, busy: Boolean,
    onMessage: (String) -> Unit, onRefresh: () -> Unit, onDelete: (HomeAd) -> Unit
) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var actionUrl by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("إنشاء إعلان للرئيسية", fontWeight = FontWeight.Black)
                    OutlinedTextField(title, { title = it.take(120) }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(body, { body = it.take(500) }, label = { Text("النص") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(imageUrl, { imageUrl = it.take(500) }, label = { Text("رابط الصورة — اختياري") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(actionUrl, { actionUrl = it.take(500) }, label = { Text("رابط عند الضغط — اختياري") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        if (title.isBlank() || busy) return@Button
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { api.adminCreateHomeAd(session, title.trim(), body.trim(), imageUrl.trim().ifBlank { null }, actionUrl.trim().ifBlank { null }) }
                            r.onSuccess { title = ""; body = ""; imageUrl = ""; actionUrl = ""; onMessage("تم نشر الإعلان في الرئيسية."); onRefresh() }
                                .onFailure { onMessage(it.message ?: "تعذر إنشاء الإعلان.") }
                        }
                    }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("نشر الإعلان") }
                }
            }
        }
        items(ads, key = { it.id }) { ad ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFE6DDF5))) {
                Column(Modifier.padding(12.dp)) {
                    Text(ad.title, fontWeight = FontWeight.Bold)
                    Text(ad.body, color = StudentMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = ad.isActive, onClick = {
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { api.adminToggleHomeAd(session, ad.id, !ad.isActive) }
                                r.onSuccess { onMessage("تم تحديث حالة الإعلان."); onRefresh() }.onFailure { onMessage(it.message ?: "تعذر التحديث.") }
                            }
                        }, label = { Text(if (ad.isActive) "ظاهر" else "مخفي") })
                        TextButton(onClick = { onDelete(ad) }) { Text("حذف", color = Color(0xFFC62828)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun LearnEnglishAdmin(api: SupabaseApi, session: StudentSession, busy: Boolean, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var english by remember { mutableStateOf("") }
    var arabic by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("مفردات") }
    var level by remember { mutableStateOf("all") }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("إضافة محتوى Learn English", fontWeight = FontWeight.Black)
        OutlinedTextField(title, { title = it.take(120) }, label = { Text("العنوان") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(english, { english = it.take(2000) }, label = { Text("النص الإنجليزي") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(arabic, { arabic = it.take(2000) }, label = { Text("الشرح/الترجمة العربية") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(category, { category = it.take(80) }, label = { Text("التصنيف") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(level, { level = it.take(40) }, label = { Text("المستوى") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            if (title.isBlank() || english.isBlank() || busy) return@Button
            scope.launch {
                val r = withContext(Dispatchers.IO) { api.adminAddLearnEnglish(session, title.trim(), english.trim(), arabic.trim(), category.trim(), level.trim()) }
                r.onSuccess { title = ""; english = ""; arabic = ""; onMessage("تمت إضافة محتوى Learn English.") }.onFailure { onMessage(it.message ?: "تعذر الإضافة.") }
            }
        }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("إضافة المحتوى") }
    }
}

@Composable
private fun SuggestionsAdmin(items: List<StudentSuggestion>, onReview: (StudentSuggestion) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items, key = { it.id }) { item ->
            StudentOutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(item.title, fontWeight = FontWeight.Bold)
                    Text(item.body, color = StudentMuted, maxLines = 4)
                    Text("${item.category} — ${item.status}", color = StudentBlue, style = MaterialTheme.typography.labelMedium)
                    TextButton(onClick = { onReview(item) }) { Text("مراجعة ورد") }
                }
            }
        }
        if (items.isEmpty()) item { Text("لا توجد اقتراحات.", color = StudentMuted) }
    }
}

@Composable
private fun EducationAdmin(api: SupabaseApi, session: StudentSession, busy: Boolean, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var subjectId by remember { mutableStateOf("") }
    var universityLevelId by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("text") }
    var url by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("إضافة شرح/درس", fontWeight = FontWeight.Black)
        Text("المحتوى يُحفظ في Supabase ويظهر دون إصدار APK جديد.", color = StudentMuted)
        OutlinedTextField(subjectId, { subjectId = it.trim().take(80) }, label = { Text("Subject ID") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(universityLevelId, { universityLevelId = it.trim().take(80) }, label = { Text("University Level ID — اتركه فارغًا للمدرسي") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(title, { title = it.take(160) }, label = { Text("عنوان الدرس") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it.take(3000) }, label = { Text("الشرح") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("text", "link", "video", "pdf").forEach { v -> FilterChip(selected = type == v, onClick = { type = v }, label = { Text(v) }) }
        }
        OutlinedTextField(url, { url = it.take(600) }, label = { Text("رابط خارجي — اختياري") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            if (subjectId.isBlank() || title.isBlank() || busy) return@Button
            scope.launch {
                val r = withContext(Dispatchers.IO) { api.adminAddEducationMaterial(session, subjectId, title.trim(), description.trim(), type, url.trim().ifBlank { null }, universityLevelId.trim().ifBlank { null }) }
                r.onSuccess { title = ""; description = ""; url = ""; onMessage("تمت إضافة المحتوى التعليمي.") }.onFailure { onMessage(it.message ?: "تعذر إضافة المحتوى.") }
            }
        }, modifier = Modifier.fillMaxWidth(), enabled = !busy) { Text("نشر الدرس") }
    }
}
@Composable
private fun AdminStorePane(
    orders: List<AdminStoreOrder>,
    diamondRequests: List<DiamondPurchaseRequest>,
    agencies: List<AgencyApplication>,
    wallets: List<AdminWalletRow>,
    onAction: (AdminStoreAction) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 6.dp, containerColor = Color.White, contentColor = StudentBlue) {
            listOf("الطلبات", "طلبات الألماس", "الوكالات", "المحافظ").forEachIndexed { index, label ->
                Tab(selected = tab == index, onClick = { tab = index }, text = { Text(label) })
            }
        }
        when (tab) {
            0 -> LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(orders, key = { it.id }) { order ->
                    StudentOutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(order.productName, fontWeight = FontWeight.Black)
                            Text("الحالة: ${order.status}", color = StudentBlue)
                            Text("المستخدم: ${order.userId.take(10)}…", color = StudentMuted, style = MaterialTheme.typography.labelSmall)
                            Text("الدفع: ${order.paymentMethod} · ${if (order.diamondAmount > 0) "${order.diamondAmount} ألماسة" else "${order.moneyAmount.toLong()} IQD"}", color = StudentMuted)
                            if (order.status !in setOf("completed", "cancelled", "refunded")) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (order.status == "pending") {
                                        OutlinedButton(onClick = { onAction(AdminStoreAction("order", order.id, status = "confirmed", title = "تأكيد قبول طلب ${order.productName}", message = "سيتم تحويل الطلب إلى مؤكد.")) }) { Text("تأكيد") }
                                    }
                                    Button(onClick = { onAction(AdminStoreAction("order", order.id, status = "completed", title = "تأكيد إكمال الطلب", message = "هل تم تنفيذ/تسليم هذا الطلب فعلًا؟")) }) { Text("مكتمل") }
                                    TextButton(onClick = { onAction(AdminStoreAction("order", order.id, status = "cancelled", title = "تأكيد إلغاء الطلب", message = "قد تؤدي هذه العملية إلى استرجاع الرصيد/المخزون حسب طريقة الدفع.")) }) { Text("إلغاء", color = Color(0xFFC62828)) }
                                }
                            }
                            if (order.status == "completed") {
                                TextButton(onClick = { onAction(AdminStoreAction("order", order.id, status = "refunded", title = "تأكيد استرجاع الطلب", message = "سيتم تنفيذ منطق الاسترجاع المالي عبر الخادم. تأكد قبل المتابعة.")) }) { Text("استرجاع", color = Color(0xFFC62828)) }
                            }
                        }
                    }
                }
                if (orders.isEmpty()) item { Text("لا توجد طلبات متجر.", color = StudentMuted, modifier = Modifier.padding(12.dp)) }
            }
            1 -> LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(diamondRequests, key = { it.id }) { request ->
                    StudentOutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("${request.diamonds} ألماسة — ${request.amountIqd} IQD", fontWeight = FontWeight.Black)
                            Text("الحالة: ${request.status}", color = StudentBlue)
                            Text("مرجع الدفع: ${request.paymentReference ?: "غير مرفق"}", color = StudentMuted)
                            Text("المستخدم: ${request.userId.take(10)}…", color = StudentMuted, style = MaterialTheme.typography.labelSmall)
                            if (request.status == "pending") {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { onAction(AdminStoreAction("diamond", request.id, approve = true, title = "تأكيد إضافة الألماس", message = "بعد التأكيد سيضيف الخادم ${request.diamonds} ألماسة إلى محفظة المستخدم. تأكد من وصول الدفع أولًا.")) }) { Text("اعتماد") }
                                    OutlinedButton(onClick = { onAction(AdminStoreAction("diamond", request.id, approve = false, title = "تأكيد رفض طلب الألماس", message = "لن تتم إضافة أي رصيد للمستخدم.")) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))) { Text("رفض") }
                                }
                            }
                        }
                    }
                }
                if (diamondRequests.isEmpty()) item { Text("لا توجد طلبات ألماس.", color = StudentMuted, modifier = Modifier.padding(12.dp)) }
            }
            2 -> LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(agencies, key = { it.id }) { application ->
                    StudentOutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text(application.fullName, fontWeight = FontWeight.Black)
                            Text("${application.province} — ${application.phone}", color = StudentMuted)
                            Text("الحالة: ${application.status}", color = StudentBlue)
                            if (application.status == "pending") {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { onAction(AdminStoreAction("agency", application.id, approve = true, title = "تأكيد قبول الوكالة", message = "سيُنشئ الخادم حساب وكيل فعّال لهذا المستخدم.")) }) { Text("قبول") }
                                    OutlinedButton(onClick = { onAction(AdminStoreAction("agency", application.id, approve = false, title = "تأكيد رفض الوكالة", message = "سيتم رفض الطلب ويمكن إضافة ملاحظة للمستخدم.")) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))) { Text("رفض") }
                                }
                            }
                        }
                    }
                }
                if (agencies.isEmpty()) item { Text("لا توجد طلبات وكالة.", color = StudentMuted, modifier = Modifier.padding(12.dp)) }
            }
            else -> LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(wallets, key = { it.userId }) { wallet ->
                    StudentOutlinedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("محفظة ${wallet.userId.take(10)}…", fontWeight = FontWeight.Bold)
                            Text("المتاح: ${wallet.availableBalance.toLong()} · المحجوز: ${wallet.heldBalance.toLong()}", color = StudentBlue)
                            Text("إجمالي الشراء: ${wallet.totalPurchased.toLong()} · المصروف: ${wallet.totalSpent.toLong()}", color = StudentMuted)
                            Text(prettyTime(wallet.updatedAt), color = StudentMuted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                if (wallets.isEmpty()) item { Text("لا توجد محافظ لعرضها.", color = StudentMuted, modifier = Modifier.padding(12.dp)) }
            }
        }
    }
}

