Student Native Full v1.0 — FIX4 Integration / QA
=================================================

هذا المشروع Android Native بالكامل:
- Kotlin + Jetpack Compose
- بدون WebView
- Supabase: Auth / Database / Storage / Realtime
- Firebase FCM Native للإشعارات

أهم ما تمت إضافته/تثبيته في FIX4:
1) هوية Native أبيض + بنفسجي مع Vector Icons.
2) شارة توثيق مشرشرة احترافية: أزرق للطالب، أحمر للمدرس، برتقالي للأدمن.
3) Student AI: سؤال وجواب + ترجمة عربي/إنجليزي + سجل محادثة عبر Edge Function حقيقية.
4) Learn English ديناميكي من Supabase + نطق Android TTS (US/UK وبطيء).
5) نظام طلب المدرس + قبول/رفض الأدمن + تحويل الدور والتوثيق الأحمر عند القبول.
6) نشر المحتوى التعليمي للمدرس/الأدمن عبر RPC محمي من الخادم.
7) الاقتراحات: إرسال من المستخدم ومراجعة من الإدارة.
8) home_ads: إنشاء/تفعيل/تعطيل/حذف من الأدمن وظهورها في الرئيسية.
9) المتجر المتقدم: المنتجات، المهام، باقات الألماس، المحفظة والسجل، الوكالة والطلبات.
10) العمليات المالية الحساسة في الأدمن تستخدم RPCs الموجودة ولا تعدّل الرصيد مباشرة.
11) الرسائل Native + ملفات/صور/فيديو/صوت + حالة القراءة + Supabase Realtime على chat_messages.
12) القصص: نص/صورة/فيديو + مشاهدات + ردود + تفاعلات.
13) حظر/إلغاء حظر مع RPC محمي وإزالة علاقات المتابعة عند الحظر.
14) Offline cache + مزامنة عند رجوع الاتصال.
15) تأكيد الخروج من الرئيسية.
16) Stable package: com.studentiraq.app
17) Beta package: com.studentiraq.app.beta
18) Reels غير موجودة عمدًا.

Backend قبل الاختبار الكامل:
- شغّل: supabase/migrations/20260822_student_native_fix4.sql
- انشر Edge Function: supabase/functions/student-ai
- ضع سر مزود AI داخل Supabase Edge Function Secrets حسب README داخل مجلد الدالة.

FCM:
- الكود يحتوي FirebaseMessagingService وandroid-fcm token registration.
- يلزم تسجيل تطبيق Android بالـpackage com.studentiraq.app داخل مشروع Firebase للحصول على Android Firebase App ID النهائي.
- القيمة الحالية في StudentConfig مبنية على إعداد Firebase السابق؛ لا نعتبر FCM Native مختبرًا نهائيًا حتى يتم اختبار Android App ID الحقيقي على APK.

QA:
- هذه نسخة تكامل واختبار وليست Release متجر نهائية.
- المطلوب: Build ناجح على GitHub Actions ثم اختبار تسجيل الدخول، AI، التعليم، الرسائل، FCM، المتجر، الأدمن والـOffline على الهاتف.
- أي وظيفة لا تنفذ عملها الفعلي لا تُحسب ميزة مكتملة.

Version name: 1.0.0-native-FIX4
Version code: 104
