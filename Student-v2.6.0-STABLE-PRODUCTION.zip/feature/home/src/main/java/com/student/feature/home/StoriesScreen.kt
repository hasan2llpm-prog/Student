@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.student.feature.home

import kotlinx.coroutines.delay
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import android.net.Uri
import android.widget.VideoView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.student.core.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

@Composable
fun StoriesScreen(api: SupabaseApi, session: StudentSession, initialStoryId: String? = null, onClose: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    val context = LocalContext.current
    val uri = LocalUriHandler.current
    var stories by remember { mutableStateOf<List<StoryItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var createOpen by remember { mutableStateOf(false) }
    var storyText by remember { mutableStateOf("") }
    var overlayText by remember { mutableStateOf("") }
    var overlayTextColor by remember { mutableStateOf("#FFFFFF") }
    var overlayBackground by remember { mutableStateOf(true) }
    var overlayPosition by remember { mutableStateOf("center") }
    var mediaFilter by remember { mutableStateOf("normal") }
    var cropMode by remember { mutableStateOf("original") }
    var selectedStoryMedia by remember { mutableStateOf<Uri?>(null) }
    var selectedStoryMime by remember { mutableStateOf<String?>(null) }
    var myProfile by remember { mutableStateOf<StudentProfile?>(null) }
    var confirmStoryPublish by remember { mutableStateOf(false) }
    var interaction by remember { mutableStateOf<StoryItem?>(null) }
    var deleteStory by remember { mutableStateOf<StoryItem?>(null) }
    var editStory by remember { mutableStateOf<StoryItem?>(null) }
    var viewerGroupIndex by remember { mutableIntStateOf(-1) }
    var viewerStoryIndex by remember { mutableIntStateOf(0) }
    var pendingOpenStoryId by remember { mutableStateOf<String?>(null) }
    var publishingStory by remember { mutableStateOf(false) }
    var initialCreatePickerConsumed by remember(initialStoryId) { mutableStateOf(false) }

    fun refresh() {
        scope.launch {
            loading = true
            message = null
            val r = withContext(Dispatchers.IO) { api.stories(session, 80) }
            r.onSuccess { stories = it }.onFailure { message = it.message }
            loading = false
        }
    }

    fun openPublishedStory(newStoryId: String) {
        scope.launch {
            loading = true
            val r = withContext(Dispatchers.IO) { api.stories(session, 80) }
            loading = false
            r.onSuccess { fresh ->
                stories = fresh
                val groups = fresh.groupBy { it.userId }.values.map { group -> group.sortedBy { it.createdAt } }
                groups.forEachIndexed { groupIndex, group ->
                    val storyIndex = group.indexOfFirst { it.id == newStoryId }
                    if (storyIndex >= 0) {
                        viewerGroupIndex = groupIndex
                        viewerStoryIndex = storyIndex
                        pendingOpenStoryId = null
                        createOpen = false
                        selectedStoryMedia = null
                        selectedStoryMime = null
                        publishingStory = false
                        message = "تم نشر القصة."
                        return@onSuccess
                    }
                }
                pendingOpenStoryId = newStoryId
                publishingStory = false
                message = "تم نشر القصة."
            }.onFailure {
                publishingStory = false
                message = "تم نشر القصة، وتعذر فتحها الآن."
            }
        }
    }

    fun publishMedia(uriValue: android.net.Uri) {
        scope.launch {
            loading = true
            message = null
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val mime = context.contentResolver.getType(uriValue) ?: "application/octet-stream"
                    val type = when {
                        mime.startsWith("image/") -> "image"
                        mime.startsWith("video/") -> "video"
                        else -> throw IllegalStateException("القصص تدعم الصور والفيديو فقط.")
                    }
                    val bytes = context.contentResolver.openInputStream(uriValue)?.use { it.readBytes() }
                        ?: throw IllegalStateException("تعذر قراءة الملف.")
                    val maxMb = cfg.int("stories.max_upload_mb", 30, 1, 100)
                    if (bytes.size > maxMb * 1024 * 1024) throw IllegalStateException("الحد الأقصى لوسائط القصة ${maxMb}MB.")
                    val ext = if (type == "image") "jpg" else "mp4"
                    val path = "${session.userId}/${System.currentTimeMillis()}_story.$ext"
                    val url = api.uploadObject(session, "stories", path, bytes, mime).getOrThrow()
                    api.createStoryWithId(
                        session = session,
                        content = storyText.trim(),
                        mediaUrl = url,
                        type = type,
                        overlayText = overlayText.trim(),
                        overlayTextColor = overlayTextColor,
                        overlayBackground = overlayBackground,
                        overlayPosition = overlayPosition,
                        mediaFilter = if (type == "image") mediaFilter else "normal",
                        cropMode = cropMode
                    ).getOrThrow()
                }
            }
            loading = false
            result.onSuccess { newStoryId ->
                pendingOpenStoryId = newStoryId
                storyText = ""; overlayText = ""; selectedStoryMedia = null; selectedStoryMime = null
                mediaFilter = "normal"; cropMode = "original"; overlayPosition = "center"; overlayBackground = true
                createOpen = false
                openPublishedStory(newStoryId)
            }.onFailure {
                publishingStory = false
                createOpen = true
                message = it.message
            }
        }
    }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked == null) {
            if (selectedStoryMedia == null) createOpen = false
        } else {
            selectedStoryMedia = picked
            selectedStoryMime = context.contentResolver.getType(picked)
            createOpen = true
        }
    }

    LaunchedEffect(Unit) {
        refresh()
        withContext(Dispatchers.IO) { api.profile(session) }.onSuccess { myProfile = it }
    }
    val storyGroups = remember(stories) {
        stories.groupBy { it.userId }.values.map { group -> group.sortedBy { it.createdAt } }
    }
    // Launch the studio only once for the explicit create route.
    // Do not key this effect to storyGroups: refreshing after publish must never reopen the picker.
    LaunchedEffect(initialStoryId) {
        if (initialStoryId == "__create__" && !initialCreatePickerConsumed) {
            initialCreatePickerConsumed = true
            createOpen = false
            mediaPicker.launch(arrayOf("image/*", "video/*"))
        }
    }
    LaunchedEffect(initialStoryId, storyGroups) {
        if (!initialStoryId.isNullOrBlank() && initialStoryId != "__create__" && storyGroups.isNotEmpty() && viewerGroupIndex < 0) {
            storyGroups.forEachIndexed { groupIndex, group ->
                val storyIndex = group.indexOfFirst { it.id == initialStoryId }
                if (storyIndex >= 0) {
                    viewerGroupIndex = groupIndex
                    viewerStoryIndex = storyIndex
                    return@LaunchedEffect
                }
            }
        }
    }
    LaunchedEffect(pendingOpenStoryId, storyGroups) {
        val targetId = pendingOpenStoryId ?: return@LaunchedEffect
        storyGroups.forEachIndexed { groupIndex, group ->
            val storyIndex = group.indexOfFirst { it.id == targetId }
            if (storyIndex >= 0) {
                viewerGroupIndex = groupIndex
                viewerStoryIndex = storyIndex
                pendingOpenStoryId = null
                return@LaunchedEffect
            }
        }
    }
    LaunchedEffect(message) { if (message != null) { delay(cfg.long("stories.status_duration_ms", 2600L, 500L, 10000L)); message = null } }

    if (confirmStoryPublish) {
        AlertDialog(
            onDismissRequest = { if (!loading) confirmStoryPublish = false },
            title = { Text("تأكيد نشر القصة") },
            text = { Text("هل تريد نشر هذه القصة الآن؟") },
            confirmButton = {
                Button(
                    enabled = !loading && (storyText.isNotBlank() || selectedStoryMedia != null),
                    onClick = {
                        confirmStoryPublish = false
                        val media = selectedStoryMedia
                        createOpen = false
                        publishingStory = true
                        if (media != null) {
                            publishMedia(media)
                        } else {
                            scope.launch {
                                loading = true
                                val r = withContext(Dispatchers.IO) { api.createStoryWithId(session, storyText.trim(), null, "text") }
                                loading = false
                                r.onSuccess { newStoryId ->
                                    pendingOpenStoryId = newStoryId
                                    storyText = ""; selectedStoryMedia = null; selectedStoryMime = null
                                    openPublishedStory(newStoryId)
                                }.onFailure {
                                    publishingStory = false
                                    createOpen = true
                                    message = it.message
                                }
                            }
                        }
                    }
                ) { Text("تأكيد ونشر") }
            },
            dismissButton = { TextButton(enabled = !loading, onClick = { confirmStoryPublish = false }) { Text("رجوع للتحرير") } }
        )
    }

    if (createOpen && selectedStoryMedia != null) {
        BackHandler(enabled = !loading) {
            createOpen = false
            selectedStoryMedia = null
            selectedStoryMime = null
            storyText = ""
            overlayText = ""
        }
        Box(
            Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            val media = selectedStoryMedia
            when {
                selectedStoryMime?.startsWith("image/") == true -> AsyncImage(
                    model = media, contentDescription = "معاينة القصة",
                    contentScale = if (cropMode == "original") ContentScale.Fit else ContentScale.Crop,
                    colorFilter = storyImageFilter(mediaFilter), modifier = Modifier.fillMaxSize()
                )
                selectedStoryMime?.startsWith("video/") == true -> AndroidView(
                    factory = { ctx -> VideoView(ctx).apply {
                        setVideoURI(media); setOnPreparedListener { mp -> mp.isLooping = true; start() }
                    } }, modifier = Modifier.fillMaxSize()
                )
            }

            if (overlayText.isNotBlank()) {
                val alignment = when (overlayPosition) { "top" -> Alignment.TopCenter; "bottom" -> Alignment.BottomCenter; else -> Alignment.Center }
                Surface(Modifier.align(alignment).padding(54.dp), color = if (overlayBackground) Color.Black.copy(alpha=.48f) else Color.Transparent, shape=RoundedCornerShape(10.dp)) {
                    Text(overlayText, color=parseStoryColor(overlayTextColor), fontSize=25.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=10.dp, vertical=6.dp))
                }
            }

            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp), verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={ createOpen=false; selectedStoryMedia=null; selectedStoryMime=null }) { Icon(Icons.Rounded.Close,"إغلاق",tint=Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton(onClick={ overlayText = if (overlayText.isBlank()) "نص" else overlayText }) { Text("Aa",color=Color.White,fontWeight=FontWeight.Black,fontSize=20.sp) }
                IconButton(onClick={ mediaFilter = when(mediaFilter){"normal"->"mono";"mono"->"warm";"warm"->"cool";else->"normal"} }, enabled=selectedStoryMime?.startsWith("image/")==true) { Icon(Icons.Rounded.AutoAwesome,"فلتر",tint=Color.White) }
                IconButton(onClick={ cropMode = when(cropMode){"original"->"9:16";"9:16"->"4:5";"4:5"->"1:1";else->"original"} }) { Icon(Icons.Rounded.Crop,"قص",tint=Color.White) }
                IconButton(onClick={ mediaPicker.launch(arrayOf("image/*","video/*")) }) { Icon(Icons.Rounded.PermMedia,"تغيير الوسائط",tint=Color.White) }
            }

            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(14.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(
                    value=overlayText, onValueChange={ overlayText=it.take(220) },
                    placeholder={ Text("Aa  أضف نصاً",color=Color.White.copy(alpha=.75f)) },
                    textStyle=LocalTextStyle.current.copy(color=Color.White), singleLine=true,
                    colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Color.White.copy(alpha=.7f),unfocusedBorderColor=Color.White.copy(alpha=.35f)),
                    modifier=Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value=storyText, onValueChange={ storyText=it.take(1200) },
                    placeholder={ Text("إضافة شرح...",color=Color.White.copy(alpha=.75f)) },
                    textStyle=LocalTextStyle.current.copy(color=Color.White), singleLine=true,
                    colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Color.White.copy(alpha=.7f),unfocusedBorderColor=Color.White.copy(alpha=.35f)),
                    modifier=Modifier.fillMaxWidth()
                )
                Button(
                    onClick={ confirmStoryPublish=true }, enabled=!loading,
                    modifier=Modifier.fillMaxWidth().height(50.dp), shape=RoundedCornerShape(25.dp)
                ) { Icon(Icons.Rounded.AddCircle,null); Spacer(Modifier.width(7.dp)); Text("قصتك",fontWeight=FontWeight.Bold) }
            }
        }
        return
    }

    interaction?.let { story ->
        StoryInteractionDialog(api, session, story, onDismiss = { interaction = null }) { msg -> message = msg }
    }

    editStory?.let { story ->
        var editText by remember(story.id) { mutableStateOf(story.content) }
        AlertDialog(
            onDismissRequest = { if (!loading) editStory = null },
            title = { Text("تعديل القصة") },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it.take(1200) },
                    label = { Text(if (story.type.equals("text", true)) "نص القصة" else "وصف القصة") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )
            },
            confirmButton = {
                Button(
                    enabled = !loading && (!story.type.equals("text", true) || editText.isNotBlank()),
                    onClick = {
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.updateStory(session, story.id, editText.trim()) }
                            loading = false
                            r.onSuccess {
                                editStory = null
                                message = "تم تعديل القصة."
                                refresh()
                            }.onFailure { message = it.message }
                        }
                    }
                ) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { editStory = null }, enabled = !loading) { Text("إلغاء") } }
        )
    }

    deleteStory?.let { story ->
        AlertDialog(
            onDismissRequest = { if (!loading) deleteStory = null },
            title = { Text("حذف القصة") },
            text = { Text("هل تريد حذف هذه القصة نهائيًا؟") },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            loading = true
                            val r = withContext(Dispatchers.IO) { api.deleteStory(session, story.id) }
                            loading = false
                            r.onSuccess { deleteStory = null; message = "تم حذف القصة."; refresh() }.onFailure { message = it.message }
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828))
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { deleteStory = null }, enabled = !loading) { Text("إلغاء") } }
        )
    }

    if (publishingStory) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(color = Color.White)
                Text("جارٍ تحميل القصة...", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        return
    }

    if (!initialStoryId.isNullOrBlank() && initialStoryId != "__create__" && viewerGroupIndex < 0 && loading) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }
        return
    }

    if (viewerGroupIndex >= 0 && storyGroups.isNotEmpty()) {
        val group = storyGroups[viewerGroupIndex.coerceIn(0, storyGroups.lastIndex)]
        InstagramStoryViewer(
            stories = group,
            startIndex = viewerStoryIndex.coerceIn(0, group.lastIndex),
            session = session,
            api = api,
            onClose = { viewerGroupIndex = -1; viewerStoryIndex = 0; onClose() },
            onNextGroup = {
                if (viewerGroupIndex < storyGroups.lastIndex) { viewerGroupIndex += 1; viewerStoryIndex = 0 }
                else { viewerGroupIndex = -1; viewerStoryIndex = 0; onClose() }
            },
            onPreviousGroup = {
                if (viewerGroupIndex > 0) {
                    viewerGroupIndex -= 1
                    viewerStoryIndex = storyGroups[viewerGroupIndex].lastIndex.coerceAtLeast(0)
                }
            },
            onInteract = { interaction = it },
            onEdit = { editStory = it },
            onDelete = { deleteStory = it }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        if (cfg.bool("stories.show_library_header", true)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(cfg.string("stories.header_title", "قصص Student"), fontWeight = FontWeight.Bold, fontSize = cfg.int("stories.header_title_sp", 17, 12, 24).sp)
                    if (cfg.bool("stories.show_header_subtitle", true)) Text(cfg.string("stories.header_subtitle", "نص، صور وفيديو لمدة 24 ساعة"), color = StudentMuted, fontSize = 11.sp)
                }
                Row {
                    if (cfg.bool("stories.show_refresh_button", true)) IconButton(onClick = { refresh() }) { Icon(Icons.Rounded.Refresh, "تحديث") }
                    if (cfg.bool("stories.show_create_button", true)) FilledIconButton(onClick = { mediaPicker.launch(arrayOf("image/*", "video/*")) }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = StudentBlue)) {
                        Icon(Icons.Rounded.Add, "إضافة قصة", tint = Color.White)
                    }
                }
            }
        }
        message?.let { Text(it, color = if (it.startsWith("تم")) Color(0xFF16803C) else MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp), fontSize = 12.sp) }
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "my_story_add") {
                Column(
                    modifier = Modifier.width(cfg.int("stories.library_item_width_dp", 86, 60, 130).dp).clickable { mediaPicker.launch(arrayOf("image/*", "video/*")) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(cfg.int("stories.library_ring_size_dp", 78, 50, 110).dp)) {
                        StudentAvatar(
                            myProfile?.fullName ?: "قصتك",
                            myProfile?.avatarUrl,
                            myProfile?.profileFrameUrl,
                            cfg.int("stories.library_avatar_size_dp", 68, 40, 100).dp,
                            modifier = Modifier.align(Alignment.Center)
                        )
                        Surface(
                            modifier = Modifier.align(Alignment.BottomEnd).size(24.dp),
                            shape = CircleShape,
                            color = StudentBlue,
                            border = BorderStroke(2.dp, Color.White)
                        ) { Icon(Icons.Rounded.Add, "إضافة قصة", tint = Color.White, modifier = Modifier.padding(3.dp)) }
                    }
                    Text("قصتك", maxLines = 1, fontSize = cfg.int("stories.library_text_sp", 12, 9, 18).sp)
                }
            }
            items(storyGroups.size, key = { index -> "story_group_${storyGroups[index].firstOrNull()?.userId ?: index}" }) { groupIndex ->
                val group = storyGroups[groupIndex]
                val story = group.last()
                Column(
                    modifier = Modifier.width(cfg.int("stories.library_item_width_dp", 86, 60, 130).dp).clickable {
                        viewerGroupIndex = groupIndex
                        viewerStoryIndex = 0
                    },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.size(cfg.int("stories.library_ring_size_dp", 78, 50, 110).dp).clip(CircleShape).border(cfg.int("stories.library_ring_width_dp", 3, 1, 7).dp, Color(0xFFEF233C), CircleShape).padding(4.dp)) {
                        StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, cfg.int("stories.library_avatar_size_dp", 68, 40, 100).dp)
                    }
                    Text(story.authorName, maxLines = 1, fontSize = cfg.int("stories.library_text_sp", 12, 9, 18).sp)
                }
            }
        }
        if (stories.isEmpty() && !loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد قصص حاليًا.", color = StudentMuted) }
        }

    }
}

@Composable
private fun InstagramStoryViewer(
    stories: List<StoryItem>,
    startIndex: Int,
    session: StudentSession,
    api: SupabaseApi,
    onClose: () -> Unit,
    onNextGroup: () -> Unit,
    onPreviousGroup: () -> Unit,
    onInteract: (StoryItem) -> Unit,
    onEdit: (StoryItem) -> Unit,
    onDelete: (StoryItem) -> Unit
) {
    val cfg = LocalNativeRemoteConfig.current
    val pager = rememberPagerState(
        initialPage = startIndex.coerceIn(0, stories.lastIndex),
        pageCount = { stories.size }
    )
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var paused by remember { mutableStateOf(false) }
    var mediaReady by remember { mutableStateOf(false) }
    var mediaError by remember { mutableStateOf(false) }
    var retryToken by remember { mutableIntStateOf(0) }

    fun previous() {
        scope.launch {
            progress.stop()
            paused = false
            if (pager.currentPage > 0) pager.animateScrollToPage(pager.currentPage - 1)
            else onPreviousGroup()
        }
    }

    fun next() {
        scope.launch {
            progress.stop()
            paused = false
            if (pager.currentPage < stories.lastIndex) pager.animateScrollToPage(pager.currentPage + 1)
            else onNextGroup()
        }
    }

    BackHandler(onBack = onClose)

    LaunchedEffect(pager.currentPage) {
        progress.snapTo(0f)
        paused = false
        mediaError = false
        val story = stories[pager.currentPage]
        val hasRemoteMedia = (story.type.equals("image", true) || story.type.equals("video", true)) && !story.mediaUrl.isNullOrBlank()
        mediaReady = !hasRemoteMedia && story.type.equals("text", true)
        if (!story.type.equals("text", true) && !hasRemoteMedia) mediaError = true
        if (story.userId != session.userId) {
            withContext(Dispatchers.IO) { api.markStoryViewed(session, story.id) }
        }
    }

    LaunchedEffect(pager.currentPage, paused, mediaReady) {
        if (paused || !mediaReady) {
            progress.stop()
            return@LaunchedEffect
        }
        val story = stories[pager.currentPage]
        val total = if (story.type.equals("video", true)) {
            cfg.long("stories.video_duration_ms", 10000L, 2500L, 60000L)
        } else {
            cfg.long("stories.image_duration_ms", 6000L, 1800L, 30000L)
        }
        val remaining = ((1f - progress.value).coerceIn(0f, 1f) * total).toLong().coerceAtLeast(80L)
        progress.animateTo(1f, animationSpec = tween(remaining.toInt(), easing = LinearEasing))
        if (!paused && progress.value >= .999f) next()
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            pageSpacing = 0.dp,
            // Story navigation is handled here explicitly so taps, holds and swipes
            // behave consistently regardless of RTL layout direction.
            userScrollEnabled = false
        ) { page ->
            val story = stories[page]
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(page, pager.currentPage) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            if (page != pager.currentPage) return@awaitEachGesture

                            // Instagram-style: holding a finger pauses immediately.
                            paused = true
                            val startX = down.position.x
                            var endX = startX
                            var endY = down.position.y
                            var endTime = down.uptimeMillis

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                endX = change.position.x
                                endY = change.position.y
                                endTime = change.uptimeMillis
                                if (!change.pressed) break
                            }

                            paused = false
                            val dx = endX - startX
                            val heldMs = endTime - down.uptimeMillis
                            val swipeThreshold = size.width * 0.16f
                            val controlsZone = endY < 96.dp.toPx() || endY > size.height - 92.dp.toPx()

                            when {
                                controlsZone -> Unit // Let close/edit/reply controls receive the gesture.
                                abs(dx) >= swipeThreshold -> {
                                    // Physical swipe left = next, swipe right = previous.
                                    if (dx < 0f) next() else previous()
                                }
                                heldMs < 240L -> {
                                    // Quick tap: left half previous, right half next.
                                    if (endX < size.width / 2f) previous() else next()
                                }
                                else -> Unit // Long press only pauses; releasing resumes.
                            }
                        }
                    }
            ) {
                when {
                    story.type.equals("image", true) && !story.mediaUrl.isNullOrBlank() -> key(story.id, retryToken) {
                        AsyncImage(
                            model = story.mediaUrl,
                            contentDescription = "قصة ${story.authorName}",
                            contentScale = if (story.cropMode == "original") ContentScale.Fit else ContentScale.Crop,
                            colorFilter = storyImageFilter(story.mediaFilter),
                            onLoading = { if (page == pager.currentPage) { mediaReady = false; mediaError = false } },
                            onSuccess = { if (page == pager.currentPage) { mediaReady = true; mediaError = false } },
                            onError = { if (page == pager.currentPage) { mediaReady = false; mediaError = true } },
                            modifier = Modifier.fillMaxSize().padding(top = 18.dp, bottom = 66.dp)
                        )
                    }
                    story.type.equals("video", true) && !story.mediaUrl.isNullOrBlank() -> key(story.id, retryToken) {
                        AndroidView(
                            factory = { context ->
                                VideoView(context).apply {
                                    tag = story.mediaUrl
                                    setOnPreparedListener { player ->
                                        player.isLooping = false
                                        if (page == pager.currentPage) { mediaReady = true; mediaError = false }
                                        if (!paused && page == pager.currentPage) start()
                                    }
                                    setOnErrorListener { _, _, _ ->
                                        if (page == pager.currentPage) { mediaReady = false; mediaError = true }
                                        true
                                    }
                                    setVideoURI(Uri.parse(story.mediaUrl))
                                }
                            },
                            update = { view ->
                                if (view.tag != story.mediaUrl) {
                                    view.tag = story.mediaUrl
                                    if (page == pager.currentPage) { mediaReady = false; mediaError = false }
                                    view.setOnPreparedListener { player ->
                                        player.isLooping = false
                                        if (page == pager.currentPage) { mediaReady = true; mediaError = false }
                                        if (!paused && page == pager.currentPage) view.start()
                                    }
                                    view.setOnErrorListener { _, _, _ ->
                                        if (page == pager.currentPage) { mediaReady = false; mediaError = true }
                                        true
                                    }
                                    view.setVideoURI(Uri.parse(story.mediaUrl))
                                }
                                if (page == pager.currentPage && mediaReady) {
                                    if (paused) {
                                        if (view.isPlaying) view.pause()
                                    } else if (!view.isPlaying) {
                                        runCatching { view.start() }
                                    }
                                } else if (view.isPlaying) {
                                    view.pause()
                                }
                            },
                            modifier = Modifier.fillMaxSize().padding(top = 18.dp, bottom = 66.dp)
                        )
                    }
                    else -> Box(
                        Modifier.fillMaxSize().background(Color(0xFF402060)).padding(38.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            story.content,
                            color = Color.White,
                            fontSize = cfg.int("stories.text_story_font_sp", 28, 16, 48).sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = cfg.int("stories.text_story_line_sp", 38, 20, 60).sp
                        )
                    }
                }

                if (!story.type.equals("text", true) && story.overlayText.isNotBlank()) {
                    val overlayAlignment = when (story.overlayPosition) {
                        "top" -> Alignment.TopCenter
                        "bottom" -> Alignment.BottomCenter
                        else -> Alignment.Center
                    }
                    Surface(
                        modifier = Modifier.align(overlayAlignment).padding(horizontal = 24.dp, vertical = 92.dp),
                        color = if (story.overlayBackground) Color.Black.copy(alpha = .48f) else Color.Transparent,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            story.overlayText,
                            color = parseStoryColor(story.overlayTextColor),
                            fontSize = 25.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                if (!story.type.equals("text", true) && story.content.isNotBlank()) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 18.dp, end = 18.dp, bottom = 82.dp),
                        color = Color.Black.copy(alpha = .42f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(story.content, color = Color.White, modifier = Modifier.padding(10.dp), maxLines = 4)
                    }
                }

                if (page == pager.currentPage && !mediaReady && !mediaError) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                    }
                }
                if (page == pager.currentPage && mediaError) {
                    Column(
                        Modifier.align(Alignment.Center).padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.BrokenImage, null, tint = Color.White, modifier = Modifier.size(42.dp))
                        Text("تعذر تحميل هذه القصة.", color = Color.White, fontWeight = FontWeight.Bold)
                        OutlinedButton(
                            onClick = { mediaError = false; mediaReady = false; retryToken++ },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = BorderStroke(1.dp, Color.White)
                        ) {
                            Icon(Icons.Rounded.Refresh, null)
                            Spacer(Modifier.width(6.dp))
                            Text("إعادة المحاولة")
                        }
                    }
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 18.dp, start = 12.dp, end = 8.dp).align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StudentAvatar(story.authorName, story.authorAvatarUrl, story.authorFrameUrl, 38.dp)
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        StudentName(
                            story.authorName,
                            story.authorVerified,
                            story.authorVerificationColor,
                            style = MaterialTheme.typography.bodyMedium.copy(color = Color.White)
                        )
                        Text(prettyTime(story.createdAt), color = Color.White.copy(alpha = .75f), fontSize = 10.sp)
                    }
                    if (paused) {
                        Icon(Icons.Rounded.PauseCircle, "متوقف", tint = Color.White.copy(alpha = .9f))
                    }
                    if (story.userId == session.userId) {
                        IconButton(onClick = { onEdit(story) }) { Icon(Icons.Rounded.Edit, "تعديل", tint = Color.White) }
                        IconButton(onClick = { onDelete(story) }) { Icon(Icons.Rounded.DeleteOutline, "حذف", tint = Color.White) }
                    }
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.ArrowBack, "رجوع", tint = Color.White) }
                }

                FilledTonalButton(
                    onClick = { onInteract(story) },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color.Black.copy(alpha = .42f),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Icon(
                        if (story.userId == session.userId) Icons.Rounded.Visibility else Icons.Rounded.ChatBubbleOutline,
                        null
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(if (story.userId == session.userId) "المشاهدات" else "رد أو تفاعل")
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            stories.forEachIndexed { i, _ ->
                LinearProgressIndicator(
                    progress = {
                        when {
                            i < pager.currentPage -> 1f
                            i == pager.currentPage -> progress.value
                            else -> 0f
                        }
                    },
                    modifier = Modifier.weight(1f).height(cfg.int("stories.progress_height_dp", 3, 1, 8).dp),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = .28f)
                )
            }
        }
    }
}

@Composable
private fun StoryOptionRow(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelected: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(options.size) { index ->
                val (value, label) = options[index]
                FilterChip(
                    selected = selected == value,
                    onClick = { onSelected(value) },
                    label = { Text(label) }
                )
            }
        }
    }
}

private fun parseStoryColor(value: String): Color = runCatching {
    Color(android.graphics.Color.parseColor(value))
}.getOrDefault(Color.White)

private fun storyImageFilter(name: String): ColorFilter? {
    val matrix = when (name) {
        "mono" -> ColorMatrix().apply { setToSaturation(0f) }
        "warm" -> ColorMatrix(floatArrayOf(
            1.12f, 0f, 0f, 0f, 6f,
            0f, 1.03f, 0f, 0f, 2f,
            0f, 0f, .88f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
        "cool" -> ColorMatrix(floatArrayOf(
            .90f, 0f, 0f, 0f, 0f,
            0f, 1.01f, 0f, 0f, 1f,
            0f, 0f, 1.14f, 0f, 5f,
            0f, 0f, 0f, 1f, 0f
        ))
        else -> return null
    }
    return ColorFilter.colorMatrix(matrix)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoryInteractionDialog(
    api: SupabaseApi,
    session: StudentSession,
    story: StoryItem,
    onDismiss: () -> Unit,
    onMessage: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val cfg = LocalNativeRemoteConfig.current
    val owner = story.userId == session.userId
    var reaction by remember(story.id) { mutableStateOf<String?>(null) }
    var viewers by remember(story.id) { mutableStateOf<List<ProfileSearchItem>>(emptyList()) }
    var reply by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(true) }

    fun refresh() {
        scope.launch {
            busy = true
            if (owner) {
                viewers = withContext(Dispatchers.IO) {
                    api.storyViewersHistory(session, story.id).getOrElse {
                        api.storyViewers(session, story.id).getOrDefault(emptyList())
                    }
                }
            } else {
                reaction = withContext(Dispatchers.IO) { api.myStoryReaction(session, story.id).getOrNull() }
            }
            busy = false
        }
    }
    LaunchedEffect(story.id) { refresh() }

    ModalBottomSheet(
        onDismissRequest = { if (!busy) onDismiss() },
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            Modifier.fillMaxWidth().heightIn(min = 260.dp, max = 650.dp).navigationBarsPadding().padding(horizontal = 16.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(if (owner) "نشاط القصة" else "الرد على القصة", fontWeight = FontWeight.Black, fontSize = 20.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss, enabled = !busy) { Icon(Icons.Rounded.Close, "إغلاق") }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (owner) {
                Text("${viewers.size} مشاهدة", color = StudentMuted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 480.dp)) {
                    items(viewers, key = { it.id }) { user ->
                        ListItem(
                            headlineContent = { StudentName(user.fullName, user.isVerified, user.verificationColor) },
                            supportingContent = { Text("@${user.username}") },
                            leadingContent = { StudentAvatar(user.fullName, user.avatarUrl, user.profileFrameUrl, 42.dp) }
                        )
                    }
                    if (viewers.isEmpty() && !busy) item {
                        Text("لا توجد مشاهدات حتى الآن.", color = StudentMuted, modifier = Modifier.padding(18.dp))
                    }
                }
            } else {
                if (cfg.bool("stories.reactions_enabled", true)) {
                    Text("تفاعل سريع", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "like" to Icons.Rounded.ThumbUp,
                            "love" to Icons.Rounded.Favorite,
                            "wow" to Icons.Rounded.SentimentVerySatisfied
                        ).forEach { (value, icon) ->
                            FilterChip(
                                selected = reaction == value,
                                onClick = {
                                    val next = if (reaction == value) null else value
                                    scope.launch {
                                        withContext(Dispatchers.IO) { api.setStoryReaction(session, story.id, next) }
                                            .onSuccess { reaction = next }
                                            .onFailure { onMessage(it.message ?: "تعذر حفظ التفاعل.") }
                                    }
                                },
                                label = { Icon(icon, value, Modifier.size(20.dp)) }
                            )
                        }
                    }
                }
                if (cfg.bool("stories.reply_enabled", true)) {
                    OutlinedTextField(
                        reply,
                        { reply = it.take(cfg.int("stories.reply_max_chars", 1000, 50, 5000)) },
                        label = { Text("اكتب ردًا") },
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        minLines = 3
                    )
                    Button(
                        onClick = {
                            if (reply.isBlank()) return@Button
                            scope.launch {
                                busy = true
                                val r = withContext(Dispatchers.IO) { api.sendStoryReplyToChat(session, story, reply.trim()) }
                                busy = false
                                r.onSuccess {
                                    reply = ""
                                    onMessage("تم إرسال الرد داخل المراسلات.")
                                    onDismiss()
                                }.onFailure { onMessage(it.message ?: "تعذر إرسال الرد.") }
                            }
                        },
                        enabled = reply.isNotBlank() && !busy,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) { Text("إرسال الرد") }
                }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}
