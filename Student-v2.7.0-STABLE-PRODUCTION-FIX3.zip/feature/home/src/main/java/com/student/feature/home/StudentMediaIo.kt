package com.student.feature.home

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Streams a content Uri into a temporary cache file without buffering the whole input in RAM.
 * If [maxBytes] is supplied, copying stops immediately once the limit is exceeded.
 */
internal fun materializeUriToCacheFile(
    context: Context,
    uri: Uri,
    suffix: String,
    maxBytes: Long? = null
): File {
    require(maxBytes == null || maxBytes > 0L) { "حد حجم الملف غير صالح." }
    val safeSuffix = if (suffix.startsWith('.')) suffix else ".$suffix"
    val file = File.createTempFile("student_media_", safeSuffix, context.cacheDir)
    try {
        context.contentResolver.openInputStream(uri)?.buffered()?.use { input ->
            file.outputStream().buffered().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var total = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read.toLong()
                    if (maxBytes != null && total > maxBytes) {
                        throw IllegalStateException("حجم الملف أكبر من الحد المسموح.")
                    }
                    output.write(buffer, 0, read)
                }
            }
        } ?: error("تعذر قراءة الملف.")
        require(file.length() > 0L) { "الملف فارغ." }
        return file
    } catch (t: Throwable) {
        file.delete()
        throw t
    }
}
